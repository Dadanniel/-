export default{
		URL:'http://112.74.181.229:8001/',//生产服务器
//      http://112.74.181.229:8001/   测试
//		http://39.108.37.60:8008/   生产
      	QIANDUODUO:'http://39.108.36.189:8001',//乾多多返回接口
      	
      	RETURNURL:"https://www.baidu.com/",//乾多多前端返回页面 
      	PAYRETURN:"pay/payreturn",//乾多多前端通知网址
      	
      	MONEYNONE:'http://test.moneymoremore.com:88/main/loan/toloanregisterbind.action',//前往乾多多的开户接口
//    	https://register.moneymoremore.com/loan/toloanregisterbind.action   正式
//    	http://test.moneymoremore.com:88/main/loan/toloanregisterbind.action   测试
	

      	MONEYNTWO:'http://test.moneymoremore.com:88/main/loan/toloanauthorize.action',//前往乾多多的授权接口
// 		https://auth.moneymoremore.com/loan/toloanauthorize.action 正式
//      http://test.moneymoremore.com:88/main/loan/toloanauthorize.action   测试


 		MONEYNTHREE:'http://test.moneymoremore.com:88/main/loan/toloanrecharge.action',//前往乾多多的充值接口
//      https://recharge.moneymoremore.com/loan/toloanrecharge.action     正式
//      http://test.moneymoremore.com:88/main/loan/toloanrecharge.action   测试

      	MONEYNFOUR:'http://test.moneymoremore.com:88/main/loan/toloanwithdraws.action',//前往乾多多的提现接口
//		https://withdrawals.moneymoremore.com/loan/toloanwithdraws.action  正式
//      http://test.moneymoremore.com:88/main/loan/toloanwithdraws.action  测试

      	MONEYNFIVE:'http://test.moneymoremore.com:88/main/loan/loan.action',//前往乾多多的转账接口
//    	https://transfer.moneymoremore.com/loan/loan.action   正式
//		http://test.moneymoremore.com:88/main/loan/loan.action  测试
      	
		URLSET:'http://112.74.181.229:8001/api/pc-loan-apply/',//借款接口(没登录)
		URLSETTWO:'http://112.74.181.229:8001/api/loan/',//借款接口（登录）
		URLPASSWORD:"member/reset_password",//修改密码接口
		URLYZM:"common/send_verify_code",//验证码接口
		INDEX_DATA:"http://112.74.181.229:8001/member/index_data",//首页数据
		AGLOBAL_DATA:"http://112.74.181.229:8001/aglobal_data",//全局数据
		PREPROJECT:'http://112.74.181.229:8001/api/preproject/',//标预告列表
		NEWPROJECT:'api/newproject/',//新标速递列表
		REGISTER:"http://112.74.181.229:8001/member/register/",//注册接口
		LOGIN:"login",//登录
		SUGGESTION:'message/suggestion',//意见反馈
		REPAY_ACCESS:'loan/repay_access',//还款通道
		MODIFY_IMAGE:'member/modify_image',//上传头像
		
		PROJECT_MAIN:"api/project-detail",//标详情已登录
		PROJECT_DETAIL:"api/project_main",//标详情未等录
		PROJECT_INFO:'http://112.74.181.229:8001/project/project_info',//标的信息
		INVESTMENT_LIST:"http://112.74.181.229:8001/investment/investment_list",//投资列表
		MY_INDEX_DATA:'member/my_index_data',//我的页面
		ENCODEURL:"common/encodeurl",//乾多多后台encodeurl
		
		SIGNATURE:'pay/signature',//乾多多秘钥
		MONEY_IN_OUT:"pay/money_in_out",//乾多多充值提现获取订单号
		PAYINVEST:'pay/invest/',//投资的转账列表
		PAY_INVEST:'pay/pay_invest',//支付的转账列表
		PAY_REPAY:'pay/repay',//还款的转账列表
		ADPAY_REPAY:"pay/advance_repay",//获取提前还款转账列表
		ISSUE_DATAILS:"http://112.74.181.229:8001/issue/issue_details",//回款计划
		MENBER_INFO:'http://112.74.181.229:8001/member/info/',//获取用户信息
		QUERY_BALANCE:'http://112.74.181.229:8001/pay/query_balance',//刷新余額
		MODIFY_NAME:'member/modify_name',//修改姓名
		MY_LOAN:'http://112.74.181.229:8001/api/my-loan/',//还款计划(我的借款)
		MY_INVESTMENT:'api/my-investment/',//回款计划   我的投资数据
		MY_RECOMMEND:'http://112.74.181.229:8001/api/recommendproject/',//推荐项目
		MODIFY_PASSWORD:'member/modify_password/',//修改密码（传入手机号码旧密码新密码）
		MODIFY_MOBILE:'member/modify_mobile',//修改手机号码
		MEMBER_ID_CARD:"member/member_id_card",//身份证验证接口
		MY_PRE_INVESTMENT:"http://112.74.181.229:8001/api/my-pre-investment/",//获取预投数据
		REPAY_AMOUNT:'pay/get_repay_amount',//获取还款金额
		MESSAGE:'http://112.74.181.229:8001/message/message',//
		BANK_CARD:'member/bank_card',//绑定银行卡
		PROJECT_SUMMARY:'http://112.74.181.229:8001/project/project_summary',//项目介绍
		  
		BACKCARD:'common/backcard',//银行卡
      	BANK_PROVINCE:'common/bank_province',//省
		BANK_CITY:'common/bank_city',//市
		BANKCARD_NAME:'member/bankcard_name',//获取银行卡名称
      	
      	MEMBER_ACCOUNT:'http://112.74.181.229:8001/member/finance',//会员账户
      	CANCEL_LOAN:"http://112.74.181.229:8001/loan/cancel_loan",//撤销借款
      	CANCEL_INVEST:"http://112.74.181.229:8001/pay/cancel_invest",//撤销投资
		MEMBER_TYPE:'http://112.74.181.229:8001/api/member/',//交易账单刷选
		CHECK_PROJECT:'investment/check_project_password',//开锁密码
}
