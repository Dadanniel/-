import Vue from 'vue'
import Router from 'vue-router'
import goashore from '@/components/goashore'//登陆页面
import registeredaccount from '@/components/Mregisteredaccount'//注册账户
import forgetpassword from '@/components/Mforgetpassword'//	忘记密码
import Home from '@/components/Home'//首页
import Invest from '@/components/Invest'//投资页
import Account from '@/components/Account'//账户页
import Mine from '@/components/Mine'//我的页
import Boorowmoney from '@/components/borrowmoney'//借款通道
import Repayment from '@/components/repayment'//还款
import Repayments from '@/components/repayments'//还款通道
import UserDetail1 from '@/components/UserDetail1'//banner1
import UserDetail2 from '@/components/UserDetail2'//banner2
import UserDetail3 from '@/components/UserDetail3'//banner3
import register from '@/components/register'//广告位 跳转注册页面
import xbsd from '@/components/xbsd'//新标速递
import foreshow from '@/components/foreshow'//标预告
import signdetails from '@/components/signdetails'//标的详情
import foreshowdetails from '@/components/foreshowdetails'//预投
import itemdetails from '@/components/itemdetails'//标的信息
import itemreferral from '@/components/itemreferral'//项目详情
import Investmentlist from '@/components/Investmentlist'//投资列表
import refuntplan from '@/components/refuntplan'//还款计划
import Homeprelaunch from '@/components/Homeprelaunch'//首页预投
import Homeinvest from '@/components/Homeinvest'//首页我要投资
import signdetailsa from '@/components/signdetailsa'//首页的标预告详情



import mineword from '@/components/mineword'//我的页的消息
import authentication from '@/components/authentication'//我的页的实名认证
import bindbankcard from '@/components/bindbankcard'//我的页面绑定银行卡
import Minepersonal from '@/components/Minepersonal'//我的页的个人中心
import Minechangehead from '@/components/Minechangehead'//我的页更换头像
import Minechangeaccout from '@/components/Minechangeaccout'//我的页更改我的用户名
import Minetwocode from '@/components/Minetwocode'//我的页的我的二维码
import Mineremovephone from '@/components/Mineremovephone'//我的页的更换手机号码
import Minvitefriends from '@/components/Minvitefriends'//我的页面邀请好友
import Minesystembid from '@/components/Minesystembid'//我的页系统自动投标
import Mineearnings from '@/components/Mineearnings'//我的页的经纪人收益
import Minebeginguide from '@/components/Minebeginguide'//我的页新手指南
import Msetinstall from '@/components/Msetinstall'//我的页的设置
import Malterpassword from '@/components/Malterpassword'//我的页修改密码
import Mfeedback from '@/components/Mfeedback'//我的设置的意见反馈
import Minedeposit from '@/components/Minedeposit'//我的页面提现
import Minedeposittwo from '@/components/Minedeposittwo'//我的页面充值
import Mineshare from'@/components/Mineshare'//我的页的好友邀请的分享
import mineguanyuwomen from'@/components/mineguanyuwomen'//关于我们


import investone from '@/components/investone'//投资页面的置家贷
import investtwo from '@/components/investtwo'//投资页面的抵押贷
import investthiree from '@/components/investthiree'//投资页面的赎楼贷
import investfour from '@/components/investfour'//投资页面的债权转让
import investfive from '@/components/investfive'//投资页面的体验区

//待删除
import investmine from '@/components/investmine'//投资页面的我要投资1
import investnvrstrepe from '@/components/investnvrstrepe'//投资页面的我要投资2
import invesdetails from '@/components/invesdetails'//投资页我的详情

import zhucexieyi from '@/components/zhucexieyi'//注册协议
import accountone from '@/components/accountone'//账户页面的我的投资
import accounttwo from '@/components/accounttwo'//账户页面的我的借款
import accountthiree from '@/components/accountthiree'//账户页面我的预投
import accountfour from '@/components/accountfour'//账户页的债权转让
import accountbills from '@/components/accountbills'//账户页的交易账单
import Aborrowing from '@/components/Aborrowing'//账户页的投资的投资金额
import accounttwos from'@/components/accounttwos'//账户页的借款详情
import accountthirees from '@/components/accountthirees'//账户页我的预投详情
import accountfours from '@/components/accountfours'//账户页页的债权转让详情
import accountschemes from '@/components/accountschemes'//账户页面的我要投资的回款计划
import accounttwoconten from '@/components/accounttwoconten'//账户页面的我要借款的回款计划
import accountthireeconten from '@/components/accountthireeconten'//账户页面的我要预投的回款计划
import accountfourconten from '@/components/accountfourconten'//账户页面的债权转让的回款计划
import accountmakeover from '@/components/accountmakeover'//账户页面的我的投资的债权转让申请
import repaymenttwo from '@/components/repaymenttwo'//账户还款

import alert from '@/components/alert/qddalert'//乾多多返回页面
Vue.use(Router)

//改写返回函数，返回的时候就会触发这个,
//你也可以直接监听浏览器的返回事件，定义一个变量就行了，逻辑跟这个差不多


export default new Router({
	mode: 'history',
	scrollBehavior (to, from, savedPosition) {
		return { x: 0, y: 0 }
	},
  routes: [
  	{
  		path:'/goashore',
  		name:'goashore',
  		component:goashore
  	},
  	{
  		path:'/registeredaccount',
  		component:registeredaccount
  	},
  	{
  		path:'/forgetpassword',
  		component:forgetpassword
  	},
    {
      path: '/',
      name: 'Home',
      component: Home
  	},
  	{
  		path:'/pagresale',
  		name:"pagresale",
  		component:alert
	  },
	  {
		path:"/zhucexieyi",
		component:zhucexieyi

	  },
    {
      path: '/invest',
      name: 'Invest',
      component: Invest,
      redirect: '/investone',
      children:[
      	{
      		path:'/investone',
      		component:investone
      	},
      	{
      		path:'/investtwo',
      		component:investtwo
      	},
      	{
      		path:'/investthiree',
      		component:investthiree
      	},
      	{
      		path:'/investfour',
      		component:investfour
      	},
      	{
      		path:'/investfive',
      		component:investfive
      	}
      ]
    },
    {
      path: '/account',
      name: 'Account',
      component: Account,
      redirect:'/accountone',
      children:[
      	{
      		path:'/accountone',
      		component:accountone,
      		meta: {
		      	keepAlive:true// 不需要被缓存
		   	 	},
      	},
      	{
      		path:'/accounttwo',
      		component:accounttwo,
      		meta: {
		      	keepAlive:true// 不需要被缓存
		   	 	},
      	},
      	{
      		path:'/accountthiree',
      		component:accountthiree,
      		meta: {
		      	keepAlive:true// 不需要被缓存
		   	 	},
      	},
      	{
      		path:'/accountfour',
      		component:accountfour,
      		meta: {
		      	keepAlive:true// 不需要被缓存
		   	 	},
      	}
      ]
    },
    {
      path: '/mine',
      name: 'Mine',
      component: Mine
    },
     { 
     	path: '/borrowmoney',
     	component: Boorowmoney
     },
     {
    	path:"/repayment",
    	name:"repayment",
    	component:Repayment
     },
     {
     	path:'/repayments',
     	component:Repayments
     },
     {
    	path: '/userdetail/1',
    	component: UserDetail1
    },
    {
    	path: '/userdetail/2',
    	component: UserDetail2
    },
    {
    	path: '/userdetail/3',
    	component: UserDetail3
    },
    {
    	path:"/register",
    	component:register
    },
    {
    	path:'/xbsd',
    	component:xbsd
    },
    {
    	path:'/foreshow',
    	component:foreshow
    },
    {
    	path:'/signdetails/:id',
    	component:signdetails
    },
     {
    	path:'/signdetailsa/:id',
    	component:signdetailsa
    },
    {
    	path:'/foreshowdetails/:id',
    	component:foreshowdetails
    },
    {
    	path:'/itemdetails/:id',
    	component:itemdetails
    },
 
    {
    	path:'/itemreferral/:id',
    	component:itemreferral
    },
    {
    	path:'/Investmentlist/:id',
    	component:Investmentlist
    },
    {
    	path:'/refuntplan/:id',
    	component:refuntplan
    },
    {
    	path:'/mineword',
    	component:mineword
    },
    {
    	path:'/authentication',
    	component:authentication
    },
    {
    	path:'/bindbankcard',
    	component:bindbankcard
    },
    {
    	path:'/Minepersonal',
    	name:"Minepersonal",
    	component:Minepersonal
    },
    {
    	path:'/Minechangehead',
    	component:Minechangehead
    },
    {
    	path:'/Minechangeaccout',
    	component:Minechangeaccout
	},
	{
		path:"/mineguanyuwomen",
		component:mineguanyuwomen
	},
    {
    	path:'/Minetwocode',
    	component:Minetwocode
    },
    {
    	path:'/Mineremovephone',
    	component:Mineremovephone
    },
    {
    	path:'/repaymenttwo',
    	name:"repaymenttwo",
    	component:repaymenttwo
    },
    {
    	path:'/Minvitefriends',
    	component:Minvitefriends
    },
    {
    	path:'/Minesystembid',
    	component:Minesystembid
    },
    {
    	path:'/Mineearnings',
    	component:Mineearnings
    },
    {
    	path:'/Minebeginguide',
    	component:Minebeginguide
    },
    {
    	path:'/Msetinstall',
    	component:Msetinstall
    },
    {
		path:'/Homeprelaunch/:id',
		name:'Homeprelaunch',
    	component:Homeprelaunch
    },
    {
    	path:'/Malterpassword',
    	component:Malterpassword
    },
    {
    	path:'/Mfeedback',
    	component:Mfeedback
    },
    {
    	path:'/Minedeposit',
    	component:Minedeposit
    },
    {
    	path:'/Minedeposittwo',
    	component:Minedeposittwo
    },
    {
    	path:'/Mineshare',
    	component:Mineshare
    },
    {
    	path:'/Homeinvest/:id',
    	name:"Homeinvest",
    	component:Homeinvest
    },
    {
    	path:'/investnvrstrepe/:id',
    	name:"investnvrstrepe",
    	component:investnvrstrepe
    },
    {
    	path:'/investmine/:id',
    	component:investmine
    },
    {
    	path:'/invesdetails/:id',
    	component:invesdetails
    },
    {
    	path:'/accountbills/:id',
    	component:accountbills
    },
    {
    	path:'/Aborrowing/:id',
    	component:Aborrowing
    },
    {
    	path:'/accounttwos/:id',
    	component:accounttwos
    },
    {
    	path:'/accountthirees/:id',
    	component:accountthirees
    },
    {
    	path:'/accountfours/:id',
    	component:accountfours
    },
    {
    	path:'/accountschemes/:id',
    	component:accountschemes
    },
    {
    	path:'/accounttwoconten/:id',
    	component:accounttwoconten
    },
    {
    	path:'/accountthireeconten/:id',
    	component:accountthireeconten
    },
    {
    	path:'/accountfourconten',
    	component:accountfourconten
    },
    {
    	path:'/accountmakeover',
    	name:'accountmakeover',
    	component:accountmakeover
    }
  ]
})

 

