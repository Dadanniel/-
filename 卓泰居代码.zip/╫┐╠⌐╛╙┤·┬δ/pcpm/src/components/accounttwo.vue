<template>
	<div class="accounttwo" style="padding-bottom:0.98rem">
		<div v-for="item in list">
			<div @click="routerbtn(item)">
				<div id="accountop">
					<div  class="xbsd_box_div" :style="{'background-color':item.project_type.color}">{{item.project_type.name}}</div>
					<div>{{item.name}}</div>
					<div>
						<div>{{item.date.split(" ")[0]}}</div>
						<div>{{item.date.split(" ")[1]}}</div>
					</div>
				</div>
				<ul id="accountul">
					<li>
						<div>借款金额</div>
						<div>{{item.amount}}元</div>
					</li>
					<li>
						<div>借款期限</div>
						<div>{{item.issue_count}}</div>
					</li>
					<li>
						<div>还款方式</div>
						<div>{{item.repay_type_display}}</div>
					</li>
				</ul>
			</div>
			<div class="accountbtnwarp" :class="{accounbottom:item.prompts_message.button===null}">
				<span class="accountbtnwarpspan" v-show="item.prompts_message.button!=='还款'" :class="{accountbtnwarps:item.prompts_message.button==null}">{{item.prompts_message.msg}}</span>
				<!--		<span class="accountbtnwarpspan" v-show="item.prompts_message.button==null" :class="{accountbtnwarps:item.prompts_message.button==null}">{{item.prompts_message.msg.last_payment_day}}&nbsp&nbsp&nbsp&nbsp&nbsp   {{item.prompts_message.msg.last_payment_amount}}</span>-->
				<div class="chexiaozhuangtai" v-show="item.prompts_message.button=='还款'">
					<div>
						<div>最后还款日子</div>
						<div>{{item.prompts_message.msg.last_payment_day}}</div>
					</div>
					<div>
						<div>最近还款金额</div>
						<div>{{item.prompts_message.msg.last_payment_amount}}元</div>
					</div>
				</div>
				<button :disabled="!item.prompts_message.click" v-show="item.prompts_message.button!==null" class="buttonstye" :class="{bttoncolor:item.prompts_message.button=='债权转让中'}" @click.stop="authenmoves(item)">{{item.prompts_message.button}}</button>
			</div>

		</div>
		<alert v-if="showbol" :alertfont="alertfont"></alert>
		<div id="loding" v-show="loadingzj">已全部加载..</div>
		<div id="loding" v-show="loading">正在加载更多..</div>
	</div>
</template>

<script>
	import alert from './alert'
	export default {
		data() {
			return {
				list: [],
				showbol: false,
				loadingzj:false,
				loading:false,
				alertfont: "撤销成功",
				overall:"",
				n:1,//jiazai
				token:window.sessionStorage.token 

			}
		},
		components: {
			alert
		},
		created() {
			//获取全局数据
			this.overall = JSON.parse(window.sessionStorage.overall);
			
//			获取借款列表
			
			this._idnexlist();
//			下拉获取列表
			function getScrollTop() {　　
				var scrollTop = 0,
					bodyScrollTop = 0,
					documentScrollTop = 0　　
					if(document.body) {　　　　 bodyScrollTop = document.body.scrollTop;　　 }　　
					if(document.documentElement) {　　　　 documentScrollTop = document.documentElement.scrollTop;　　 }　　 scrollTop = (bodyScrollTop - documentScrollTop > 0) ? bodyScrollTop : documentScrollTop;　　
					return scrollTop;
				}
				//文档的总高度 
				function getScrollHeight() {　　
					var scrollHeight = 0,
						bodyScrollHeight = 0,
						documentScrollHeight = 0;　　
					if(document.body) {　　　　 bodyScrollHeight = document.body.scrollHeight;　　 }　　
					if(document.documentElement) {　　　　 documentScrollHeight = document.documentElement.scrollHeight;　　 }　　 scrollHeight = (bodyScrollHeight - documentScrollHeight > 0) ? bodyScrollHeight : documentScrollHeight;　　
					return scrollHeight;
				}
				//浏览器视口的高度 
				function getWindowHeight() {　　
					var windowHeight = 0;　　
					if(document.compatMode == "cSS1compat") {　　　　 windowHeight = document.documentElement.clientHeight;　　 } else {　　　　 windowHeight = document.body.clientHeight;　　 }　　
					return windowHeight;
				}
	
				window.onscroll = ()=> {
					//判断滑到底部					　　
					if(getScrollTop() + getWindowHeight() == getScrollHeight()) {
						this._idnexlist();
					};
				}

			

		},
		methods: {

			routerbtn(item) {
				if(item.project !== null) {
					this.$router.push("/accounttwos/" + item.id)
				
				}

			},

			
			_idnexlist(){
				var url = this.$url.MY_LOAN
				this.$http.get(url+"?page=" + this.n++, { headers: { 'Authorization':this.token} })
				.then((response) => {
					for(var i = 0; i < response.data.results.length; i++) {
						if(response.data.results[i].project_type==null){
							response.data.results[i].project_type="#FFF0F5"
						}
						if(response.data.results[i].project !== null) {
							response.data.results[i]= response.data.results[i].project							
						}
						if(response.data.results[i].issue_type == "MONTH") {
							response.data.results[i].issue_count = response.data.results[i].issue_count + "个月"
						} else {
							response.data.results[i].issue_count = response.data.results[i].issue_count + "天"
						}
						for(var l = 0; l < this.overall.project_type_list.length; l++) {
							if(response.data.results[i].project_type == this.overall.project_type_list[l].code) {
								response.data.results[i].project_type = this.overall.project_type_list[l] 	
							}
						}

					}
					this.loading=true
					setTimeout(()=>{
						this.loading=false
					},1000)
					this.list = this.list.concat(response.data.results)
					console.log(this.list)
					window.sessionStorage.accounttwo = JSON.stringify(this.list)
				})
				.catch(()=>{
					this.loadingzj=true
					setTimeout(()=>{
						this.loadingzj=false
					},1000)
					
				})
			},
			authenmoves(item) {
				var id = item.id
				if(item.prompts_message.click == true) {

					if(item.prompts_message.button == "撤销") {
						var types=item.project == null?"LOAN_APPLY":"PROJEcT"
						this.$http.post(this.$url.CANCEL_LOAN,{
								id:item.id,
								type:types
							},{headers:{
								Authorization:this.token
							}})
							.then((response) => {
								console.log(response)
								if(response.data.code == 0) {
									this.showbol = true;
									var that = this
									setTimeout(function() {
										that.showbol = false
									}, 1200)
									this.n=1
									this.list=[]
									this._idnexlist();
								}
							})

					}
					if(item.prompts_message.button == "还款") {
						this.$store.dispatch("authenmoves")
						window.sessionStorage.authitem=JSON.stringify(item)
						this.$router.push({ name: "repaymenttwo" })
					}

				}

			}
		}
	}
</script>

<style scoped="scoped">
	#accountop {
		height: 0.88rem;
		width: 100%;
		background-color: #FFFFFF;
		border-bottom: 1px solid #DcDcDc;
		overflow: hidden;
		margin-top: 0.1rem;
		position: relative;
	}
	
	#accountop>div {
		float: left;
		font-size: 0.3rem;
	}
	
	.accounttwo {
		width: 100%;
		overflow: hidden;
	}
	
	.xbsd_box_div {
		width: 0.44rem;
		height: 0.28rem;
		font-size: 0.16rem!important;
		line-height: 0.28rem;
		text-align: center;
		/*background: red;*/
		border-radius: 4px;
		position: absolute;
		top: 0.27rem;
		left: 0.24rem;
		color: #FFFFFF;
		overflow: hidden;
	}
	
	.xbsd_box_div1 {
		background-color: red!;
	}
	
	.xbsd_box_div2 {
		background-color: yellow;
	}
	
	.xbsd_box_div3 {
		background-color: beige;
	}
	
	.xbsd_box_div4 {
		background-color: black;
	}
	
	.xbsd_box_div5 {
		background-color: blue;
	}
	
	@media(max-width:400px)and (min-width:300px) {
		.xbsd_box_div {
			width: 25px;
			height: 14px;
			font-size: 12px;
			line-height: 14px;
			text-align: center;
			/*background: red;*/
			border-radius: 4px;
			position: absolute;
			top: 0.26rem;
			left: 0.24rem;
			color: #FFFFFF;
			overflow: hidden;
		}
	}
	
	#accountop>div:nth-of-type(2) {
		margin-left: 0.88rem;
		height: 0.88rem;
		line-height: 0.88rem;
	}
	
	#accountop>div:nth-of-type(3) {
		float: right;
		margin-right: 0.24rem;
		font-size: 0.2rem;
		color: #666666;
		height: 0.88rem;
		margin-top: 0.15rem;
		text-align: center;
		border-top: 1px solid #FFFFFF;
		box-sizing: border-box;
	}
	
	#accountop>div:nth-of-type(3)>div:nth-of-type(2) {
		margin-top: 0.1rem;
	}
	
	#accountul {
		list-style: none;
		width: 100%;
		float: right;
		background-color: #FFFFFF;
	}
	
	#accountul>li {
		width: 80%;
		border-bottom: 1px solid #DcDcDc;
		line-height: 0.88rem;
		overflow: hidden;
		background-color: #FFFFFF;
		float: right;
	}
	
	#accountul>li>div:nth-of-type(1) {
		float: left;
		font-size: 0.28rem;
	}
	
	#accountul>li>div:nth-of-type(2) {
		float: right;
		font-size: 0.26rem;
		margin-right: 0.24rem;
	}
	
	#accountul>li:nth-of-type(3) {
		border: none;
	}
	
	.accountbtnwarp {
		width: 100%;
		height: 1rem;
		font-size: 0.26rem;
		background-color: #fde8cd;
		position: relative;
		margin-top: 2.64rem;
	}
	
	.chexiaozhuangtai {
		height: 1rem;
		margin-left: 20%;
	}
	
	.chexiaozhuangtai>div {
		margin-top: 0.2rem;
		float: left;
		text-align: center;
		font-size: 0.23rem;
	}
	
	.chexiaozhuangtai>div>div:nth-of-type(2) {
		margin-top: 0.05rem;
	}
	
	.chexiaozhuangtai>div:nth-of-type(2) {
		margin-left: 0.5rem;
	}
	
	.accounbottom {
		background-color: #DcDcDc !important;
	}
	
	.accountbtnwarpspan {
		width: 100%;
		margin-left: 0.24rem;
		display: inline-block;
		height: 1rem;
		line-height: 1rem;
	}
	
	.buttonstye {
		width: 1.9rem;
		height: 0.6rem;
		text-align: center;
		line-height: 0.6rem;
		color: #FFFFFF;
		background-color: #FD8F00;
		border-radius: 6px;
		position: absolute;
		top: 0.2rem;
		right: 0.24rem;
		display: inline-block;
		border: none;
	}
	
	.bttoncolor {
		background-color: #999999;
	}
	
	.accountbtnwarps {
		text-align: center;
		width: 95%;
	}
	#loding{
		width:30%;
		height:0.68rem;
		text-align: center;
		line-height: 0.68rem;
		background:rgba(0,0,0,0.6);
		position:fixed;
		bottom:1.1rem;
		z-index:9999;
		left:35%;
		border-radius: 6px;
		color:#FFFFFF;
		
		}
</style>