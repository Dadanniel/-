<template>
	<div class="Aborrowing">
		<topct :dataname="dataname"></topct>
		<div class="Aborrowingwarp">
			<ul class="warpulone" @click="itembtn(data)">
				<li><span>{{data.name}}</span><img src="../imgs/homeqietu/shiliangzhinengkaob.png" /></li>
				<li>{{data.amount}}</li>
				<li>投资金额(元)</li>
			</ul>

			<ul class="warpultwo">
				<li>
					<span>年利率</span><span>{{data.rate}}%</span>
				</li>
				<li>
					<span>投资期限</span><span>{{data.issue_count}}</span>
				</li>
				<li>
					<span>计息方式</span><span>满标即计息</span>
				</li>
				<li>
					<span>投资收益</span><span>{{data.interest_income}}元</span>
				</li>
				<li>
					<span>回款方式</span><span>{{data.repay_type}}</span>
				</li>
				<li>
					<span>投资到期日期</span><span>{{data.invest_due_date.split("T")[0]}}</span>
				</li>
				<li @click="routerbtn" >
					<span>回款计划</span><img src="../imgs/homeqietu/shiliangzhinengkaob.png" />
				</li>
			</ul>
			<div class="aborbottom">
				放款后才可查询详细的回款计划
			</div>
		</div>
	</div>
</template>

<script>
	import topct from './topct'
	export default {
		data() {
			return {
				dataname: "投资详情",
				data: ""
			}

		},
		created() {
			var overall = JSON.parse(window.sessionStorage.overall)
			var id = this.$route.params.id;
			var account = JSON.parse(window.sessionStorage.accountone);
			for(let i = 0; i < account.length; i++) {
				if(account[i].project == id) {
					this.data = account[i]

					
				}

				for(let l = 0; l < overall.RATE_TYPE.length; l++) {
					if(overall.RATE_TYPE[l].code == this.data.rate_type) {
						this.data.rate_type = overall.RATE_TYPE[l]
					}
				}
				for(let i = 0; i < overall.repay_type.length; i++) {
					if(overall.repay_type[i].code == this.data.repay_type) {
						this.data.repay_type = overall.repay_type[i].desc

					}
				}

			}
		},
		methods:{
			routerbtn(){
				if(this.data.enter_plan==true){
					this.$router.push("/accountschemes/"+this.data.project)
				}
				
			},
			itembtn(data){
				this.$router.push({path:'/signdetails/'+data.project})
				sessionStorage.removeItem('particulars')
				window.sessionStorage.particulars="moveurl"
			}
		},
		components: {
			topct
		}
	}
</script>

<style scoped="scoped">
	.Aborrowingwarp {
		width: 100%;
		position: absolute;
		top: 0.98rem;
	}
	
	.warpulone {
		width: 100%;
		background-color: #FFFFFF;
	}
	
	.warpulone>li {
		width: 100%;
		text-align: center;
	}
	
	.warpulone>li:nth-of-type(1) {
		font-size: 0.28rem;
		color: #333333;
		padding-top: 0.4rem;
	}
	
	.warpulone>li:nth-of-type(1)>span {
		vertical-align: middle;
	}
	
	.warpulone>li:nth-of-type(1)>img {
		width: 0.17rem;
		height: 0.3rem;
		margin-left: 0.2rem;
		vertical-align: middle;
	}
	
	.warpulone>li:nth-of-type(2) {
		font-size: 0.42rem;
		color: #D83515;
		padding: 0.4rem 0;
	}
	
	.warpulone>li:nth-of-type(3) {
		font-size: 0.28rem;
		color: #333333;
		padding-bottom: 0.4rem;
	}
	
	.warpultwo {
		width: 100%;
		margin-top: 0.1rem;
		background-color: #FFFFFF;
	}
	
	.warpultwo>li {
		width: 100%;
		height: 0.88rem;
		border-top: 1px solid #DcDcDc;
		line-height: 0.88rem;
	}
	
	.warpultwo>li:nth-of-type(1) {
		border: none;
	}
	
	.warpultwo>li>span:nth-of-type(1) {
		float: left;
		font-size: 0.32rem;
		margin-left: 0.24rem;
	}
	
	.warpultwo>li>span:nth-of-type(2) {
		font-size: 0.28rem;
		float: right;
		margin-right: 0.24rem;
	}
	
	.warpultwo>li>img {
		float: right;
		margin-right: 0.24rem;
		width: 0.17rem;
		height: 0.3rem;
		margin-top: 0.29rem;
	}
	
	.aborbottom {
		font-size: 0.26em;
		color: #666666;
		margin-top: 0.2rem;
		margin-left: 0.24rem;
		margin-bottom: 0.98rem;
	}
</style>