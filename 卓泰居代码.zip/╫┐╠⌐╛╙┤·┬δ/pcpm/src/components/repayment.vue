<template>
	<div class="repament">
		<div class="headname">
			<div @click="repamentto">
				<div class="headnamelist"><img src="../imgs/homeqietu/fanhui.png"/></div>
			</div>
			<div id="headname_left">还款</div>
		</div>
		<div class="refundcenter">
			<div class="rfd_way">
				<div >还款方式</div>
				<div><img src="../imgs/homeqietu/shiliangzhinengkaob.png"/></div>
			    <div>本期还款</div>
			</div>
			<div id="explaindss">
				<div>可选择本期还款, 提前还清余额还款方式</div>
			</div>
			<div class="rfd_way" style="margin-top:0;font-size:0.26rem;">
				<div>第三方资金安全托管</div>
			</div>
			<div class="rfd_way" style="margin-top:0;">
				<div >到帐时间</div>				
			    <div style="margin-right: 0.24rem;">24小时之内</div>
			</div>
			<div class="rfd_way" style="margin-top:0;">
				<div >还款金额</div>				
			   	<input type="text" placeholder="本期应还20.0000.00元"/>
			</div>
			<div id="btnBotom">
				下一步
			</div>
		</div>
		
	</div>
		
</template>

<script>
	export default{
		methods:{
			repamentto(){
				this.$router.go(-1)
			}
		}
	}
 </script>

<style scoped="scoped">
	body,html{
		width:100%;
		height:100%;
		background-color:#f5f5f5;
	}
	.headname{
		position:fixed;
		left:0;
		top:0;
	}
	.refundcenter{
		width:100%;
		margin-top:0.88rem;
		border:1px solid #F5F5F5;
		box-sizing: border-box;
	}
	.rfd_way{
		
		height:0.88rem;
		width:100%;
		background-color:white;
		margin-top:0.2rem;
		line-height: 0.88rem;
		position: relative;
		border-top:1px solid #F5F5F5;
		box-sizing: border-box;
	}
	.rfd_way>input{
		border:0;
		height:0.26rem;
		font-size:0.26rem;
		float:left;
		margin-left:0.3rem;
		width:75%;
		margin-top:0.31rem;
		Outline:none;
		font-size:#cacaca
	}
	.rfd_way>div:nth-of-type(1){
		float:left;
		font-size:0.3rem;
		margin-left:0.24rem;
		color:#333333;
	}
	.rfd_way>div:nth-of-type(2),.rfd_way>div:nth-of-type(3){
		float:right;
		font-size:0.26rem;
	}
	.rfd_way>div:nth-of-type(2)>img{
		height:0.3rem;
		width:0.17rem;
		position: absolute;
		right:0.24rem;
		top:0.29rem;
	}
	.rfd_way>div:nth-of-type(3){
		margin-right:0.61rem;
		color:#666666;
	}
	#explaindss>div{
		width:100%;
		height:0.6rem;
		background-color:#F5F5F5;
		line-height: 0.6rem;
		font-size:0.22rem;
		color:#666666;
		text-indent: -1.2rem;
		
	}
	
	#btnBotom{
		width:6.84rem;
		margin:1.1rem auto;
		height:0.8rem;
		background-color:#D83515;
		border-radius: 6px;
		font-size:0.34rem;
		color:#FFFFFF;
		text-align: center;
		line-height: 0.8rem;
		
	}
</style>