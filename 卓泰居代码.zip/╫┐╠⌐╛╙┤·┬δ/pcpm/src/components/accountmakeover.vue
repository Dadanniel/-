<template>
	<div class="accountmakeover">
		<topct :dataname="dataname"></topct>
		<ul>
			<li>
				<div>转让金额</div>
				<div>5,000.00元</div>
			</li>
			<li>
				<div>手续费</div>
				<div>0元</div>
			</li>
			<li>
				<div>折让率</div>
				<div>0%-7.5%<input type="text" placeholder="0" v-model="text"/></div>
			</li>
			<li>
				<div>预期到帐金额</div>
				<div id="monule">4946446.14元</div>
			</li>
		</ul>
		<div id="mistbtn" @click="btnmist">提交</div>
		<div id="divwarp">
			<div>温馨提示:</div>
			<div>
					<div>1.发起债权转让将放弃本期及以后各期利息，同时从成交日起，此债权权责由受让人承担；</div>
					<div>2.转让人通过折让率设置转让价格，只可以打折；</div>
					<div>3.所有产品可转让多次；</div>
					<div>4.还款日前5天不可以转让债权；</div>
					<div>5.债权一次性转让剩余本金，认购份额最低10元，按整数倍递增；</div>
					<div>6.转让有效期为提出申请起5个自然日，有效期内被认购的部分即时成交，债权在未有人购买时可随时取消；</div>
					<div>7.逾期的借款标不可以转让；</div>
					<div>8.债权未完成转让的，超过转让期的，剩余债权归转让人所有；</div>
					<div>9.当期提前还款时，不能转让债权；使用体验金时，不能转让债权；</div>
					<div>10.债权转让如果已经有承接人，则不能撤销转让；</div>
					<div>11.债权转让过程中遇到问题，请联系客服。</div>
			</div>
		</div>
	</div>
</template>

<script>
	import topct from'./topct'
	export default{
		data(){
			return{
				dataname:"债权转让申请",
				text:""
			}	
		},
		methods:{
			btnmist(){
				var id= window.sessionStorage.accountitemid
				this.$http.post("api/api/investment-transfer-apply/",{
					project:id,
					transfer_rate:this.text,
					member:2333
				})
				.then((response)=>{
					console.log(response)
				})
			}
		},
		components:{
			topct
		}
	}
</script>

<style>
	.accountmakeover>ul{
		position:absolute;
		top:1.08rem;
		list-style: none;
		width:100%;
	}
	.accountmakeover>ul>li{
		width:100%;
		height:0.88rem;
		line-height: 0.88rem;
		text-indent: 0.24rem;
		background:#FFFFFF;
		font-size:0.32rem;
		border-bottom:1px solid #DcDcDc;
	}
	.accountmakeover>ul>li>div:nth-of-type(1){
		float:left;
	}
	.accountmakeover>ul>li>div:nth-last-of-type(1){
		border:none;
		
	}
	#monule{
		color:#fd8f00;
	}
	.accountmakeover>ul>li>div:nth-of-type(2)>input{
		width:2rem;
		outline: none;
		border-radius: 4px;
		height:0.58rem;
		margin-left:0.24rem;
		border:1px solid gray;
		margin-top:-0.1rem;
		text-indent:0.2rem;
	}
	.accountmakeover>ul>li>div:nth-of-type(2){
		float:right;
		margin-right:0.24rem;
	}
	#mistbtn{
		width:6.84rem;
		height:0.8rem;
		text-align: center;
		line-height: 0.8rem;
		background-color:#D83515;
		color:#FFFFFF;
		font-size:0.34rem;
		
		margin:auto;
		margin-top:5rem;
		border-radius: 6px;
	}
	#divwarp{
		width:95%;
		margin:auto;
		margin-top:0.4rem;
	}
	#divwarp>div:nth-of-type(1){
		color:#333333;
		font-size:0.32rem;
	}
	#divwarp>div:nth-of-type(2){
		color:gray;
		font-size:0.24rem;
	}
</style>