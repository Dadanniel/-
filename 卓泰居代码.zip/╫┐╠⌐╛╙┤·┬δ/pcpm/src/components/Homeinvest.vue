<template>
	<div class="Homeprelaunch">
		<topctfalse :dataname="dataname"></topctfalse>
		<div class="prelaunchconten">
			<div id="contentop">
				<div>
					<div :style="{'background-color':texts.project_type_display.color}" class="xbsd_box_div">{{texts.project_type_display.name}}</div>
					<div>{{texts.name}}</div>
					<div><img v-show="texts.is_lock" src="../imgs/homeqietu/biaodisuo.png"/></div>
				</div>

				<div id="contentopbox">
						<div>
							<div>年利率</div>
							<div>{{texts.rate}}%</div>
						</div>
						<div>
							<div>总额<span>(元)</span></div>
							<div>{{texts.amount}}</div>
						</div>
						<div>
							<div>期限</div>
							<div>{{texts.issue_count}}个月</div>
						</div>
						<div>
							<div>可投资<span>(元)</span></div>
							<div>{{texts.remain_amount}}元</div>
						</div>
				</div>

			</div>
			<ul id="contentuls">
				<li>
					投资金额<input type="text" :placeholder="'账户可用余额'+my_data.available_remain+'元'" v-model="amount"/>
				</li>
				<li>
					<span>投资期限</span><span>{{texts.issue_count}}个月</span>
				</li>
				<li><span>计息方式</span><span>满标即计息</span></li>
				<li><span>投资收益</span><span>根据用户输入的金额系统自动算出</span></li>
			</ul>
			<div id="contenbottom">预投成功，标的上线时系统将自动帮您转为投资</div>
			<div id="contenbtn" @click="clickbtn">
			下一步
			</div>
		</div>
		
	</div>
</template>

<script>
	import topctfalse from './topctfalse'
	export default{
		data(){
			return{
				dataname:"我要投资",
				amount:"",
				data:'',
				texts:'',
				alldata:JSON.parse(window.sessionStorage.overall),//全局数据
				my_data:"",//我的个人数据
			}
		},
		created(){
			var id= this.$route.params.id;
			this.$http.get(this.$url.NEWPROJEcT)
				.then((response)=>{
					for(let i=0;i<response.data.results.length;i++){
						if(response.data.results[i].id==id){
							for(let l=0;l<this.alldata.project_type_list.length;l++){
								if(this.alldata.project_type_list[l].name==response.data.results[i].project_type_display){
									response.data.results[i].project_type_display=this.alldata.project_type_list[l]
									this.texts=response.data.results[i]
								}
							}
						}
					}				
				})
			
			this.my_data=JSON.parse(window.sessionStorage.personaldetails)
				
		},
		components:{
			topctfalse
		},
		methods:{
			clickbtn(){
				var id= this.$route.params.id;
				this.$http.post('api/investment/investment',{				
					project_id:id,
					nember_id:1,
					amount:this.amount
					
				})
				.then((response)=>{
					this.data=response.data				
				})
			}
		}
	}
</script>

<style scoped="scoped">
	.prelaunchconten{
		width:100%;
		position:absolute;
		top:1.08rem;
	}
	#contentop{
		width:100%;

	
		background-color:#FFFFFF;
		overflow: hidden;
		position:relative;
	}
	#contentop>div:nth-of-type(1)>div{
		float:left;
	}
	#contentop>div:nth-of-type(1)>div:nth-of-type(2){
		font-size:0.3rem;
		line-height: 0.8rem;
		
	}
	.xbsd_box_div1{
		background-color:red;
	}
	.xbsd_box_div2{
		background-color:yellow;
	}
	.xbsd_box_div3{
		background-color:beige;
	}
	.xbsd_box_div4{
		background-color:black;
	}
	.xbsd_box_div5{
		background-color:blue;
		
	}
	.xbsd_box_div{
		width:0.44rem;
		height:0.28rem;
		font-size:0.16rem;
		text-align: center;
		line-height: 0.28rem;
		margin-top:0.24rem;
		border-radius: 4px;
		margin-left:0.24rem;
		margin-right:0.2rem;
		color:#FFFFFF;
	}
	@media  (min-width:300px) and (max-width: 400px) { 
	 .xbsd_box_div{
			width:26px;
			height:14px;
			font-size:12px;
			line-height:14px;
			margin-top:0.22rem;
		}
	}
	#contentop>div:nth-of-type(1)>div:nth-of-type(3){
		margin-top:0.2rem;
		width:0.2rem;
		height:0.3rem;
		position:relative;
		margin-left:0.2rem;
	}
	#contentop>div:nth-of-type(1)>div:nth-of-type(3)>img{
		width:0.2rem;
		height:0.3rem;
		position:absolute;
		top:0;
		left:0;
	}
	#contentopbox{
		width:100%;
		height:1.68rem;
		margin-top:0.8rem;
		
	}
	#contentopbox>div{
		float:left;
		width:25%;
		text-align: center;
		font-size:0.28rem;
		margin-top:0.4rem;
	}
	#contentopbox>div>div>span{
		font-size:0.18rem;
	}
	#contentopbox>div>div:nth-of-type(2){
		font-size:0.24rem;
		margin-top:0.2rem;
	}
	#contentopbox>div:nth-of-type(3){
		float:left;
		width:25%;
		text-align: center;
		font-size:0.24rem;
	}
	#contentopbox>div:nth-of-type(4){
		color:#D83515;
	}
	#contentuls{
		width:100%;
		list-style: none;
		margin-top:0.2rem;
		background-color:#FFFFFF;
	}
	#contentuls>li{
		width:100%;
		height:0.88rem;
		line-height: 0.88rem;
		font-size:0.26rem;
		text-indent: 0.24rem;
		border-top:1px solid #DcDcDc;
	}
	#contentuls>li:nth-of-type(1){
		border:none;
	}
	#contentuls>li>input{
		margin-left:0.2rem;
		width:70%;
		border:none;
		Outline:none;
	}
	#contentuls>li>span:nth-of-type(2){
		color:#FD8F00;
		margin-left:0.2rem;
	}
	#contenbottom{
		font-size:0.2rem;
		margin-top:0.2rem;
		margin-left:0.24rem;
		color:#828282;
	}
	#contenbtn{

		width:6.85rem;
		height:0.8rem;
		margin:1.1rem auto;
		text-align: center;
		line-height: 0.8rem;
		background-color:#Fc8E0D;
		color:#FFFFFF;
		font-size:0.34rem;
		border-radius: 6px;

	}
</style>