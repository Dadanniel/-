<template>
	<div class="accounttwo" style="padding-bottom:0.98rem">
		<div v-for="item in list">
		<div>
			<div id="accountop">
				<div :class="{xbsd_box_div1:'ZJD'==item.project_type.code,xbsd_box_div2:'SLD'==item.project_type.code,xbsd_box_div3:'ZQZR'==item.project_type.code,xbsd_box_div4:'TYQ'==item.project_type.code,xbsd_box_div5:'DYB'==item.project_type.code}" class="xbsd_box_div">{{item.project_type.name}}</div>
				<div>{{item.transfer_name}}</div>
				<div>
					<div>{{item.date.split("T")[0]}}</div>
					<div>{{item.date.split("T")[1]}}</div>
				</div>
			</div>
			<ul id="accountul">
				<li>
					<div>债转金额</div><div>{{item.transfer_amount}}元</div>
				</li>
				<li>
					<div>债转年利率</div><div>{{item.transfer_rate}}%</div>
				</li>
				<li><div>债转期限</div><div>{{item.transfer_issue}}天</div></li>
				<li><div>债转成本</div><div>{{item.invest_transfer_cost}}元</div></li>
			</ul>
			</div>
			<div class="accountbtnwarp" :class="{accounbottom:item.prompts_message.button===null}">
				<span class="accountbtnwarpspan" :class="{accountbtnwarps:item.prompts_message.button==null}">{{item.prompts_message.msg}}</span>
				<div :disabled="item.prompts_message.button=='债权转让中'" tag="button" v-show="item.prompts_message.button!==null" class="buttonstye" :class="{bttoncolor:item.prompts_message.button=='债权转让中'}"@click="authenmoves(item)">{{item.prompts_message.button}}</div>
				
			</div>
		</div>
		<alert v-if="showbol" :alertfont="alertfont"></alert>
	</div>
</template>

<script>
	import alert from'./alert'
	export default{
		data(){
			return{
				list:'',
				showbol:false,
				alertfont:"撤销成功"
			}
		},
		components:{
			alert
		},
		created(){
			var overall = JSON.parse(window.sessionStorage.overall);
			var n = 2
//			//获取个人信息
//			var data = JSON.parse(window.sessionStorage.personaldetails)
//			var id = data.member_id
//			var url="api/api/invest-transfer/"+id+"/investtransfers/"
//			this.$http.get(url,{headers:{'token':window.sessionStorage.token}})
//			.then((response)=>{	
//				for(var i=0;i<response.data.results.length;i++){
//					for(var l=0;l<overall.project_type_list.length;l++){
//						if(response.data.results[i].project_type==overall.project_type_list[l].code){
//							response.data.results[i].project_type=overall.project_type_list[l]
//						}
//					}
//				}
//				this.list = response.data.results
//			})
			function getScrollTop(){
			　　var scrollTop = 0, bodyScrollTop = 0, documentScrollTop = 0;
			　　if(document.body){
			　　　　bodyScrollTop = document.body.scrollTop;
			　　}
			　　if(document.documentElement){
			　　　　documentScrollTop = document.documentElement.scrollTop;
			　　}
			　　scrollTop = (bodyScrollTop - documentScrollTop > 0) ? bodyScrollTop : documentScrollTop;
			　　return scrollTop;
			} 
			 //文档的总高度 
			function getScrollHeight(){
			　　var scrollHeight = 0, bodyScrollHeight = 0, documentScrollHeight = 0;
			　　if(document.body){
			　　　　bodyScrollHeight = document.body.scrollHeight;
			　　}
			　　if(document.documentElement){
			　　　　documentScrollHeight = document.documentElement.scrollHeight;
			　　}
			　　scrollHeight = (bodyScrollHeight - documentScrollHeight > 0) ? bodyScrollHeight : documentScrollHeight;
			　　return scrollHeight;
			} 
			 //浏览器视口的高度 
			function getWindowHeight(){
			　　var windowHeight = 0;
			　　if(document.compatMode == "cSS1compat"){
			　　　　windowHeight = document.documentElement.clientHeight;
			　　}else{
			　　　　windowHeight = document.body.clientHeight;
			　　}
			　　return windowHeight;
			} 
				var that = this		
				 window.onscroll = function(){
				 	//判断滑到底部
				　　if(getScrollTop() + getWindowHeight() == getScrollHeight()){							
//							let url = 'api/api/invest-transfer/'+id+'/investtransfers/'+'?page='+n++
//							if(getScrollTop() + getWindowHeight() == getScrollHeight()){
//							that.$http.get(url)
//							.then((response)=>{
//								for(var i=0;i<response.data.results.length;i++){
//									for(var l=0;l<overall.project_type_list.length;l++){
//										if(response.data.results[i].project_type==overall.project_type_list[l].code){
//											response.data.results[i].project_type=overall.project_type_list[l]
//										}
//									}
//								}
//								//添加到this。list里继续遍历
//								that.list = that.list.concat(response.data.results)
//							})
//				　　		}
				};
			}
	 },
		methods:{
			authenmoves(item){
				var id=item.id
				if(item.prompts_message.button=="撤销"){
					this.$http.post("api/pay/CANCEL_INVEST",{
						investment_id:id,
						project_id:1,
						member_id:1
					})
					.then((response)=>{
						if(response.data.code==0){
							this.showbol=true;
							var that=this
							setTimeout(function(){
								that.showbol=false
							},1200)
						}
					})
					
				}

			}
		}
	}
</script>

<style scoped="scoped">
	.accounttwo{
		width:100%;
		overflow:hidden;
	}
	#accountop{
		height:0.88rem;
		width:100%;
		background-color:#FFFFFF;
		border-bottom:1px solid #DcDcDc;
		overflow:hidden;
		margin-top:0.1rem;
		position:relative;
	}
	#accountop>div{
		float:left;
		font-size:0.3rem;


	}
	.xbsd_box_div{
		width:0.44rem;
		height:0.28rem;
		font-size:0.16rem!important;
		line-height: 0.28rem;
		text-align: center;
		background:red;
		border-radius: 4px;
		position: absolute;
		top:0.27rem;
		left:0.24rem;
		color:#FFFFFF;
	}
	.xbsd_box_div1{
		background-color:red!;
	}
	.xbsd_box_div2{
		background-color:yellow;
	}
	.xbsd_box_div3{
		background-color:beige;
	}
	.xbsd_box_div4{
		background-color:black;
	}
	.xbsd_box_div5{
		background-color:blue;
		
	}
	@media(max-width:400px)and (min-width:300px ) {
		.xbsd_box_div{
			width:25px;
			height:14px;
			font-size:12px;
			line-height:14px;
			text-align: center;
			background:red;
			border-radius: 4px;
			position: absolute;
			top:0.26rem;
			left:0.24rem;
			color:#FFFFFF;
		}
	}
	#accountop>div:nth-of-type(2){
		margin-left:0.88rem;
		height:0.88rem;
		line-height: 0.88rem;
	}
	#accountop>div:nth-of-type(3){
		float:right;
		margin-right:0.24rem;
		font-size:0.2rem;
		color:#666666;
		height:0.88rem;
		margin-top:0.15rem;
		text-align: center;
		border-top:1px solid #FFFFFF;
		box-sizing: border-box;
	}
	#accountop>div:nth-of-type(3)>div:nth-of-type(2){
		margin-top:0.1rem;
	}
	#accountul{
		list-style: none;
		width:100%;
		float:right;
		background-color:#FFFFFF;
	}
	#accountul>li{
		width:80%;
		border-bottom:1px solid #DcDcDc;
		line-height: 0.88rem;
		overflow:hidden;
		background-color:#FFFFFF;
		float:right;
	}
	#accountul>li>div:nth-of-type(1){
		float:left;
		font-size:0.28rem;
	}
	#accountul>li>div:nth-of-type(2){
		float:right;
		font-size:0.26rem;
		margin-right:0.24rem;
	}
	#accountul>li:nth-last-of-type(1){
		border:none;
	}
	.accountbtnwarp{
		width:100%;
		height:1rem;

		font-size:0.26rem;
		background-color:#fde8cd;
		position:relative;
		margin-top:3.52rem;
	}
	.accountbtnwarp>span{
		margin-left:0.24rem;
		display: inline-block;
		height:1rem;
		line-height: 1rem;
	}
	.accounbottom{
		background-color:#DcDcDc !important;

	}
	.accountbtnwarpspan{
		width:100%;
		margin-left:0.24rem;
		display: inline-block;
		height:1rem;
		line-height: 1rem;
	}
	.buttonstye{
		width:1.9rem;
		height:0.6rem;
		text-align: center;
		line-height: 0.6rem;
		color:#FFFFFF;
		background-color:#FD8F00;
		border-radius: 6px;
		position:absolute;
		top:0.2rem;
		right:0.24rem;
		display: inline-block;
		border:none;
	}
	.bttoncolor{
		background-color:#999999;
	}
	.accountbtnwarp>p{
		font-size:0.26rem;
		text-align: center;
		line-height: 1rem;
	}
	.accountbtnwarps{
		text-align: center;
		width:95%;
	}
</style>