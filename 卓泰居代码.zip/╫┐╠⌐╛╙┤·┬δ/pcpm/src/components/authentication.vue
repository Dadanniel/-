<template>
	<div class="authentication">
		<topct :dataname="dataname"></topct>

		<div class="autenwarp">
			<div class="authenname">姓名<input v-if="disabled" readonly="readonly" type="" :placeholder="namea" name="" id="" value="" v-model="name" /><input v-else="disabled" type="" :placeholder="namea" name="" id="" value="" v-model="name" />
			</div>
			<div class="authennumber">身份证号<input v-if="disabled" readonly="readonly" type="" :placeholder="authennumbers" name="" id="" value="" v-model="identitycard" /><input v-else="disabled" type="" :placeholder="authennumbers" name="" id="" value="" v-model="identitycard" />
			</div>
			<div class='autents'>实名认证成功后不可更改</div>
			<button :disabled="disabled" class="authenbtn" :class="{'authenbtn2':disabled}" @click="autenbtn">下一步</button>
		</div>

	</div>
</template>

<script>
	import topct from "./topct"
	import {MessageBox} from 'mint-ui';
	export default {
		data() {
			return {
				dataname: "实名认证",
				name: "",//姓名
				identitycard: "",//身份证号码
				namea: "",
				authennumbers: "",
				disabled: "",
				member_id:"",
				token:window.sessionStorage.token
			}
		},
		created() {
			
			var personaldetails = JSON.parse(window.sessionStorage.my_data)
			this.member_id=personaldetails.id
			this.namea = personaldetails.real_name
			this.authennumbers = personaldetails.id_no
			this.disabled = personaldetails.id_verified
		},
		components:{
			topct
		},
		methods: {
			autenbtn() {
				
				var isIDcard1 = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$/; 
				var isIDcard2 = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/; 
				if(this.name!==""){
					if(this.identitycard!==""){

							this.$http.post(this.$url.URL+this.$url.MEMBER_ID_CARD, {
								name: this.name,
								id_no: this.identitycard
							},{
								headers: {
									Authorization:this.token
								}
							})
							.then((response)=>{
								console.log(response)
								if(response.data.code == "0"){
									MessageBox("提示",'实名认证成功')									
									this.$http.get(this.$url.URL+this.$url.MY_INDEX_DATA, {headers: {'Authorization':window.sessionStorage.token}})
									.then((response)=>{										
										window.sessionStorage.my_data = JSON.stringify(response.data)
										this.$router.push("/Mine")
									})
								}else{
									MessageBox("提示",response.data.msg)
								}
							})
					}else{
						MessageBox("提示",'请填写身份证')
					}
					
				}else{
					MessageBox("提示",'请填写姓名')
				}
			}
		}
	}
</script>

<style>
	.autenwarp {
		position: absolute;
		top: 1.08rem;
		width: 100%;
	}
	
	.authenname {
		top: 1.08rem;
		width: 100%;
		height: 0.88rem;
		line-height: 0.88rem;
		font-size: 0.31rem;
		background-color: #FFFFFF;
		background-color: #FFFFFF;
		text-indent: 0.24rem;
		color: #333333;
	}
	
	.authennumber {
		margin-top: 0.2rem;
		width: 100%;
		height: 0.88rem;
		line-height: 0.88rem;
		font-size: 0.31rem;
		background-color: #FFFFFF;
		text-indent: 0.24rem;
		color: #333333;
	}
	
	input {
		margin-left: 0.3rem;
		Outline: none;
		width: 60%;
		border: none
	}
	
	.autents {
		margin-top: 0.2rem;
		font-size: 0.22rem;
		text-indent: 0.24rem;
		color: #666666;
	}
	
	.authenbtn {
		width: 6.85rem;
		height: 0.8rem;
		margin: 1.1rem auto;
		text-align: center;
		line-height: 0.8rem;
		background-color: #Fc8E0D;
		color: #FFFFFF;
		font-size: 0.34rem;
		border-radius: 6px;
		text-align: center;
		display: block;
		border: none;
	}
	
	.authenbtn2 {
		background: #cccccc;
	}
</style>