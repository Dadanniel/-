<template>
	<div class="mine">
		<div class="minetop">
			<router-link tag="div" to="/mineword">
				<img @click="minebtnone" src="../imgs/mineimgs/xiaoxithreedfklj.png" alt="" />
			</router-link>
			<div>{{numbera}}</div>
		</div>
		<div class="minewarp">
			<div class="minewarptop">
				<div class="minewarptop_head">
					<img :src="headimg" />
				</div>
				<div class="minewarp_top_name">
					<div>{{my_data.member_name}}</div>
					<div>{{my_data.slogan}}</div>
				</div>
				<router-link tag="div" class="minewarp_top_left" to="/Minepersonal" @click.native="authenmoves">
					<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
				</router-link>
				<div class="minewarp_top_midden">
					<div>
						<div>账户总额</div>
						<!--<router-link tag="div" to="/pagresale">
							账户总额
						</router-link>-->
						<div>￥{{my_data.total}}</div>
					</div>
					<div>
						<div>可用资金</div>
						<div>￥{{my_data.available_remain}}</div>
					</div>
					<div>
						<div>累计收益</div>
						<div>￥{{my_data.accumulative_income}}</div>
					</div>
				</div>
				<div class="minewarp_top_btn">
					<div class="minewarp_top_btn_left">
						<div>
							<div @click="authenmoveone ">充值</div>
						</div>
					</div>
					<div class="minewarp_top_btn_right">
						<div @click="authenmovetwo ">提现</div>
					</div>
				</div>
			</div>
			<div class="minewarp_ul1">
				<ul>
					<li class="minewarp_li">
						<div>
							<img src="../imgs/mineimgs/jinjirenshouyi.png" alt="" />
						</div>
						<div>邀请好友奖励</div>
						<router-link tag="div" to="/Mineearnings" @click.native="authenmoves">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</router-link>
						<div>{{my_data.broker_income}}</div>
					</li>
					<li class="minewarp_li">
						<div>
							<img src="../imgs/mineimgs/shimingrenzheng.png" alt="" />
						</div>
						<div>实名认证</div>

						<router-link tag="div" to="/authentication" @click.native="authenmoves">

							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />

						</router-link>
						<div style="color:#FD8F01;" v-if="my_data.id_verified">已实名</div>
						<div style="color:#cAcAcA;" v-else>未实名</div>
						<div></div>
					</li>
					<li class="minewarp_li">
						<div>
							<img src="../imgs/mineimgs/bangdingyinghangka.png" alt="" />
						</div>
						<div>绑定银行卡</div>
						<router-link tag="div" to="/bindbankcard" @click.native="authenmoves">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</router-link>
						<div style="color:#FD8F01;" v-if="my_data.bank_card_no">已绑定({{yhk}})</div>
						<div style="color:#cAcAcA;" v-else>未绑定</div>
						<div></div>
					</li>
					<li class="minewarp_li">
						<div>
							<img src="../imgs/mineimgs/jinjirenshouyi.png" alt="" />
						</div>
						<div>第三方资金托管账户</div>

						<div>
							<form name="form1"  :action="url" method="post" v-if="my_data.deposit_id==null">
								<input type="" v-show="move" name="RegisterType" id="" value="2" />
								<input type="" v-show="move" name="Mobile" id="" :value="my_data.mobile" />
								<input type="" v-show="move" name="RealName" id="RealName" :value="my_data.real_name" />
								<input type="" v-show="move" name="IdentificationNo" id="IdentificationNo" :value="my_data.id_no" />
								<input type="" v-show="move" name="LoanPlatformAccount" id="" :value="my_data.member_id"/>
								<input type="" v-show="move" name="PlatformMoneymoremore" id="" :value="p" />
								<input type="" v-show="move" name="ReturnURL" id="ReturnURL" :value="returnurl" />
								<input type="" v-show="move" name="NotifyURL" id="NotifyURL" :value="Notifyurl" />
								<input type="" v-show="move" name="SignInfo" id="" :value="result"/>
								<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" @click="submitbtn"/>
							</form>
							<form name="form2" :action="urltwo" method="post" v-else-if="my_data.deposit_id!==null&&my_data.deposit_auth==false">
								<input type="" v-show="move" name="MoneymoremoreId" id="" :value="my_data.deposit_id" />
								<input type="" v-show="move" name="PlatformMoneymoremore" id="" :value="p" />
								<input type="" v-show="move" name="AuthorizeTypeOpen" id="RealName" value="1,2,3" />
								<input type="" v-show="move" name="ReturnURL" id="IdentificationNo" :value="returnurl" />
								<input type="" v-show="move" name="NotifyURL" id="" :value="Notifysurl" />
								<input type="" v-show="move" name="SignInfo" id="" :value="result" />
								<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" @click="submitbtn" />
							</form>	
								<img v-else src="../imgs/homeqietu/shiliangzhinengkaob.png"/>
						</div>
						<div style="color:#cAcAcA;" v-if="my_data.deposit_id==null">未开户</div>
						<div style="color:#FD8F01;" v-else>{{open_account}},{{authorization}}</div>
					</li>
				</ul>
			</div>
			<div class="minewarp_ul1" style="margin-bottom:1.18rem;">
				<ul>
					<li class="minewarp_li">

						<div>
							<div class="minewarp_li_ratate">热</div>
							<img src="../imgs/mineimgs/yaoqinghaoyoufix.png" alt="" />
						</div>
						<div>邀请好友
						</div>
						<router-link tag="div" to="/Minvitefriends" @click.native="authenmoves">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</router-link>
						<div></div>
					</li>
					<li class="minewarp_li">
						<div>
							<img src="../imgs/mineimgs/xitongzidongtoubiao.png" alt="" />
						</div>
						<div>系统自动投标</div>

						<router-link tag="div" to="/Minesystembid" @click.native="authenmoves">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</router-link>
						<div></div>
					</li>
					<li class="minewarp_li">
						<div>
							<img src="../imgs/mineimgs/xinshouzhilan.png" alt="" />
						</div>
						<div>新手指南</div>
						<router-link tag="div" to="/Minebeginguide" @click.native="authenmoves">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</router-link>
						<div style="color:#cAcAcA;">400-5566-455</div>
					</li>
					<li class="minewarp_li">
						<div>
							<img src="../imgs/mineimgs/guanyuwomenone.png" alt="" />
						</div>
						
						<div>关于我们</div>

						<router-link tag="div" to="/mineguanyuwomen">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</router-link>
						<div></div>
					</li>
					<li class="minewarp_li">
						<div>
							<img src="../imgs/mineimgs/shezhithree.png" alt="" />
						</div>
						<div>设置</div>
						<router-link tag="div" to="/Msetinstall" @click.native="authenmoves">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</router-link>
						<div></div>
					</li>
				</ul>
			</div>
			<router-link tag="div" to="/goashore" class="personalbtn" @click.native="authenmovesd">
				退出当前账户
			</router-link>
		</div>

	</div>
</template>

<script>
	import {MessageBox} from 'mint-ui';
	export default {
		data() {
			return {
				url:"",//开户接口
				urltwo:"",//授权接口
				data: "",
				yhk:"",//处理过的银行卡
				p: "",
				headimg: window.localStorage.headimg,
			
				numbera: "",
				move: false,
				result: "",
				result2: "",
				switchover: "", //是否实名认证
				my_data:JSON.parse(window.sessionStorage.my_data), //我的页面数据信息
				bank_no: "", //绑定银行卡信息
				open_account: "", //乾多多是否开户
				authorization: "", //乾多多是否授权		
				Notifyurl:"",//乾多多开户后台返回接口
				Notifysurl:"",//乾多多授权后台返回接口
				returnurl:"",//钱多多前端返回接口
			}
		},
		created() {
			this.url=this.$url.MONEYNONE//开户接口
			this.urltwo=this.$url.MONEYNTWO//授权接口
			this.returnurl=this.$url.URL+this.$url.PAYRETURN//前端返回页面
			this.Notifyurl = this.$url.QIANDUODUO + JSON.parse(window.sessionStorage.overall).RECHARGE_CALLBACK//开户后台通知网址
			this.Notifysurl = this.$url.QIANDUODUO+JSON.parse(window.sessionStorage.overall).AUTHORIZE_CALLBACK//授权接口		
			
			
			//左上角长度
			this.$http.get(this.$url.MESSAGE)
			.then((response) => {
				this.numbera = response.data.results.length
			})
			//获取我的页面数据
			this.$http.get(this.$url.URL+this.$url.MY_INDEX_DATA, { headers: { "Authorization": window.sessionStorage.token } })
				.then((response) =>{
					this.my_data = response.data
					console.log(this.my_data)
					this.yhk=this.my_data.bank_card_no.substr(this.my_data.bank_card_no.length-4)
					window.sessionStorage.my_data=JSON.stringify(response.data)//存储我的页面信息
					this.p = window.sessionStorage.p
					console.log(this.p)
					//密钥拼接
					//开户密钥
		//			console.log(this.data.real_name)
					console.log(this.my_data)
					var str=""
					if(this.my_data.deposit_id==null){
						 str = "2" + this.my_data.mobile + this.my_data.real_name + this.my_data.id_no + this.my_data.member_id + this.p + this.returnurl+this.Notifyurl
					}else{
						 str =this.my_data.deposit_id+this.p+"1,2,3"+this.returnurl+this.Notifysurl
					}
					
					console.log(str)
					//获取密钥		
					//开户获取密钥
					this.$http.post(this.$url.URL+this.$url.SIGNATURE,{
							str:str
						})
						.then((response)=>{
							this.result=response.data.result
						})
					if(this.my_data.deposit_id ==null) {
						this.open_account = "未开户"
					} else { 
						this.open_account = "已开户"
					}
					if(this.my_data.deposit_auth == true) {
						this.authorization = "已授权"
					} else {
						this.authorization = "未授权"
					}
				})


		},
		mounted(){
			
		},
		computed: {

		},
		methods: {
			submitbtn(){
				if(this.my_data.deposit_id==null){
					form1.submit()
				}else{
					form2.submit()
				}
				
			},
			authenmovesd() {
				sessionStorage.clear();
				localStorage.clear();
			},
			minebtnone() {
				this.$store.dispatch("minebtnone")
			},
			
			authenmoves() {
				this.$store.dispatch("authenmoves")
			},
			authenmoveone() {
				this.$store.dispatch("authenmoves")
				
				if(this.my_data.deposit_id!==null){
					if(this.my_data.deposit_auth == true){
						this.$router.push("/Minedeposittwo")
					}else{
						MessageBox("提示",'请先进行托管账户授权')
					}
				}else{
					MessageBox("提示",'请先进行托管账户开户')
				}
			},
			authenmovetwo(){
				this.$store.dispatch("authenmoves")
				if(this.my_data.bank_card_no!==''){
					if(this.my_data.deposit_id!==null){
						if(this.my_data.deposit_auth == true){
							this.$router.push("/Minedeposit")
						}else{
							MessageBox("提示",'请先进行托管账户授权')
						}
					}else{
						MessageBox("提示",'请先进行托管账户开户')
					}
				}else{
					MessageBox("提示",'请先绑定银行卡')	
				}				
			}
		}
	}
</script>

<style scoped="scoped">
	#subbtn {
		width: 100%;
		height: 100%;
		background-color: #D83515;
		border: none;
		color: #FFFFFF;
		font-size: 0.26rem;
		outline: none;
		margin-left: 0;
	}
	
	.minetop {
		width: 100%;
		height: 1.38rem;
		background-color: #Fc8E0D;
		position: relative;
		z-index: 888;
	}
	
	.minetop>div>img {
		width: 0.4rem;
		height: 0.38rem;
		position: absolute;
		right: 0.24rem;
		top: 0.25rem;
	}
	
	.minetop>div:nth-of-type(2) {
		width: 0.3rem;
		height: 0.3rem;
		background-color: #FFFFFF;
		text-align: center;
		line-height: 0.3rem;
		font-size: 0.22rem;
		color: #D83515;
		position: absolute;
		top: 0.15rem;
		right: 0.15rem;
		border-radius: 50%;
	}
	
	.minewarp {
		width: 93.6%;
		margin: -0.5rem auto;
		z-index: 889;
		position: absolute;
		left: 0.24rem;
	}
	
	.minewarptop {
		width: 100%;
		height: 4.07rem;
		background-color: #FFFFFF;
		position: relative;
		border: 1px solid #FFFFFF;
		box-sizing: border-box;
	}
	
	.minewarptop_head {
		width: 1.08rem;
		height: 1.08rem;
		position: absolute;
		top: 0.3rem;
		left: 0.3rem;
		border-radius: 50%;
	}
	
	.minewarptop_head>img {
		width: 1.08rem;
		height: 1.08rem;
		border-radius: 50%;
	}
	
	.minewarp_top_name {
		font-size: 0.22rem;
		position: absolute;
		left: 1.88rem;
		top: 0.5rem;
	}
	
	.minewarp_top_name>div:nth-of-type(2) {
		margin-top: 0.24rem;
		color: #D83515;
	}
	
	.minewarp_top_left {
		width: 0.18rem;
		height: 0.32rem;
		position: absolute;
		right: 0.26rem;
	}
	
	.minewarp_top_left>img {
		width: 0.18rem;
		height: 0.32rem;
	}
	
	.minewarp_top_midden {
		width: 100%;
		margin-top: 1.98rem;
	}
	
	.minewarp_top_midden>div {
		width: 33.3333333333%;
		float: left;
		text-align: center;
	}
	
	.minewarp_top_midden>div>:nth-of-type(1) {
		font-size: 0.28rem;
	}
	
	.minewarp_top_midden>div>:nth-of-type(2) {
		font-size: 0.26rem;
		margin-top: 0.3rem;
		color: #D83515;
	}
	
	.minewarp_top_btn {
		width: 100%;
		height: 0.5rem;
	}
	
	.minewarp_top_btn>div {
		width: 50%;
		height: 0.5rem;
		float: left;
		font-size: 0.26rem;
	}
	
	.minewarp_top_btn>div>div {
		width: 2.3rem;
		height: 0.5rem;
		text-align: center;
		line-height: 0.5rem;
		margin: auto;
		margin-top: 0.3rem;
		color: #FFFFFF;
		border-radius: 6px;
	}
	
	.minewarp_top_btn_left>div {
		background-color: #D83515;
	}
	
	.minewarp_top_btn_right>div {
		background-color: #2F81FD;
	}
	
	.minewarp_ul1 {
		width: 100%;
		background-color: #FFFFFF;
		margin-top: 0.2rem;
		margin-bottom: 20px !important;
	}
	
	.minewarp_ul1>ul {
		width: 96%;
		margin: auto;
		list-style: none;
	}
	
	.minewarp_ul1>ul>li {
		height: 0.88rem;
		border-top: 1px solid #DcDcDc;
		line-height: 0.88rem;
		position: relative;
	}
	
	.minewarp_ul1>ul>li:nth-of-type(1) {
		border-top: none;
	}
	
	.minewarp_li>div {
		float: left;
	}
	
	.minewarp_li>div:nth-of-type(2) {
		font-size: 0.29rem;
		margin-left: 0.2rem;
	}
	
	.minewarp_li>div:nth-of-type(4) {
		font-size: 0.26rem;
		float: right;
		margin-right: 0.1rem;
		color: #D83515;
	}
	
	.minewarp_li>div:nth-of-type(3) {
		width: 0.17rem;
		height: 0.3rem;
		float: right;
	}
	
	.minewarp_li>div:nth-of-type(3) img {
		width: 0.17rem;
		height: 0.3rem;
		position: absolute;
		top: 0.29rem;
	}
	
	.minewarp_li>div:nth-of-type(1) {
		width: 0.36rem;
		height: 0.4rem;
	}
	
	.minewarp_li>div:nth-of-type(1)>img {
		width: 0.36rem;
		height: 0.4rem;
		position: absolute;
		top: 0.22rem;
	}
	
	.minewarp_li_ratate {
		width: 20px;
		height: 20px;
		font-size: 12px;
		border-radius: 50%;
		text-align: center;
		line-height: 20px;
		border-radius: 50%;
		background-color: #D83515;
		position: absolute;
		color: #FFFFFF;
		top: 0.1rem;
		left: 1.7rem;
	}
	
	.personalbtn {
		width: 100%;
		height: 0.8rem;
		font-size: 0.34rem;
		background-color: #Fc8e0d;
		border-radius: 6px;
		text-align: center;
		line-height: 0.8rem;
		color: #FFFFFF;
		margin-bottom: 1.08rem;
	}
</style>