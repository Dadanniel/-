<template>
	<div class="bindbankcard" >
		<topct :dataname="dataname"></topct>
		<div class="bindcardwarp" v-if="moves">
			<div class="bindcontenttop">
				为了您的资金安全，请绑定账户实名认证人的银行卡，且绑定的银行卡需<span style="color:red;">和充值卡为同一张</span>
			</div>

			<div class="bindname">
				持卡人姓名<span style="margin-left:0.2rem;color:#9ec4fd">{{mydata.real_name}}</span>
			</div>

			<div class="bindname">
				银行卡号<input type="" name="" placeholder="请输入您的银行卡" id="" value="" v-model="bankcard" @blur="movesbtn"/>
			</div>
			<div class="bindname" @click="btn_1">
				<span>银行卡</span><span style="margin-left:0.5rem;color:#9ec4fd">{{moneycontent1.text}}</span>
				<img  src="../imgs/homeqietu/gengduojiantou.png" alt="">
			</div>
			<div class="bindname" @click="btn_2">
				<span>开户省</span><span style="margin-left:0.5rem;color:#9ec4fd">{{moneycontent2.text}}</span>
				<img  src="../imgs/homeqietu/gengduojiantou.png" alt="">
			</div>
			<div class="bindname" @click="btn_3">
				<span>开户市</span><span style="margin-left:0.5rem;color:#9ec4fd">{{moneycontent3.text}}</span>
				<img  src="../imgs/homeqietu/gengduojiantou.png" alt="">
			</div>
			<div class="bindname">
				<span>卡类型</span><span style="margin-left:0.5rem;color:#9ec4fd">
					
				</span>
				
			</div>
			<mt-radio
				v-model="value"
				:options="options" @change="check">
			</mt-radio>
			<div class="bindbankbtn" @click="bindbankbtn">
				确定
			</div>
		</div>
		<div class="bindcardwarptwo" v-else>
			<div class="bindcarpdiv">
				<div class="bindcarpimg"><img src="../imgs/mineimgs/yhk.png"/></div>
				<div class="bindcarpfont">
					<div>{{mydata.bank_name}}</div>
					<div>{{yhk}}</div>
				</div>
			</div>
			<div class="bindbankbtn" @click="btnset">更换银行卡</div>
		</div>
	</div>
</template>

<script>
import Picker from "better-picker";
import topct from "./topct";
import { MessageBox } from "mint-ui";
export default {
  data() {
    return {
      moves: true, //
      mydata: "", //我的个人信息
      dataname: "绑定银行卡",
      name: "",
      bankcard: "",
      token: window.sessionStorage.token,
      yhk: "",
      value: "",
      purpose1: ["湖南", "湖北"], //银行卡地址列表
      purposeone: [], //银行卡列表
      moneycontent1: "", //确认的因银行地址
      kedizhivlue: "", //卡value
      purpose2: [], //省列表
      purposetwo: [], //省列表
      moneycontent2: "", //确认的省
      shengvlue: "", //省value
      purpose3: "", //市列表
      purposethree: [], //市列表
      shivlue: "", //省value
      moneycontent3: "", //确认的市
      shivlue: "", //市value
      options: [
        {
          label: "信用卡",
          value: "0",
          disabled: false
        },
        {
          label: "借记卡",
          value: "1",
          disabled: true
        }
      ]
    };
  },
  created() {
    this._bankprovince(); //获取省份
    this._bankcity(); //获取市级
    this._bankcard(); //银行卡类型
    this.mydata = JSON.parse(window.sessionStorage.my_data);
    if (this.mydata.bank_card_no == "") {
      this.moves = true;
    } else {
      this.moves = false;
    }
    var reg = /^(\d{4})(\d*)(\d{4})$/;
    var str = this.mydata.bank_card_no;
    this.yhk = str.replace(reg, function(a, b, c, d) {
      return b + c.replace(/\d/g, "*") + d;
    });
  },
  methods: {
	  movesbtn(){
		  this.$http.post(this.$url.URL+this.$url.BANKCARD_NAME,{
					card_no:this.bankcard
				},{
					 headers: { Authorization: "JWT " + this.token } 
				})
				.then((response)=>{
					console.log(response)
					 for (var setone in this.purpose1) {
						if (this.purpose1[setone] == response.data.bank_name) {
					
							this.kedizhivlue = setone;
							var setthree={text:response.data.bank_name}
							this.moneycontent1=setthree;
							console.log(this.kedizhivlue)
							
						}
					}
				})
	  },
    btn_1() {
      var data1 = this.purposeone;
      var picker = new Picker({
        data: [data1],
        selectedIndex: [0],
        title: "银行卡"
      });
      picker.on("picker.select", (selectedVal, selectedIndex) => {
        this.moneycontent1 = data1[selectedIndex[0]];
        for (var setone in this.purpose1) {
          if (this.purpose1[setone] == data1[selectedIndex[0]].text) {
            this.kedizhivlue = setone;
          }
        }

      });
      picker.show();
    },
    btn_2() {
      var data1 = this.purposetwo;
      var picker = new Picker({
        data: [data1],
        selectedIndex: [0],
        title: "开户省"
      });
      picker.on("picker.select", (selectedVal, selectedIndex) => {
        this.purposethree = [];
		this.moneycontent2 = data1[selectedIndex[0]];
		this.moneycontent3 ="";


        for (var stds in this.purpose2) {
          if (this.purpose2[stds].city == data1[selectedIndex[0]].text) {
            this.shengvlue = this.purpose2[stds].value;
          }
        }
  
  
        for (var stdsd in this.purpose3) {
          if (this.purpose3[stdsd].code == this.shengvlue) {
            var object = { text: this.purpose3[stdsd].city };
            this.purposethree.push(object);
          }
        }
      });
      picker.show();
    },
    btn_3() {
      if (this.shengvlue !== "") {
        var data1 = this.purposethree;
        var picker = new Picker({
          data: [data1],
          selectedIndex: [0],
          title: "开户市"
        });
        picker.on("picker.select", (selectedVal, selectedIndex) => {
          this.moneycontent3 = data1[selectedIndex[0]];
          for (var stdstwo in this.purpose3) {
            if (this.purpose3[stdstwo].city == data1[selectedIndex[0]].text) {
              this.shivlue = this.purpose3[stdstwo].value;
           
            }
          }
        });
        picker.show();
      } else {
        MessageBox("提示", "请选择开户省份");
      }
    },
    bindbankbtn() {
	  var set = /^\d{16,20}$/;
	  if(set.test(this.bankcard)){
      if (this.bankcard !== "") {
        if (this.moneycontent1 !== "") {
          if (this.moneycontent2 !== "") {
            if (this.moneycontent3 !== "") {
				if(this.value!==""){
					 this.$http
                .post(
                  this.$url.URL + this.$url.BANK_CARD,
                  {
                    name:this.mydata.real_name,
					card_no:this.bankcard,
					bank_name:this.moneycontent1.text,
					bank_code:this.kedizhivlue,
					is_credit_card:this.value,
					province_code:this.shengvlue,
					city_code:this.shivlue
                  },
                  { headers: { Authorization: this.token } }
                )
                .then(response => {
                  if (response.data.code == "0") {
                    this.$http
                      .get(this.$url.URL + this.$url.MY_INDEX_DATA, {
                        headers: { Authorization: this.token }
                      })
                      .then(response => {
                        this.mydata = response.data;
                        window.sessionStorage.my_data = JSON.stringify(
                          response.data
                        );
                        MessageBox("提示", "绑定成功");
                        var reg = /^(\d{4})(\d*)(\d{4})$/;
                        var str = this.mydata.bank_card_no;
                        this.yhk = str.replace(reg, function(a, b, c, d) {
                          return b + c.replace(/\d/g, "*") + d;
                        });
                        this.$router.push("/Mine");
                      });
                  } else {
                    MessageBox("提示", response.data.msg);
                  }

                  this.moves = false;
                });
				}else{
					MessageBox("提示", "请选择银行卡类型");
				}
             
            } else {
              MessageBox("提示", "请选择开户市");
            }
          } else {
            MessageBox("提示", "请选择开户省份");
          }
        } else {
          MessageBox("提示", "请选择开户银行");
        }
      } else {
        MessageBox("提示", "请输入银行卡号");
	  }
	  }else{
		  MessageBox("提示", "银行卡格式不对"); 
	  }
    },
    btnset() {
      this.moves = true;
    },
    check(value) {
      console.log(value);
    },
    _bankprovince() {
      this.$http
        .get(this.$url.URL + this.$url.BANK_PROVINCE) //省
        .then(res => {
          this.purpose2 = res.data.backcard_dict;
          for (var sets in this.purpose2) {
            var object = { text: this.purpose2[sets].city };
            this.purposetwo.push(object);
          }
      
        });
    },
    _bankcity() {
      this.$http
        .get(this.$url.URL + this.$url.BANK_CITY) //市
        .then(res => {
          this.purpose3 = res.data.backcard_dict;
     
        });
    },
    _bankcard() {
      this.$http
        .get(this.$url.URL + this.$url.BACKCARD) //银行卡类型
        .then(res => {
        	
          this.purpose1 = res.data.backcard_dict;
          for (var set in this.purpose1) {
            var object = { text: this.purpose1[set] };
            this.purposeone.push(object);
          }
        });
    }
  },
  components: {
    topct
  }
};
</script>

<style scoped="scoped">
.bindcardwarp {
  width: 100%;
  position: absolute;
  top: 1.18rem;
}
.bindcardwarptwo {
  width: 100%;
  position: absolute;
  top: 1.18rem;
}
.bindcarpdiv {
  width: 95%;
  margin: auto;
  background: #9ec4fd;
  border-radius: 4px;
  padding: 0.4rem 0;
}
.mint-cell-wrapper {
  width: 0.5rem;
  float: left;
}
.bindcarpimg {
  width: 0.66rem;
  height: 0.66rem;
  display: inline-block;
  vertical-align: middle;
  margin-left: 0.2rem;
}
.bindcarpimg > img {
  width: 100%;
  height: 100%;
  vertical-align: middle;
}
.bindcarpfont {
  display: inline-block;
  vertical-align: middle;
  font-size: 0.24rem;
  font-weight: bold;
  margin-left: 0.2rem;
}
.bindcarpfont > div:nth-of-type(2) {
  margin-top: 0.2rem;
}
.bindcontenttop {
  width: 100%;
  font-size: 0.24rem;
  padding: 0 0.24rem;
}
.bindname {
  margin-top: 0.2rem;
  width: 100%;
  height: 0.88rem;
  line-height: 0.88rem;
  text-indent: 0.24rem;
  font-size: 0.32rem;
  background-color: #ffffff;
  font-size: 0.26rem;
  font-weight: bold;
}
.bindname > input {
  margin-left: 0.3rem;
  outline: none;
  border: none;
  width: 60%;
}
.bindcomtentmidden {
  margin-top: 0.3rem;
  width: 100%;
  font-size: 0.26rem;
  text-indent: 0.24rem;
}
.bindauthcode {
  width: 100%;
  height: 0.88rem;
  margin-top: 0.2rem;
  line-height: 0.88rem;
  background-color: #ffffff;
  line-height: 0.88rem;
  position: relative;
}
.bindauthcode > input {
  position: absolute;
  width: 70%;
  height: 0.88rem;
  left: 0.24rem;
  border: none;
  outline: none;
}
.bindauthcodediv {
  font-size: 0.26rem;
  width: 1.5rem;
  height: 0.46rem;
  text-align: center;
  line-height: 0.46rem;
  color: #d83515;
  border: 1px solid #d83515;
  position: absolute;
  top: 0.21rem;
  right: 0.5rem;
  border-radius: 6px;
}
#bindtext1 {
  font-size: 0.28rem;
  margin-top: 0.8rem;
  margin-left: 0.24rem;
  color: #2f81fd;
}
.bindtext2 {
  margin-top: 0.2rem;
  margin-left: 0.4rem;
  font-size: 0.24rem;
  color: #666666;
}
.bindbankbtn {
  width: 6.85rem;
  height: 0.8rem;
  text-align: center;
  line-height: 0.8rem;
  background: #fd8f01;
  border-radius: 6px;
  font-size: 0.34rem;
  color: #ffffff;
  margin: auto;
  margin-top: 1rem;
}
.bindname > img {
  width: 0.3rem;
  float: right;
  margin-top: 0.35rem;
  margin-right: 0.2rem;
}
</style>