<template>
	<div class="itemdetails">
		<div class="headname">
			<div @click="gobacktop">
					<div class="headnamelist">
						<img src="../imgs/homeqietu/fanhui.png"/>
					</div>
			</div>
			<div id="headname_left">标的信息</div>
		</div>
		<div class="itemdetailswarp">
			<div id="item_money"><p>标的金额</p></div>
			<div id='item_moneyto'>
				<div>
					<div>借款总额</div>
					<div>{{data.amount}}</div>
				</div>
				<div>
					<div>已还金额</div>
					<div>{{data.remain_amount}}</div>
				</div>
				<div>
					<div>待还金额</div>
					<div>{{data.repay_amount}}</div>
				</div>
			</div>
			<div id="item_money" style="border-top:none"><p>借款人信息</p></div>
			<div class="item_bottomwary">
				<div>
					<div>借款人成功次数：</div>
					<div>{{data.loan_success_times}} 次</div>
				</div>
				<div>
					<div>流标/审核失败：</div>
					<div>{{data.loan_fail_times}} 次</div>
				</div>
				<div>
					<div>待还款：</div>
					<div>3 笔</div>
				</div>
				<div>
					<div>提前还款：</div>
					<div>{{data.ahead_repay_times}} 笔</div>
				</div>
				<div>
					<div>准时还款：</div>
					<div>{{data.ontime_repay_times}} 笔</div>
				</div>
				<div>
					<div>逾期还款：</div>
					<div>{{data.delay_repay_times}} 次</div>
				</div>
				<div>
					<div>还款能力：</div>
					<div>{{data.repayable}}</div>
				</div>
				<div>
					<div>逾期未还款：</div>
					<div>0 笔</div>
				</div>
				
				
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				data:''
			}
		},
		computed:{
			
		},
		methods:{
			gobacktop(){
				this.$router.go(-1)
			}
		},
		created(){
			var id= this.$route.params.id;
			this.$http.post(this.$url.PROJECT_INFO,{
				project_id:id
			})
			.then((response)=>{
				console.log(response.data)
				this.data=response.data
				
			})
		}
	}
</script>

<style scoped="scoped">
	.headname{
		position:fixed;
		left:0;
		top:0;
	}
	.itemdetailswarp{
		width:100%;
		position: absolute;
		top:1.08rem;
	}
	#item_money{
		width:100%;
		height:0.88rem;
		text-align: left;
		background-color:#FFFFFF;
		font-size:0.32rem;
		line-height: 0.88rem;
		border-top:1px solid #DcDcDc;
		

	}
	#item_money>p{
		margin-left:0.34rem;
		font-weight:bold;
	}
	#item_moneyto{
		width:100%;
		height:1.7rem;
		border-bottom:1px solid #DcDcDc;
		border-top:1px solid #DcDcDc;
		background-color:#FFFFFF;
	}
	#item_moneyto>div{
		width:33.3333333%;
		float:left;
		text-align: center;
		margin-top:0.49rem;
	}
	#item_moneyto div>div:nth-of-type(1){
		font-size:0.32rem;
	}
	#item_moneyto div>div:nth-of-type(2){
		font-size:0.26rem;
		margin-top:0.2rem;
		color:#FD8F00;
	}
	.item_bottomwary{
		width:100%;
		border-top:1px solid #DcDcDc;
		font-size:0.28rem;
		background-color:#FFFFFF;
		overflow: hidden;
	}
	.item_bottomwary>div{
		float:left;
		margin-top:0.3rem;
		/*width:50%;*/
	}
	.item_bottomwary div>div:nth-of-type(1){
		float:left;
	}
	.item_bottomwary div>div:nth-of-type(2){
		float:right;
		color:#FD8F00;
	}
	
	.item_bottomwary>div:nth-of-type(2n-1){
		width:3rem;
		margin-left:0.34rem;
		margin-right:0.7rem;
	}
	.item_bottomwary>div:nth-of-type(2n){
		width:2.7rem;

	}
	.item_bottomwary>div:nth-of-type(7),.item_bottomwary>div:nth-of-type(8){
		padding-bottom:0.4rem;
	}
	.item_bottomwary>div:nth-of-type(1),.item_bottomwary>div:nth-of-type(2){
		margin-top:0.4rem;
	}
	
	
</style>