<template>
	<div class="accountbills">
		<p @click="accountbtn1">筛选</p>
		<topct :dataname="dataname"></topct>
		<div class="accountlist">
			<ul class="listul">
				<li v-for="item in list" class="listli">
					<div>
						<p class="listp">{{item.time.split(" ")[0]}}</p>
						<p>{{item.time.split(" ")[1]}}</p>
					</div>
					<div>{{item.deal_type_display}}</div>
					<div>
						<p>{{item.deal_amount}}</p>
						<p>{{item.deal_comment}}</p>
					</div>
					<!--<div class="div_1">
						<p>可用金额</p>
						<p>{{item.available_remain}}</p>
					</div>-->
				</li>
			</ul>

		</div>
		<div class="accountfiltratewarp" v-show="accounwarpshow">
			<div class="filtrateleft">

			</div>
			<div class="filtrateright">
				<div class="filtrattop" @click="cancelbtn">
					确定
				</div>
				<p>选择分类</p>
				<ul class="filtrateul">
					<li class="filtrateli" v-for="(item,index,move) in show_list" :class="{filtratelis:indexs==index}" @click="filtratclick(index)">{{item}}</li>

				</ul>
			</div>
		</div>
	</div>
</template>

<script>
	import topct from './topct'
	export default {
		data() {
			return {
				dataname: "交易账单",
				listli: "",
				accounwarpshow: false,
				list: [],
				indexs: 0,
				show_list: [], //显示数据
				parameter_list: [], //传参数据
				deal_type: "", //传参分类数据
			}
		},
		created() {
			var overall = JSON.parse(window.sessionStorage.overall);
			this.listli = overall.DEAL_TYPE
			console.log(this.listli)
			this.show_list.push("全部")
			this.parameter_list.push("")
			for(let i = 0; i < this.listli.length; i++) {
				var data_list = JSON.stringify(this.listli[i]).split(":")
				this.parameter_list.push(data_list[0].substring(2, data_list[0].length - 1))
				this.show_list.push(data_list[1].substring(1, data_list[1].length - 2))
			}

			var id = this.$route.params.id;
			var url = "api/api/member/"
			this.$http.get(url, {
							headers: {
								"Authorization": window.sessionStorage.token
							}
						})
				.then((response) => {
					this.list = response.data.results
					this.$nextTick(function() {
						var listul = document.querySelector(".listul")
						var listli = document.querySelectorAll('.listli')
						var listp = document.querySelectorAll('.listp')
						for(let i = 0; i < listli.length; i++) {
							var set = listp[i].innerHTML.split("-")[1][1]
							var sets = listp[i + 1].innerHTML.split("-")[1][1]
							if(set !== sets) {
								var div = document.createElement("div");
								div.innerText = sets + "月";
								div.style.height = "0.4rem";
								div.style.backgroundcolor = "#cAcAcA";
								div.style.fontSize = "0.22rem";
								div.style.color = "#333333";
								div.style.lineHeight = "0.4rem";
								div.style.textIndent = "0.24rem"
								listul.insertBefore(div, listli[i + 1])
							}
						}
					})
				})
		},
		components: {
			topct
		},
		methods: {

			filtratclick(index) {
				this.indexs = index
				this.deal_type = this.parameter_list[this.indexs]

			},
			accountbtn1() {
				this.accounwarpshow = true
				setTimeout(function() {
					$(".filtrateright").animate({
						right: 0
					}, 300)
				}, 100)

			},
			cancelbtn() {
				$(".filtrateright").animate({
					right: "-80%"
				}, 300)

				if(this.deal_type == "") {
					this.$http.get("api/api/member/", {
							headers: {
								"Authorization": window.sessionStorage.token
							}
						})
						.then((response) => {
							console.log("null"+response)
							this.list = response.data.results
						})
				} else {
					console.log("VVVV"+ this.deal_type)
					this.$http.get("api/api/member/?deal_type="+this.deal_type,{
							headers: {
								"Authorization": window.sessionStorage.token
							}
						})
						.then((response) => {
							console.log("AAA"+response)
							this.list = response.data.results
						})
				}

				this.animationa = false
				this.animationb = true
				var that = this
				setTimeout(function() {
					that.accounwarpshow = false
				}, 300)
			}
		},
		mounted() {
			var that = this
			Zepto(".filtrateright").on("swipeRight", function() {
				$(".filtrateright").animate({
					right: "-80%"
				}, 300)
				setTimeout(function() {
					that.accounwarpshow = false
				}, 300)
			})
		}
	}
</script>

<style scoped="scoped">
	.accountbills {
		overflow: hidden;
	}
	
	.accountbills>p:nth-of-type(1) {
		font-size: 0.28rem;
		color: #FFFFFF;
		position: fixed;
		top: 0.3rem;
		right: 0.24rem;
		z-index: 900;
	}
	
	@media (max-width:400px) and (min-width: 300px) {
		.accountbills>p:nth-of-type(1) {
			font-size: 0.28rem;
			color: #FFFFFF;
			position: fixed;
			top: 0.25rem;
			right: 0.24rem;
			z-index: 900;
		}
	}
	
	.accountlist {
		width: 100%;
		position: absolute;
		top: 0.88rem;
		margin-bottom: 0.98rem;
	}
	
	.accountlist>ul {
		list-style: none;
		width: 100%;
	}
	
	.accountlist>ul>li {
		width: 100%;
		height: 1.2rem;
		border-top: 1px solid #DcDcDc;
		background-color: #FFFFFF;
		position: relative;
	}
	
	.accountlist>ul>li:nth-of-type(1) {
		border: 1px solid #FFFFFF;
		box-sizing: border-box;
	}
	
	.accountlist li>div {
		float: left;
	}
	
	.accountlist li>div:nth-of-type(1) {
		font-size: 0.22rem;
		text-align: center;
		margin-left: 0.24rem;
		margin-top: 0.3rem;
	}
	
	.accountlist li>div:nth-of-type(1)>p:nth-of-type(2) {
		margin-top: 0.1rem;
	}
	
	.accountlist li>div:nth-of-type(2) {
		font-size: 0.18rem;
		width: 0.6rem;
		height: 0.6rem;
		background-color: #FD8F00;
		text-align: center;
		line-height: 0.6rem;
		color: #FFFFFF;
		border-radius: 50%;
		margin: 0 0.4rem;
		margin-top: 0.3rem;
	}
	
	@media (max-width:340px) and (min-width: 300px) {
		.accountlist li>div:nth-of-type(2) {
			font-size: 12px;
			width: 30px;
			height: 30px;
			line-height: 30px;
			margin-top: 0.24rem
		}
		.accountlist li>div:nth-of-type(1) {
			margin-top: 0.24rem;
		}
	}
	
	.accountlist li>div:nth-of-type(3) {
		margin-top: 0.16rem;
	}
	
	.accountlist li>div:nth-of-type(3)>p:nth-of-type(1) {
		font-size: 0.34rem;
	}
	
	.accountlist li>div:nth-of-type(3)>p:nth-of-type(2) {
		font-size: 0.22rem;
		margin-top: 0.1rem;
	}
	
	.accountfiltratewarp {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background: rgba(0, 0, 0, 0.6);
		z-index: 99999;
		overflow: hidden;
	}
	
	.filtrateright {
		width: 80%;
		position: fixed;
		height: 100%;
		background-color: #FFFFFF;
		top: 0;
		right: -80%;
	}
	
	.filtrateleft {
		width: 20%;
		height: 100%;
		float: left;
	}
	
	.filtrattop {
		height: 0.88rem;
		width: 100%;
		text-align: right;
		padding-right: 0.24rem;
		line-height: 0.88rem;
		font-size: 0.28rem;
		color: #D83515;
	}
	
	.filtrateright>p {
		font-size: 0.33rem;
		margin-left: 0.16rem;
		color: #333333;
	}
	
	.filtrateul {
		width: 100%;
		margin-top: 0.6rem;
		padding: 0 0.6rem;
		list-style: none;
	}
	
	.filtrateli {
		float: left;
		font-size: 0.16rem;
		width: 23%;
		height: 0.6rem;
		text-align: center;
		line-height: 0.6rem;
		margin-right: 15%;
		border: 1px solid #cAcAcA;
	}
	
	.filtratelis {
		background-color: #2F81FD;
		border: none;
		color: #FFFFFF;
	}
	
	.filtrateul>li:nth-of-type(3n) {
		margin-right: 0;
	}
	
	.filtrateul>li:nth-of-type(n+4) {
		margin-top: 0.3rem;
	}
	.div_1{
		
	}
</style>