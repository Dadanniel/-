<template>
	<div class="signdetail">
		<div class="headname">
			<router-link tag="div" to="/foreshow">
				<div class="headnamelist"><img src="../imgs/homeqietu/fanhui.png"/></div>
			</router-link>
			<div id="headname_left">标详情</div>
			<img src="../imgs/homeqietu/zhuanfathree.png" alt="" />
		</div>
		<div class="sign_center">
			<div class="count_downwarp" >
				<div id="count_downcnter">
					<div>新标上线倒计时</div>
					<div>01</div> ：
					<div>56</div> ：
					<div>20</div>
				</div>
			</div>
			<div class="sign_center_topbox">
				<div id="sign_center-top">明秀东路荣和山水绿城房产借款<img src="../imgs/homeqietu/biaodisuo.png" alt="" /></div>
				<div id="sign_center-top-nlv">12%<span>年利率</span></div>
				<div id="investplan">
					<span>投资进度</span>
					<meter value="0.6">60%</meter>
					<span>80%</span>
				</div>
				<div id="sign_center_top1">
					<div><div>剩余时间</div>
						<div>3天20时12分36秒</div>
					</div>
					<div>
						<div>产品总额/起投金额</div>
						<div>60.000.00/20.000.00</div>
					</div>
					
				</div>
				<div id="sign_center_top1" style="margin-top:0.4rem">
					<div><div style="margin-top:0.4rem">可投资金额</div>
						<div style="color:#FD8F00">20.000.00</div>
					</div>
					<div>
						<div style="margin-top:0.4rem">标的期限</div>
						<div>3 个月</div>
					</div>
					
				</div>
				<div id="sign_center_top2">
						<div><span>计息方式：</span> 满标即计息</div>
						<div><span>还款方式：</span> 到期一次性还款</div>
				</div>
			</div>	
			<ul class="sign_center_bottomul">
				<li><span>项目详情</span>
				<router-link to="/itemreferral">
					<img id="sign_center_bottomulimg" src="../imgs/homeqietu/shiliangzhinengkaob.png"/>
				</router-link>
				</li>
				<li><span>标的信息</span>
					<router-link to="/itemdetails">
					<img id="sign_center_bottomulimg" src="../imgs/homeqietu/shiliangzhinengkaob.png"/>
					</router-link>
				</li>
				<li><span>投资列表</span>
					<router-link to="/Investmentlist">
					<img id="sign_center_bottomulimg" src="../imgs/homeqietu/shiliangzhinengkaob.png"/>
					</router-link>
				</li>
				<li><span>还款计划</span>
					<router-link to="/refuntplan">
					<img id="sign_center_bottomulimg" src="../imgs/homeqietu/shiliangzhinengkaob.png"/>
					</router-link>
				</li>
			</ul>
		</div>
		<div class="signdetail_bottom">
			我要投资
		</div>
	</div>
		
</template>

<script>
	export default{
		data(){
			return{
				
			}
		},
		computed:{
//			countsown(){
//				return this.$store.state.countsown
//			}
		},
		methods:{
			
		}
	}
</script>

<style>
	.headname{
		position:fixed;
		left:0;
		top:0;
	}
	.headname>img{
		position:fixed;
		width:0.37rem;
		height:0.35rem;
		right:0.24rem;
		top:0.27rem;
	}
	.sign_center{
		width:100%;
		position:absolute;
		top:1.08rem;
		box-sizing: border-box;
		margin-bottom:0.88rem;
	}
	.sign_center_topbox{
		width:100%;
		background-color:#FFFFFF;
		overflow: hidden;
		border-top:1px solid #FFFFFF;
		text-align: center;
	}
	#sign_center-top>img{
		width:0.2rem;
		height:0.26rem;
		margin-left:0.2rem;
	}
	#sign_center-top{
		margin-top:0.3rem;
		font-size:0.34rem;
		color:#333333;
	}
	#sign_center-top-nlv{
		margin-top:0.5rem;
		font-size:0.68rem;
		color:#D83515;
	}
	#sign_center-top-nlv>span{
		margin-left:0.2rem;
		font-size:0.26rem;
		color:#333333;
	}
	#investplan{
		font-size:0.3rem;
		text-align: center;
		margin-top:0.4rem;

	}
	#investplan>meter{
		margin:0 0.3rem;
		width:2.98rem;
		height: 0.16rem;
		margin-bottom:0.07rem;
	}
	#investplan>span:nth-of-type(2){
		color:#D83515;
	}
	#sign_center_top1{
		width:100%;
		margin-top:0.5rem;
		
	}
	#sign_center_top1>div{
		float:left;
		width:50%;
		text-align: center;
	}
	#sign_center_top1 div>div:nth-of-type(1){
		font-size:0.3rem;
		color:#333333;
	}
	#sign_center_top1>div:nth-of-type(1)>div:nth-of-type(2){
		font-size:0.26rem;
		color:#D83515;
		margin-top:0.2rem;
	}
	#sign_center_top1>div:nth-of-type(2)>div:nth-of-type(2){
		font-size:0.28rem;
		color:#FD8F00;
		margin-top:0.2rem;
	}
	#sign_center_top2{
		width:100%;
		height: 0.7rem;


		font-size:0.26rem;
	}
	#sign_center_top2>div{
		float:left;
		width:50%;
		height:0.7rem;
		text-align: center;
		line-height: 0.7rem;
		border-top:1px solid #333333;
		border-bottom:1px solid #333333;
		box-sizing: border-box;
		margin-top:0.3rem;
	}
	#sign_center_top2>div:nth-of-type(1){
		border-right:1px solid #333333;
		
	}
	#sign_center_top2>div>span{
		color:#FD8F00;
	}
	.sign_center_bottomul{
		width:100%;
		list-style: none;
		margin-top:0.2rem;
		
	}
	.sign_center_bottomul>li{
		width: 100%;
		height:0.88rem;
		border-bottom:1px solid #DcDcDc;
		background-color:#FFFFFF;
		font-size:0.32rem;
		position:relative;
		line-height: 0.88rem;
	}
	.sign_center_bottomul>li:nth-of-type(1){
		border-top:1px solid #DcDcDc;
	}
	.sign_center_bottomul>li>span{
		margin-left:0.24rem;
	}
	#sign_center_bottomulimg{
		width:0.17rem;
		height:0.3rem;
		position:absolute;
		right:0.24rem;
		top:0.29rem;
	}
	.signdetail_bottom{
		width:100%;
		height:0.88rem;
		text-align: center;
		line-height: 0.88rem;
		background-color:#fd4f4f;
		position: fixed;
		left:0;
		bottom:0;
		color:#FFFFFF;
		font-size:0.34rem;
	}
	.count_downwarp{
		height:1.16rem;
		width:100%;
		text-align: center;
		line-height: 1.16rem;
		font-size:0.26rem;
	}
	#count_downcnter>div{
		display: inline-block;
	}
	#count_downcnter>div:nth-of-type(2),#count_downcnter>div:nth-of-type(3),#count_downcnter>div:nth-of-type(4){
		width:0.48rem;
		height:0.56rem;
		background-color:#D83515;
		color:#FFFFFF;
		text-align: center;
		line-height: 0.56rem;
		margin-left:0.3rem;
	}
	#count_downcnter>div:nth-of-type(3),#count_downcnter>div:nth-of-type(4){
		margin-left:0;
	}
</style>