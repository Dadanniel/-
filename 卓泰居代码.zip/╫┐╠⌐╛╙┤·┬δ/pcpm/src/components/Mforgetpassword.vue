<template>
	<div class="registeredaccount">
		<topctfalse :dataname="dataname"></topctfalse>
		<div class="registwarp">
			<div id="registbox">
				手机号：<input type="text" placeholder="请输入您的手机号码" v-model="names"/>
			</div>
			<div id="registbox">
				验证码：<input type="text" placeholder="请输入短信验证码" v-model="codes"/>
				<button v-if="shows" @click="codebtn">获取验证码</button>
				<button v-else>{{limt}}后重新获取</button>
			</div>
			<div id="registbox">
				设置密码：<input type="text" placeholder="请输入一个长度为8~16的数字和字母组合的密码" v-model="password1"/>
			</div>
			<div id="registbox">
				确认密码：<input type="text" placeholder="再次确认您的登陆密码" v-model="password2"/>
			</div>
			<div id="registertn" @click="gohome">
				确定
			</div>
		</div>
	</div>
</template>

<script>
	import topctfalse from './topctfalse'
	import {md5} from "@/../static/plug/md5.js"
	import {MessageBox} from 'mint-ui';
	export default{
		data(){
			return{
				shows:true,
				limt:60,
				dataname:'忘记密码',
				names:"",//手机号码
				codes:'',
				password1:"",
				password2:""
			}
		},
		components:{
			topctfalse
		},
		methods:{
			gohome(){
					
		
				var re=/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/;
					if(this.names!==""){
						if(this.codes!==""){
							if(this.password1!==""&&this.password2!==""){
								if(re.test(this.password2)&&re.test(this.password2)){
									if(this.password1==this.password2){
										var passwords=md5(this.password2)
										this.$http.post(this.$url.URL+this.$url.URLPASSWORD,{
											mobile:this.names,
											password:passwords,
											sms_verify_code:this.codes
										})
										.then((response)=>{
											console.log(response)
											if(response.data.code=="0"){
												MessageBox("提示","修改密码成功")
												this.$router.go(-1)
											}else{
												MessageBox("提示",response.data.msg)
											}
										})
									}else{

										MessageBox("提示","两次密码输入不同")
									}
								}else{

									MessageBox("提示","密码格式不正确")
								}
							}else{

								MessageBox("提示","请输入密码")
							}
						}else{

							MessageBox("提示","请输入验证码")
						}
					}else{

						MessageBox("提示","请输入手机号码")
					}
			},
			codebtn(){
				var re=/^1\d{10}$/;
				if(this.names!==""){
					if(re.test(Number(this.names))){
						this.shows=false
						this.$http.post(this.$url.URLYZM,{
							mobile:this.names,
							name:this.names,
							type:"REST_PASSWORD"
						})
						.then((response)=>{
							console.log(response)
							var set = setInterval(()=>{
								this.limt--
								if(this.limt==-1){
									this.limt=60
									this.shows=true
									clearInterval(set)
								}
							},1000)
						})
					}else{
						MessageBox("提示","输入的手机号码不正确")
					}
				}else{
					MessageBox("提示","请输入手机号码")
				}
				
			}
		}
	}
</script>

<style scoped="scoped">
	.registwarp{
		width:92%;
		position:absolute;
		top:1.18rem;
		left:4%;
	}
	#registbox{
		height:0.88rem;
		line-height: 0.88rem;
		border-bottom:1px solid #333333;
		font-size:0.3rem;
		color:#333333;
		position:relative;
	}
	#registbox>input{
		width:70%;
		height:0.75rem;
		border:none;
		background-color:#F5F5F5;
		outline: none;
		z-index:2;
	}
	#registbox>button{
		position: absolute;
		width:2rem;
		height:0.46rem;
		font-size:0.26rem;
		text-align: center;
		line-height: 0.46rem;
		border:1px solid #D83515;
		color:#D83515;
		border-radius: 6px;
		z-index:3;
		top:0.22rem;
		right:0;
		background-color:#FFFFFF;
	}
	#registbox>button:active{
		background-color:#D83515;
		color:#FFFFFF;
	}
	#registertn{
		width:92%;
		height:0.8rem;
		border-radius: 6px;
		background-color:#Fc8E0D;
		
		margin:auto;
		margin-top:1.16rem;
		text-align: center;
		line-height: 0.8rem;
		font-size:0.34rem;
		color:#FFFFFF;
	}
</style>
