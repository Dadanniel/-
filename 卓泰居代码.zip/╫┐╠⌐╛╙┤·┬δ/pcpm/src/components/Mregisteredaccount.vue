<template>
	<div class="registeredaccount">
		<topctfalse :dataname="dataname"></topctfalse>
		<div class="registwarp">
			<div id="registbox">
				手机号：<input type="text" v-model="loginname" placeholder="请输入您的手机号码"/>
			</div>
			<div id="registbox">
				验证码：<input  type="text" v-model="authcode" placeholder="请输入短信验证码"/>
				<button v-if="moves" @click="gaincode" :disabled="gainbol">获取验证码</button>
				<button v-else>{{limit}}秒后重新获取</button>
			</div>
			<div id="registbox">
				邀请码：<input type="text" placeholder="输入好友手机号码/邀请码"/>
			</div>
			<div style="font-size:0.18rem;color:#DcDcDc;">有好友邀请码就填写，没有就暂时不填</div>
			<div id="registbox">
				设置密码：<input type="password" v-model="password1" placeholder="设置您的登录密码"/>
			</div>
			<div id="registbox">
				确认密码：<input @blur="password" type="password" v-model="password2" placeholder="再次确认您的登陆密码"/>
			</div>
			<div id="service">
				<input name="Fruit" type="radio" value="" /><span>我已阅读并同意</span>
				<router-link tag="span" to="/zhucexieyi">
				《注册协议》
				</router-link>

			</div>
			<div id="registertn" @click="register">
				注册
			</div>
		</div>
	</div>
</template>

<script>
	import topctfalse from './topctfalse'
	import {md5} from "@/../static/plug/md5.js"
	import { MessageBox } from 'mint-ui';
	export default{
		data(){
			return{
				moves:true,//注册按钮
				limit:5,
				dataname:'注册',
				loginname:"",
				authcode:'',
				gainbol:false,
				password1:"",
				password2:'',
				countdown:""
			}
		},
		created(){

		},	
		methods:{
			password(){
				if(this.password1!==this.password2){
					this.password2="",
					MessageBox('提示', '两次密码输入不相同，请重新输入');
				}
			},
			gaincode(){			
					var re=/^1\d{10}$/;
					
					if(this.loginname!==""){
						if(re.test(Number(this.loginname))){
							this.moves=false
							this.$http.post(this.$url.URLYZM, {
					    	mobile:this.loginname,
					    	type:'REGISTER'
						 	 })
						  	.then((response)=>{
						    	var set =setInterval(()=>{
						    		this.limit--
						    		if(this.limit==0){
						    			this.limit=5
										this.moves=true
										clearInterval(set)
						    		}
						    	},1000)
						  	})
						}else{
						MessageBox('提示', '手机号码不正确');							
						}
					}else{
						MessageBox('提示', '请填写手机号码');
					}	    		
			},
			register(){
			
				if(this.loginname==""){
					MessageBox('提示', '请输入手机号码');
				}else{
					if(this.authcode==""){
					MessageBox('提示', '请输入验证码');
					}else{
						if(this.password1==""&&this.password2==""){
							MessageBox('提示', '请输入密码');
						}else{
							if(this.password1==this.password2){										
							var passwords=md5(this.password2)		
							this.$http.post(this.$url.REGISTER, {
					    	mobile:this.loginname,
					    	password:passwords,
						    sms_verify_code:this.authcode
						 	 })
						  	.then((response)=>{
						  		console.log(response)
						    	if(response.data.code==0){
								MessageBox('提示', '注册成功');
						    		this.$router.push({name:'goashore'})
						    	}else{
						    		MessageBox('提示',response.data.msg);
						    	}
							})
							}else{
								MessageBox('提示', '两次输入密码不同请重新输入');
							}
						}
					}
				}
				
				
				
				
			}
		},
		components:{
			topctfalse
		}
	}
</script>

<style scoped="scoped">
	.registwarp{
		width:92%;
		position:absolute;
		top:1.18rem;
		left:4%;
	}
	#registbox{
		height:0.88rem;
		line-height: 0.88rem;
		border-bottom:1px solid #333333;
		font-size:0.3rem;
		color:#333333;
		position:relative;
	}
	#registbox>div{
		position:absolute;
		width:0.4rem;
		height:0.4rem;
		top:0.26rem;
		text-align: center;
		line-height: 0.4rem;
		right:1.6rem;
	}
	#registbox>input{
		width:70%;
		height:0.74rem;
		border:none;
		background-color:#F5F5F5;
		outline: none;
		z-index:2;
	}
	#registbox>button{
		position: absolute;
		width:2rem;
		height:0.46rem;
		font-size:0.26rem;
		text-align: center;
		line-height: 0.46rem;
		border:1px solid #D83515;
		color:#D83515;
		border-radius: 6px;
		z-index:3;
		top:0.22rem;
		right:0;
		background-color:#FFFFFF;
		margin: 0;
        padding: 0;

	}
	#registbox>button:active{
		background-color:#D83515;
		color:#FFFFFF;
		border:0px;
		margin: 0;
        padding: 0;
	}
	#service{
		font-size:0.24rem;
		margin-top:0.3rem;
	
	}
	#service>input{
		width:0.25rem;
		margin-right:0.1rem;
		vertical-align: middle;
		margin-left:0;
	}
	#service>span{
		vertical-align: middle;
	}
	#service>span:nth-of-type(2){
		color:#D83515;
	}
	#registertn{
		width:92%;
		height:0.8rem;
		border-radius: 6px;
		background-color:#Fc8E0D;
		
		margin:auto;
		margin-top:1.16rem;
		text-align: center;
		line-height: 0.8rem;
		font-size:0.34rem;
		color:#FFFFFF;
	}
</style>
