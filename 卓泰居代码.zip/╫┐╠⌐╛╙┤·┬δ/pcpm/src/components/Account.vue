<template>
	<div class="account">
		<div class="headname">
			<div id="headname_left">账户</div>
			<router-link tag="div" :to="{path:'/accountbills/'+deal_type}" id="headname_right" @click.native="authenmoves">
				交易账单
			</router-link>
		</div>
		<ul id="accountul">
			<router-link tag="li" to="/accountone" @click.native="baberbtn1"><div class="accountli" :class="{accountlis:accountlibol1}">我的投资</div><div :class="{accountsolid:solidbol1}"></div></router-link>
			<router-link tag="li" to="/accountthiree" @click.native="baberbtn3"><div class="accountli" :class="{accountlis:accountlibol3}">我的预投</div><div :class="{accountsolid:solidbol3}"></div></router-link>
			<router-link tag="li" to="/accounttwo" @click.native="baberbtn2"><div class="accountli" :class="{accountlis:accountlibol2}">我的借款</div><div :class="{accountsolid:solidbol2}"></div></router-link>
			
			<router-link tag="li" to="/accountfour" @click.native="baberbtn4"><div class="accountli" :class="{accountlis:accountlibol4}">债权转让</div><div :class="{accountsolid:solidbol4}"></div></router-link>
		</ul>
		<div class="accountucontent">
			<router-view></router-view>
		</div>
		<!--<popupbox :hint="hint"></popupbox>-->
	</div>
</template>

<script>
	import popupbox from'./Xpopupbox'
	export default{
		data(){
			return{
				deal_type:"我要投资"
			}
		},
		components:{
//			popupbox
		},
		computed:{
			accountlibol1(){
				return this.$store.state.accountlibol1
			},
			solidbol1(){
				return this.$store.state.solidbol1
			},
			accountlibol2(){
				return this.$store.state.accountlibol2
			},
			solidbol2(){
				return this.$store.state.solidbol2
			},
			accountlibol3(){
				return this.$store.state.accountlibol3
			},
			solidbol3(){
				return this.$store.state.solidbol3
			},
			accountlibol4(){
				return this.$store.state.accountlibol4
			},
			solidbol4(){
				return this.$store.state.solidbol4
			}
		},
		methods:{
			authenmoves(){
				this.$store.dispatch("authenmoves")
			},
			baberbtn1(){
				this.$store.dispatch("baberbtn1")
				this.deal_type="我的投资"
			},
			baberbtn2(){
				this.$store.dispatch("baberbtn2")
				this.deal_type="我的借款"
			},
			baberbtn3(){
				this.$store.dispatch("baberbtn3")
				this.deal_type="我的预投"
			},
			baberbtn4(){
				this.$store.dispatch("baberbtn4")
				this.deal_type="债权转让"
			}
		},
		mounted(){
		}
	}
</script>

<style scoped="scoped">
	#headname_right{
		font-size:0.24rem;
		top:0.3rem;
		color:#FFFFFF;
		right:0.24rem;
	}
	#accountul{
		position:fixed;
		top:0.88rem;
		width:100%;
		list-style: none;
		z-index:9999;
	}
	#accountul>li{
		float:left;
		height:0.8rem;
		width:25%;
		font-size:0.3rem;
		background-color:#FFFFFF;
		position:relative;
		border-bottom:none;
	}
	.accountli{
		width:100%;
		height:0.48rem;
		border-right:1px solid #999999;
		margin-top:0.16rem;
		text-align: center;
		line-height: 0.48rem;
	}
	#accountul>li:nth-of-type(4)>div{
		border-right:none;
	}
	.accountucontent{
		position:absolute;
		top:1.7rem;
		width:100%;
		height:100px;
	}
	.accountsolid{
		width:70%;
		height:0.8rem;
		position:absolute;
		top:0;
		left:15%;
		border-bottom:1px solid #D83515;
	}
	.accountlis{
		color:#D83515;
	}
</style>