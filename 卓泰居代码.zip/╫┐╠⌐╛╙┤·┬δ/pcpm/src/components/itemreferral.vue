<template>
	<div id="itemreferral">
		<div class="headname">
			<div @click="gobacktop2">
					<div class="headnamelist">
						<img src="../imgs/homeqietu/fanhui.png"/>
					</div>
			</div>
			<div id="headname_left">项目介绍</div>
		</div>
		<div class="itemreferral_textwarp">
			<div class="itemreferral_textbutton">项目介绍</div>
			<div class="itemreferral_textcenter">
				“全民金服”是一家专注于网络金融的互联网服务平台。平台秉承透明，安全稳健的原则，致力于为客户提供简易便捷，高效的服务，立足于房地产交易供应链。
			</div>
			<div class="itemreferral_textbutton">还款来源</div>
			<div class="itemreferral_textcenter">
				“全民金服”是一家专注于网络金融的互联网服务平台。平台秉承透明，安全稳健的原则，致力
			</div>
			<div class="itemreferral_textbutton">风控措施</div>
			<div class="itemreferral_textcenter">
				“全民金服”是一家专注于网络金融的互联网服务平台。平台秉承透明平台秉承透明，安全稳健的原则，致力于，安全稳健的原则，致力
			</div>
			<div class="itemreferral_textimg">
				<div></div>
				<div></div>
				<div></div>
			</div>
			<div class="itemreferral_textbutton">借款详情</div>
			<div class="itemreferral_textcenter">
				“全民金服”是一家专注于网络金融的互联网服务平台。平台秉承透明平台秉承透明，安全稳健的原则，致力于，安全稳健的原则，致力
			</div>
			<div class="itemreferral_textimg">
				<div></div>
				<div></div>
				<div></div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				
			}
		},
		computed:{
			
		},
		methods:{
			gobacktop2(){
				this.$router.go(-1)
			}
		},
		created(){
			var id= this.$route.params.id;
			
			this.$http.post(this.$url.PROJECT_SUMMARY,{
				project_id:id
			})
			.then((response)=>{
				console.log(response)
				this.data=response.data
				
			})
		}
	}
</script>

<style scoped="scoped">
	.headname{
		position:fixed;
		left:0;
		top:0;
	}
	.itemreferral_textwarp{
		width:100%;
		background-color:#f5f5f5;
		position:absolute;
		top:0.88rem;
	}
	.itemreferral_textbutton{
		margin-top:0.3rem;
		margin-left:0.24rem;
		width:1.6rem;
		height:0.5rem;
		text-align: center;
		line-height: 0.5rem;
		background-color:#FD8F00;
		color:#FFFFFF;
		font-size:0.3rem;
	}
	.itemreferral_textcenter{
		font-size:0.28rem;
		text-indent: 2em;
		margin-left:0.24rem;
		margin-right:0.24rem;
		margin-top:0.3rem;
		font-weight: bold;
	}
	.itemreferral_textimg{
		margin-left:0.24rem;
		margin-right:0.24rem;
		margin-top:0.3rem;
		overflow: hidden;
	}
	.itemreferral_textimg>div{
		float:left;
		width:2.24rem;
		height:2.24rem;
		background:gray;
	}
	.itemreferral_textimg>div:nth-of-type(2){
		margin:0 0.15rem;
	}
</style>