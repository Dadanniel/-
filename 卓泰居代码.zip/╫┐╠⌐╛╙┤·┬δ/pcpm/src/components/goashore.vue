<template>
	<div class="goashore">
		<div class="goimgs">
			<img src="../imgs/homeqietu/logo@2x.png"/>
		</div>
		<input id="gophone" @blur="changemovephon" type="text" placeholder="手机/用户名" v-model="names"/>
		<div id="gopasswordwarp">
			<input id="gopassword" type="password" v-model="passwords" v-show="passwordbol" placeholder="密码"/>
			<input id="gopassword" type="text" v-model="passwords" v-show="!passwordbol" placeholder="密码"/>
			<div class="gopassimg1" :class="{gopassimg:gopassbBol}" @click="clickpass"></div>
		</div>
		
		<div id="gobtnone" @click="debark">登陆</div>
		<div class="goashorerouter">
			<router-link tag="div" to="/registeredaccount">
				注册账户
			</router-link>
			<div>|</div>
			<router-link tag="div" to="/forgetpassword">
				忘记密码
			</router-link>
			
		</div>
		<div class="goashorebottom">
				<span>*新用户注册,立享10,000.00元好礼</span>
				<span @click="goretreat">取消登陆</span>
		</div>
	</div>
</template>

<script>
	 import {md5} from "@/../static/plug/md5.js"
	 import {MessageBox} from 'mint-ui';
	export default{
		data(){
			return{
				gopassbBol:false,
				passwordbol:true,
				passwords:"",
				names:"",
				data:""
			}
		},
		methods:{
			changemovephon(){
			},
			clickpass(){
				this.gopassbBol=!this.gopassbBol
				this.passwordbol=!this.passwordbol
			},
			debark(){				
				var passwords=md5(this.passwords)
				console.log(passwords)
				this.$http.post(this.$url.URL+this.$url.LOGIN,{
					username:this.names,
				    password:passwords	
				 	 })
				  	.then((response)=>{
				    	if(response.status==200){
				    		window.sessionStorage.token='JWT '+response.data.token//存储token
							console.log(window.sessionStorage.token)
				    		MessageBox("提示",'登录成功')			    		

				    		 this.$router.push({path:"/"})
				    		 this.$store.dispatch("gobacktop")
				    		 this.$store.dispatch('changeBg1')
							
							this.$http.get(this.$url.URL+this.$url.MY_INDEX_DATA,{headers:{"Authorization":window.sessionStorage.token}})
							.then((response)=>{
								window.sessionStorage.my_data=JSON.stringify(response.data)	//存储个人信息
							})
						
				    	}else{
				    		MessageBox("提示",'账号或密码错误')
				    	}
				  	}).catch(()=>{
				  		MessageBox("提示",'账号或密码错误')
				  	})
			},
			goretreat(){
				this.$router.push({path:"/"})
				this.$store.dispatch("gobacktop")
			}
		},
		//数据获取
	    created(){
	    			
	    }
	}
</script>

<style scoped="scoped">
	html,body{
		width:100%;
		height:100%;
	}
	.goashore{
		width:100%;
		text-align: center;
	}
	.goimgs{
		margin:auto;
		width:2.07rem;
		height:2.07rem;
		margin-top:1.02rem;

	}
	.goimgs>img{
		width:2.07rem;
		height:2.07rem;
		
	}
	#gophone{
		width:80%;
		height:0.68rem;
		margin-top:1.26rem;
		border:none;
		border-bottom:1px solid #333333;
		background-color:#F5F5F5;
		text-indent: 0.1rem;
		outline: none;

	}
	#gopassword{
		width:80%;
		height:0.68rem;
		margin-top:0.52rem;
		border:none;
		border-bottom:1px solid #333333;
		background-color:#F5F5F5;
		text-indent: 0.1rem;
		outline: none;
	}
	#gopasswordwarp{
		position: relative;
	}
	.gopassimg1{
		width:0.46rem;
		height:0.3rem;
		position:absolute;
		right:0.88rem;
		top:0.7rem;
		background:url(../imgs/homeqietu/yanjingyibi.png) no-repeat;
		background-size:0.46rem 0.3rem;
	}
	.gopassimg{
		background:url(../imgs/homeqietu/yanjingyizheng.png) no-repeat;
		background-size:0.46rem 0.3rem;
	}
	#gobtnone{
		margin:auto;
		width:80%;
		height:0.8rem;
		background-color:#Fc8E0D;
		margin-top:1.1rem;
		border-radius: 6px;
		text-align: center;
		line-height: 0.8rem;
		color:#FFFFFF;
		font-size:0.34rem;
	}
	.goashorerouter{
		width:80%;
		margin:auto;
		margin-top:0.4rem;
		font-size:0.28rem;
		color:#333333;
	}
	.goashorerouter>div{
		float:right;
		margin-left:0.1rem;
	}
	.goashorerouter>div:nth-of-type(2){
		margin-top:-0.02rem;
	}
	.goashorebottom{
		position:fixed;
		width:100%;
		bottom:0.3rem;
		
	}
	.goashorebottom>span:nth-of-type(1){
		float:left;
		font-size:0.28rem;
		margin-left:0.3rem;
		color:#D1D5D8
	}.goashorebottom>span:nth-of-type(2){
		float:right;
		font-size:0.3rem;
		color:blue;
		margin-right:0.3rem;
	}
</style>