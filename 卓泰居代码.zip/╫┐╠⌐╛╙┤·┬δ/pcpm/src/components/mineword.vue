<template>
	<div class="mineword">
		<topct :dataname="dataname"></topct>
		<ul class="wordwarp_ul">
			<li v-for="item in data">
				<div>{{item.time.split("T")[0]}}</div>
				<div class="wordwarp_liwarp">
					<div v-show="item.status"></div>
					<div>投资成功</div>
					<div> {{item.content}}</div>
					<div><a :href="item.url">{{item.url}}</a></div>
				</div>
			</li>
			
		</ul>
			
	</div>
</template>

<script>
	import topct from '@/components/topct'

	export default{
		data(){
			return{
				dataname:"消息",
				data:""
			}
		},
		created(){
			this.$http.get("api/message/message/")
			.then((response)=>{
				this.data=response.data.results
				console.log(this.data)
			})
		},
		components:{
			topct
		},
		methods:{

		},
		mounted(){
		
			
		}
		
	}
</script>

<style>
	.wordwarp_ul{
		width:94%;
		position:absolute;
		top:0.88rem;
		left:3%;
	}
	.wordwarp_ul>li{
		width:100%;
		
	}
	.wordwarp_ul>li>div:nth-of-type(1){
		width:100%;
		text-align: center;
		padding-top:0.2rem;
		padding-bottom:0.2rem;
		font-size:0.22rem;
		color:#666666;
	}
	.wordwarp_liwarp{
		width:100%;
		background-color:#FFFFFF;
		border-radius: 6px;
		position:relative;
	}
	.wordwarp_liwarp>div:nth-of-type(1){
		width:0.2rem;
		height:0.2rem;
		background-color:#D83515;
		position:absolute;
		top:-0.08rem;
		left:-0.08rem;
		border-radius: 50%;
	}
	.wordwarp_liwarp>div:nth-of-type(2){
		font-size:0.32rem;
		color:#333333;
		padding-top:0.3rem;
		padding-bottom:0.3rem;
		margin-left:0.2rem;
	}
	.wordwarp_liwarp>div:nth-of-type(3){
		font-size:0.26rem;
		color:#666666;
		padding-left:0.2rem;
		padding-right:0.2rem;
	}
	.wordwarp_liwarp>div:nth-of-type(4){
		font-size:0.26rem;
		padding-left:0.2rem;
		padding-right:0.2rem;
		padding-bottom:0.3rem;
	}
</style>