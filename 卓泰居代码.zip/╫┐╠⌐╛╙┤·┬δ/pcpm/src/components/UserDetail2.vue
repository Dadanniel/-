<template>
	<div>
		banner2
	</div>
</template>

<script>
</script>

<style>
</style>