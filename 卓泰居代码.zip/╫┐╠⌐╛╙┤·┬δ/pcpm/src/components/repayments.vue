<template>
	<div>
		<topct :dataname="dataname"></topct>
		<div class="repaycenter">
			<ul>
				<li v-for="(item,index) in list">
					<div id="repaytop">
						<div :class="{xbsd_box_div1:'置家袋'==item.project_type,xbsd_box_div2:'赎楼贷'==item.project_type,xbsd_box_div3:'债权转让'==item.project_type,xbsd_box_div4:'体验区'==item.project_type,xbsd_box_div5:'抵押标'==item.project_type}" class="xbsd_box_div">{{item.project_type}}</div>
						<div>{{item.name}}</div>
					</div>
					<div id="repaymoni">
						<div id="repaymonileft">
							<div>借款总额</div>
							<div>{{item.amount}}</div>
						</div>
						<div id="repaymonicenter">
							<div>已还金额</div>
							<div>{{item.repay_amount}}</div>
						</div>
						<div id="repaymoniright">
							<div>还款方式</div>
							<div>{{item.repay_type}}</div>
						</div>
					</div>
					<div id="repayskipwarp">
						<div>
							<div>本期应还 :</div>
							<div>{{item.plan_repay}}元</div>
						</div>
						<div>
							<div>本期已还 :</div>
							<div>{{item.real_repay}}元</div>
						</div>
						<div>
							<div>最迟还款日 :</div>
							<div>{{item.deadline}}</div>
						</div>
						<router-link tag="div" to="/repayment" class="repaymentbnt">
							还款
						</router-link>
					</div>
					<div id="periods">
						<div>期数</div>
						<div>应还<span>(元)</span></div>
						<div>已还 <span>(元)</span></div>
						<div>未还 <span>(元)</span></div>
						<div>还款状态</div>
					</div>
					<ul>
						<li id="periodsul" v-for="items in item.issue">
						<div>第{{items.issue_num}}期</div>
						<div>{{items.plan_repay}}</div>
						<div>{{items.real_repay}}</div>
						<div>{{items.no_repay}}</div>
						<div>{{items.status}}</div>
						</li>
					</ul>	
	
					<div id="periodsli">
						<div>查看还款详情</div>
					</div>
				</li>				
			</ul>
			
		</div>
		
	</div>
	
</template>

<script>
	import topct from '@/components/topct'
	export default{
		data(){
			return{
				dataname:"还款通道",
				list:'',
				token:window.sessionStorage.token
			}
		},
		created(){
			this.$http.post(this.$url.URL+this.$url.REPAY_ACCESS,{},{
				 headers: {
                  Authorization:this.token
                }
			})
			.then((response)=>{
				this.list = response.data.project_dict_list
				console.log(response)
				for(var i=0; i<this.list.length;i++){
					if(this.list[i].project_type=="ZLD"){
						this.list[i].project_type="置楼贷"
					}
					if(this.list[i].project_type=="SLD"){
						this.list[i].project_type="赎楼贷"
					}
					if(this.list[i].project_type=="ZJD"){
						this.list[i].project_type="置家贷"
					}
				}
			})
		},
		components:{
			topct
	}
	}
</script>

<style scoped="scoped">
	html,body{
		z-index:0
	}
	.repaycenter>ul{
		list-style: none;
		width:100%;
	}
	.repaycenter>ul>li{
		width:100%;
		margin-top:0.1rem;
	}
	.repaycenter>ul>li:nth-of-type(1){
		margin-top:0;
	}
	.repaycenter{
		position:absolute;
		top:0.98rem;
		width:100%;
		z-index:2;
	}
	#repaytop{
		width:100%;
		height:0.88rem;
		background-color:#FFFFFF;
		line-height: 0.88rem;
	}
	
	.xbsd_box_div{
		width:0.44rem;
		height:0.28rem;
		font-size:0.16rem;
		background-color:green;
		border-radius: 2px;
		text-align: center;
		line-height: 0.28rem;
		color:#FFFFFF;
		margin-top:0.3rem;
		margin-left:0.24rem;
		float:left;
	}
	.xbsd_box_div1{
		background-color:red;
	}
	.xbsd_box_div2{
		background-color:yellow;
	}
	.xbsd_box_div3{
		background-color:beige;
	}
	.xbsd_box_div4{
		background-color:black;
	}
	.xbsd_box_div5{
		background-color:blue;
		
	}
	@media(min-width:300px)and (max-width: 400px) {
    	.xbsd_box_div{
		font-size:12px;
		height:14px;
		width:26px;
		line-height: 14px;
		margin-top:0.26rem;
	}
	}
	#repaytop>div:nth-of-type(2){
		font-size:0.32rem;
		margin-left:0.2rem;
		float:left;
	}
	#repaymoni{
		width:100%;
		height:1.42rem;
		border-top:1px solid #F5F5F5;
		background-color:#FFFFFF;
	}
	#repaymoni>div{
		width:33.333333%;
		height:1.42rem;
		float:left;
		text-align: center;
	}
	#repaymoni>div>div:nth-of-type(1){
		font-size:0.3rem;
		color:#333333;
		margin-top:0.3rem;
	}
	#repaymoni>div>div:nth-of-type(2){
		font-size:0.26rem;
		color:#FD8F00;
		margin-top:0.2rem;
	}
	#repayskipwarp{
		width:100%;
		height:2rem;
		border-top:1px solid #F5F5F5;
		background-color:#FFFFFF;
		position:relative;
	}
	#repayskipwarp>div{
		font-size:0.3rem;
		margin-left:0.4rem;
		margin-top:0.22rem;
	}
	#repayskipwarp>div>div{
		display: inline-block;
		
	}
	#repayskipwarp>div>div:nth-of-type(2){
		margin-left:0.2rem;
		color:#D83515;
	}
	.repaymentbnt{
		width:2rem;
		height:0.66rem;
		border-radius: 6px;
		background-color:#D83515;
		position:absolute;
		top:0.4rem;
		right:0.6rem;
		text-align: center;
		line-height: 0.66rem;
		color:#FFFFFF;
		font-size:0.3rem;
		z-index:999;
		
	}
	#periods{
		width:100%;
		height: 0.7rem;
		background-color:#d8d7d7;
		
	}
	#periods>div{
		width:20%;
		height:0.7rem;
		text-align: center;
		line-height: 0.7rem;
		float:left;
		font-size:0.28rem;
	}
	#periods>div>span{
		font-size:0.22rem;
	}
	#periodsul{
		width:100%;
		height: 0.7rem;
		background-color:#d8d7d7;
		list-style: none;
		background-color:#FFFFFF;
		border-bottom: 1px solid #F5F5F5;
	}
	#periodsul>div{
		width:20%;
		height:0.7rem;
		text-align: center;
		line-height: 0.7rem;
		float:left;
		font-size:0.28rem;
	}
	
	#periodsli{
		width:100%;
		height:0.7rem;
		background-color:#FFFFFF;
		border: 1px solid #FFFFFF;
		box-sizing: border-box;
	}
	#periodsli>div{
		width:1.96rem;
		font-size:0.24rem;
		color:#D83515;
		margin:0 auto;
		/*height:0.7rem;*/
		line-height: 0.7rem;
		background:url(../imgs/homeqietu/chakangengduo.png) no-repeat;
		background-size:0.24rem 0.22rem;
		background-position:1.72rem 0.24rem;
	}
</style>