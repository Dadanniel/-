<template>
	<div class="Minepersonal">
		<div class="headname">
			<div>
				<div class="headnamelist"><img @click="gomine" src="../imgs/homeqietu/fanhui.png"/></div>
			</div>
			<div id="headname_left">个人中心</div>
		</div>
		<div class="Mineperwarp">
			<ul>
				<li class='Mineperwarpli'>
					<div>头像</div>
					<div>
						<img :src="srcimg" alt="" />
					</div>
					<router-link tag="div" to="/Minechangehead">
						<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
					</router-link>

				</li>
				<li class='Mineperwarpli2'>
					<div>用户名</div>
					<div>
						{{my_data.member_name}}
					</div>
					<router-link tag="div" to="/Minechangeaccout">
						<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
					</router-link>
				</li>
				<li class='Mineperwarpli'>
					<div>二维码</div>
					<div style="border-radius: 0;">
				
						<img src="../imgs/mineimgs/erweimathree.png" alt="" />
					</div>
		
					<router-link tag="div" to="/Minetwocode">
						<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
					</router-link>
		
				</li>
				<li class='Mineperwarpli2'>
					<div>更换手机号码</div>
					<div>
						{{my_data.mobile}}
					</div>
					<router-link tag="div" to="/Mineremovephone">
						<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
					</router-link>
				</li>

			</ul>
		</div>
	</div>
</template>

<script>
	import topct from './topct'
	export default{
		data(){
			return{
				srcimg:window.localStorage.headimg,
				my_data:'',
			}
		},
		created(){
			this.my_data=JSON.parse(window.sessionStorage.my_data)
		},
		computed:{
			changename(){
				return this.$store.state.changename
			}
		},
		methods:{
			gomine(){
				this.$store.dispatch("gobacktop")
				this.$router.push({path:"Mine"})
			}
		},
		components:{
			topct
		}
	}
</script>

<style scoped="scoped">
	.Mineperwarp{
		width:100%;
		position:absolute;
		top:1.08rem;
	}
	.Mineperwarp>ul{
		width:100%;
		list-style: none;
	}
	.Mineperwarp>ul>li{
		width:100%;
		height:1.1rem;
		position:relative;
		border-top: 1px solid #dcdcdc;
		background-color:#FFFFFF;
		line-height: 1.1rem;
		text-indent: 0.24rem;
	}
	.Mineperwarpli>div:nth-of-type(1){
		font-size:0.33rem;
		text-indent: 0.24rem;
	}
	.Mineperwarpli>div:nth-of-type(2){
		width:0.7rem;
		height:0.7rem;
		border-radius: 50%;
		position:absolute;
		top:0.2rem;
		right:0.61rem;
		overflow:hidden;
		
	}
	.Mineperwarpli>div:nth-of-type(2)>img{
		width:0.7rem;
		height:0.7rem;
		position:absolute;
		top:0;
		left:0;
		}
	.Mineperwarpli>div:nth-of-type(3){
		position:absolute;
		width:0.17rem;
		height:0.3rem;
		right:0.24rem;
		top:0.4rem;
	}
	.Mineperwarpli>div:nth-of-type(3)>img{
		position:absolute;
		width:0.17rem;
		height:0.3rem;
		right:0rem;
		top:0em;
	}
	.Mineperwarpli2>div:nth-of-type(3){
		position:absolute;
		width:0.17rem;
		height:0.3rem;
		right:0.24rem;
		top:0.4rem;
	}
	.Mineperwarpli2>div:nth-of-type(3)>img{
		position:absolute;
		width:0.17rem;
		height:0.3rem;
		right:0rem;
		top:0em;
	}
	.Mineperwarpli2>div:nth-of-type(1){
		font-size:0.33rem;
		text-indent: 0.24rem;
	}
	.Mineperwarpli2>div:nth-of-type(2){
		position:absolute;
		right:0.61rem;
		z-index: 9999;
		font-size:0.26rem;
		color:#666666;
		top:0
	}
</style>