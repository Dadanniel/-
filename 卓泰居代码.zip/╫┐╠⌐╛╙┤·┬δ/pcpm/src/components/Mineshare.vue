<template>
	<div class="Mineshare">
		<!--<topct :dataname="dataname"></topct>-->
		你好
	</div>
</template>

<script>
//	import topct from'./topct'
	export default{
		data(){
			return{
				dataname:"绑定银行卡"
			}
		}
	}
</script>

<style>
</style>