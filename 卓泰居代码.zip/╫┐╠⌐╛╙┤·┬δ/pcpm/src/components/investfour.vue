<template>
	<div class="investone">
		<invesitem :invesid="invesid"></invesitem>
	</div>
</template>

<script>
	import invesitem from './invesitem'
	export default{
		data(){
			return{
				invesid:"4"
			}
		},
		components:{
			invesitem
		}
	}
</script>

<style scoped="scoped">
	.investone{
		width:100%;
		position:absolute;
		top:0.88rem;
		height:100%;
	}
</style>