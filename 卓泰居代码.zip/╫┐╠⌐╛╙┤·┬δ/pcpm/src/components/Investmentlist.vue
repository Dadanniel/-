<template>
	<div id="Investmentlist">
		<div class="headname">
			<div @click="gobacktop">
				<div class="headnamelist">
					<img src="../imgs/homeqietu/fanhui.png"/>
				</div>
			</div>	
			<div id="headname_left">投资列表</div>
		</div>
		<div id="Investmentlistultext">
			<div id="Investmentlistuldiv">
				<div>用户名</div>
				<div>年利率<span>(%)</span></div>
				<div>投资金额<span>(元)</span></div>
				<div>投资时间</div>
			</div>
			<ul id="Investmentlistul">
			
				<li v-for="item in datalist">
					<div>{{item.member_name}}</div>
					<div>{{item.rate}}%</div>
					<div>{{item.amount}}</div>
					<div>{{item.time}}</div>
				</li>
				
			</ul>
		</div>
			

		
	</div>
</template>

<script>
	export default{
		data(){
			return{
				datalist:''
			}
		},
		created(){
			var id= this.$route.params.id;
			
			this.$http.post(this.$url.INVESTMENT_LIST,{
				project_id:id
			})
			.then((response)=>{
				console.log(response.data.investment_list)
				this.datalist=response.data.investment_list
				
			})
		},
		computed:{
			
		},
		methods:{
			gobacktop(){
				this.$router.go(-1)
			}
		}
	}
</script>

<style>
	body{
	}
	.headname{
		position:fixed;
		left:0;
		top:0;
	}
	#Investmentlistultext{
		margin-top:0.88rem;
	}
	#Investmentlistul{
		width:100%;
		list-style: none;
		background-color:#FFFFFF;
		margin:0 auto;
		position:absolute;
	}
	#Investmentlistul>li{
		width:100%;
		height:0.76rem;
		text-align: center;
		line-height: 0.76rem;
		margin:auto;
		border-bottom:1px solid #DcDcDc;
	}
	#Investmentlistul>li>div{
		float:left;
		font-size:0.32rem;
	}

	#Investmentlistul>li>div:nth-of-type(1){
		width:20%;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
		
	}
	#Investmentlistul>li>div:nth-of-type(2){
		width:25%;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
	}
	#Investmentlistul>li>div:nth-of-type(3){
		width:30%;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
	}
	#Investmentlistul>li>div:nth-of-type(4){
		width:25%;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
		
	}
	#Investmentlistuldiv{
		height:0.76rem;
		font-size:0.32rem;
		line-height: 0.76rem;
	}
	#Investmentlistuldiv>div>span{
		font-size:0.24rem
	}
	#Investmentlistuldiv>div{
		float:left;
		text-align: center;
	}
	#Investmentlistuldiv>div:nth-of-type(1){
		width:20%;
		
	}
	#Investmentlistuldiv>div:nth-of-type(2){
		width:25%
	}
	#Investmentlistuldiv>div:nth-of-type(3){
		width:30%
	}
	#Investmentlistuldiv>div:nth-of-type(4){
		width:25%;
		
	}
</style>