<template>
	<div class="alert">
		<div class="alertbox">
			<button class='btn' @click="btn">确定</button>
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				
			}
		},
		methods:{
			btn(){
				this.$router.push("/")
			}
		}
	}
</script>

<style scoped="scoped">
	.alert{
		width:100%;
		height:100%;
		background:rgba(1,1,1,0.3);
		position: fixed;
	}
	.alertbox{
		width:60%;
		height:50%;
		margin:30% auto;
		background-color:#FFFFFF;
		border-radius: 6px;
		position:relative;
		text-align: center;
	}
	.btn{
		width:30%;
		height:40px;
		background-color:#005DE6;
		color:#FFFFFF;
		position:absolute;
		bottom:0.3rem;
		right:0.2rem;
		border:none;
		border-radius: 4px;
		outline: none;
	}
	
</style>