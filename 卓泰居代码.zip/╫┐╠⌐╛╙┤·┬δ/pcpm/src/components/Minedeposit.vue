<template>
	<div class="Minedeposit">
		<topct :dataname="dataname"></topct>
		<div class="minedepositliwarp">
			<ul id="minedepositli">
				<li><p>提现额度</p>
					<input type="text" v-model="money"/>
				</li>
			</ul>
			<div>预计提钱到帐时间 24 小时内</div>
			<div>
				<form id="form3" :action="gourl" method="post">
					<input type="" v-show="move" name="WithdrawMoneymoremore" id="" :value="my_data.deposit_id" />
					<input type="" v-show="move" name="PlatformMoneymoremore" id="" :value="p"/>
					<input type="" v-show="move" name="OrderNo" id="RealName" :value="order_no"/>
					<input type="" v-show="move" name="Amount"  :value="money" />
					<input type="" v-show="move" name="CardNo" id="RechargeType" :value="my_data.bank_card_rsa"/>					
					<input type="" v-show="move" name="CardType" id="FeeType" :value="my_data.is_credit_card"/>
					<input type="" v-show="move" name="BankCode" id="FeeType" :value="my_data.bank_code"/>
					<input type="" v-show="move" name="Province" id="FeeType" :value="my_data.province_code"/>
					<input type="" v-show="move" name="City" id="FeeType" :value="my_data.city_code"/>
					<input type="" v-show="move" name="ReturnURL" id="IdentificationNo" :value="returnurl"/>
					<input type="" v-show="move" name="NotifyURL" id="" :value="resul"/>
					<input type="" v-show="move" name="SignInfo" id="SignInfo" :value="Notifysurl"/>
          
					<input class="submitbtn" type="button" @click="btnsubmots" value="确定提现"/>
				</form>
			</div>
		</div>
	</div>
</template>

<script>
import topct from "./topct";
import { MessageBox } from 'mint-ui';
export default {
  data() {
    return {
      move: false,
      dataname: "提现",
      my_data: "", //个人信息
      p:"", //平台乾多多标识
      resul: "", //后台通知网址
      returnurl: "", //钱多多前台通知网址
      money: "", //充值金额
      order_no: "", //平台的提现订单号
      Notifysurl: "", //秘钥
	  gourl: "", //钱多多多提现页面
	  token:window.sessionStorage.token
    };
  },
  created() {
	this.my_data = JSON.parse(window.sessionStorage.my_data)//个人资料
	this.gourl = this.$url.MONEYNFOUR;
	this.p=window.sessionStorage.p
    this.returnurl = this.$url.URL+this.$url.PAYRETURN;//钱多多前台通知网址
    this.resul =this.$url.QIANDUODUO +JSON.parse(window.sessionStorage.overall).RECHARGE_CALLBACK; //提现接口
  },
  methods: {
    btnsubmots() {
      var reg = /^[0-9]+.?[0-9]*$/;
      if (this.money !== "" && reg.test(this.money)) {
        if (Number(this.money) <= Number(this.my_data.available_remain)) {
          this.$http.post(
              this.$url.URL + this.$url.MONEY_IN_OUT,
              {
                //充值提现获取订单号
                type: "REcHARGE",
                amount: this.money
              },
              { headers: { Authorization:this.token } }
            )
            .then(response => {
              this.order_no = response.data.order_no;
              var str=this.my_data.deposit_id+this.p+this.order_no+this.money+this.my_data.bank_card_no+this.my_data.is_credit_card+this.my_data.bank_code+this.my_data.province_code+this.my_data.city_code+this.returnurl+this.resul
              console.log(str)
              this.$http.post(this.$url.URL + this.$url.SIGNATURE, {
                  //获取秘钥接口
                  str: str
                })
                .then((response) => {
                  this.Notifysurl = response.data.result;
                  
                  if (response.status == "200" && this.Notifysurl !== "") {
                   MessageBox.confirm('是否前往充值页面?').then(action => {
						form3.submit()
					});
                  }
                });
            })
            .catch(() => {
              MessageBox('提示','请重新输入金额')
            });
        } else {
          MessageBox('提示','您输入的金额大于你账户的总余额请重新输入')
          this.money = "";
        }
      } else {
        this.money = "";
        MessageBox('提示','请输入提现金额(只能为数字)')
      }
    }
  },
  components: {
    topct
  }
};
</script>

<style scoped="scoped">
html,
body {
  height: 100%;
}
* {
  margin: 0;
  padding: 0;
}
.minedepositliwarp {
  width: 100%;
  position: absolute;
  top: 1.08rem;
}
#minedepositli {
  list-style: none;
  width: 100%;
}
#minedepositli > li {
  width: 100%;
  height: 0.88rem;
  background-color: #ffffff;
  line-height: 0.88rem;
  position: relative;
  margin-bottom: 0.2rem;
  font-size: 0.32rem;
}
#minedepositli > li > p {
  display: inline-block;
}
#minedepositli > li > p:nth-of-type(1) {
  margin-left: 0.24rem;
}
#minedepositli > li > input {
  width: 70%;
  outline: none;
  border: none;
  margin-left: 0.24rem;
}
.minedepositliwarp > div:nth-of-type(1) {
  font-size: 0.26rem;
  color: #666666;
  margin-left: 0.24rem;
}
.minedepositliwarp > div:nth-of-type(2) {
  width: 6.84rem;
  height: 0.8rem;
  background-color: #Fc8E0D;
  color: #ffffff;
  font-size: 0.34rem;
  text-align: center;
  line-height: 0.8rem;
  margin: auto;
  margin-top: 2rem;
  border-radius: 6px;
}
.submitbtn {
  width: 100%;
  height: 100%;
  background-color: #Fc8E0D;
  border: none;
  outline: none;
  color: #ffffff;
}
</style>