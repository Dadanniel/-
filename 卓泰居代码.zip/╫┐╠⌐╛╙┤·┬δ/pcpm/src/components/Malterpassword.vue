<template>
	<div class="Malterpassword">
		<topctfalse :dataname="dataname"></topctfalse>
		<div class="passwordboxs">
			<div>旧密码</div>
			<input type="text" placeholder="请输入旧密码" v-model="passwordone"/>
			<div>设置新的密码</div>
			<input type="text" placeholder="8-16位，至少包含数字，字母" v-model="passwordtwo"/>
			<div>再次输入新密码</div>
			<input type="text" placeholder="再次确认您的登录密码" v-model="passwordthree"/>
			<div id="outmsetbtn" @click="goashorebtn">
				确认
			</div>
		</div>
		
	</div>
</template>

<script>
    import topctfalse from './topctfalse'
    import { MessageBox } from 'mint-ui';
    import {md5} from "@/../static/plug/md5.js"
	export default{
		data(){
			return{
				dataname:"修改登录密码",
				passwordone:"",
				passwordtwo:"",
                passwordthree:"",
                token:window.sessionStorage.token
			}
		},
		components:{
			topctfalse
		},
		methods:{
			goashorebtn(){
				if(this.passwordone==""){
                    MessageBox('提示', '请输入旧密码');

				}else{
					if(this.passwordtwo==""||this.passwordthree==""){
                        MessageBox('提示', '请输入新密码');				
					}else{
						var re=/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/;
						if(re.test(this.passwordtwo)&&re.test(this.passwordthree)){
							if(this.passwordtwo==this.passwordthree){
								var passwordones=md5(this.passwordone)
                                var passwords=md5(this.passwordthree)
                                var paprams4 = {
                                    old_password: passwordones,
                                    new_password: passwords
                                };
								this.$http.put(this.$url.URL+this.$url.MODIFY_PASSWORD,paprams4,{
                                 headers: { Authorization:this.token}
                                })
								.then((response)=>{
                                        MessageBox('提示', '已经修改密码');
                                })
                                .catch((esl)=>{
                                     MessageBox('提示',esl.old_password[0]);
                                })
							}else{
                                MessageBox('提示', "两次密码输入不同请重新输入");
								this.passwordthree=""
							}
						}else{
                             MessageBox('提示', "密码必须为8~16位的数字和字母组合");
						}
						
					}
				}
			}
		}
	}
</script>

<style scoped="scoped">
	html,body{
		width:100%;
		height:100%;
	}
	.passwordboxs{
		width:100%;
		position:absolute;
		top:0.88rem;
	}
	.passwordboxs>div{
		float:left;
		font-size:0.3rem;
		margin-top:0.3rem;
		margin-bottom:0.2rem;
		margin-left:0.24rem;
	}
	.passwordboxs>input{
		float:left;
		width:100%;
		height:0.88rem;
		text-indent: 0.24rem;
		border:none;
		outline: none;

	}
	#outmsetbtn{
		width:6.85rem;
		height:0.8rem;
		background-color:#Fc8E0D;
		margin-left:0.325rem;
		margin-top:2rem;
		border-radius: 6px;
		text-align: center;
		line-height: 0.8rem;
		font-size:0.34rem;
		color:#FFFFFF;
		
	}
</style>