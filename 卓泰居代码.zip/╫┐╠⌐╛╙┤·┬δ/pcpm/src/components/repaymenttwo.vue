<template>
	<div class="repament">
		<div class="headname">
			<div @click="repamentto">
				<div class="headnamelist"><img src="../imgs/homeqietu/fanhui.png"/></div>
			</div>
			<div id="headname_left">还款</div>
		</div>
		<div class="refundcenter">
			<div class="rfd_way" @click="bottommove=!bottommove">
				<div >还款方式</div>
				<div><img src="../imgs/homeqietu/shiliangzhinengkaob.png"/></div>
			    <div>{{huankuanfs}}</div>
			</div>
			<div id="explaindss">
				<div>可选择本期还款, 提前还清余额还款方式</div>
			</div>
			<div class="rfd_way" style="margin-top:0;font-size:0.26rem;">
				<div>第三方资金安全托管</div>
			</div>
			<div class="rfd_way" style="margin-top:0;">
				<div >到帐时间</div>				
			    <div style="margin-right: 0.24rem;">24小时之内</div>
			</div>
			<div class="rfd_way" style="margin-top:0;">
				<div >还款金额</div>				
			   	<span style="margin-left:0.2rem;color:#Fc8E0D;">{{moneyitem}}</span>
			</div>
			<form id="form1" :action="gourl" method="post">
				<input type="" v-show="move" name="LoanJsonList" id="" :value="encold" />
				<input type="" v-show="move" name="PlatformMoneymoremore" id="" :value="p"/>
				<input type="" v-show="move" name="TransferAction" id="" value="2"/>
				<input type="" v-show="move" name="Action" id="" value="1"/>
				<input type="" v-show="move" name="TransferType" id="" value="2"/>
				<input type="" v-show="move" name="NeedAudit" id="" value="1"/>
				<input type="" v-show="move" name="ReturnURL" id="IdentificationNo" :value="returnurl" />
				<input type="" v-show="move" name="NotifyURL" id="" :value="resul"/>
				<input type="" v-show="move" name="SignInfo" id="SignInfo" :value="Notifysurl"/>
				<input id="btnBotom" type="button" @click="getPayDetail()"  value="还款"/>
			</form>		
		</div>
		<div id="bottonbtn" v-show="bottommove">
			<div v-for="(item,index) in huankanfangs" @click="bottombtn(item,index)">{{item}}</div>
		</div>
	</div>
		
</template>

<script>
import { MessageBox } from "mint-ui";
export default {
  data() {
    return {
      move: false,
      huankuanfs: "本期还款",
      huankanfangs: ["本期还款", "提前还款", "取消"],
      bottommove: false,
      token: window.sessionStorage.token, //touken
      dataitem: JSON.parse(window.sessionStorage.authitem), //项目信息
      datamoney: "", //金额
      moneyitem: "", //显示的金额

      myindexdata: JSON.parse(window.sessionStorage.my_data), //个人资料
      p: window.sessionStorage.p, //平台乾多多标识
      returnurl: "", //钱多多前端通知网址
      resul: "", //转账后台接口
      LoanJsonList: [], //转账列表没有encode
      encold: [], //转账列表encode过的
      Notifysurl: "", //秘钥
      gourl: "" //乾多多还款接口
    };
  },
  created() {
    this._repaymoney(); //获取还账金额
    this.returnurl = this.$url.URL + this.$url.PAYRETURN; //钱多多前端通知网址
    this.resul =
      this.$url.QIANDUODUO +
      JSON.parse(window.sessionStorage.overall).TRANSFER_CALLBACK; //转账后台接口
    this.gourl = this.$url.MONEYNFIVE;
  },
  methods: {
    _repaymoney() {
      this.$http
        .post(
          this.$url.URL + this.$url.REPAY_AMOUNT,
          {
            project_id: this.dataitem.id
          },
          { headers: { Authorization: this.token } }
        )
        .then(response => {
          this.datamoney = response.data;
          this.moneyitem = this.datamoney.current;
          console.log(this.datamoney);
        });
    },
    repamentto() {
      this.$router.go(-1);
      this.$store.dispatch("gobacktop");
    },
    bottombtn(item, index) {
      //选项
      this.bottommove = !this.bottommove;
      if (index == "0") {
        this.moneyitem = this.datamoney.current;
      } else if (index == "1") {
        this.moneyitem = this.datamoney.all;
      }
      if (item !== "取消") {
        this.huankuanfs = item;
      }
    },
    getPayDetail() {
      //乾多多跳转
      let id = this.dataitem.id;
      this.LoanJsonList = []; //点击前先让转账列表变为空
      var urls = "";
      var urld = "";
      if (this.huankuanfs == "本期还款") {
        var urls = {
          project_id: id,
          type: "",
          amount: this.moneyitem
        };
        var urld = this.$url.PAY_REPAY;
      } else {
        var urls = {
          project_id: id,
          type: "ALL",
          amount: this.moneyitem
        };
        var urld = this.$url.ADPAY_REPAY;
      }

      if (
        parseFloat(this.myindexdata.available_remain) >=
        parseFloat(this.moneyitem)
      ) {
        this.$http
          .post(this.$url.URL + urld, urls, {
            headers: { Authorization: this.token }
          })
          .then(response => {
            console.log(response);
            let list = response.data.LoanJsonList;
            if (list !== undefined) {
              for (let i = 0; i < list.length; i++) {
                if (list[i].SecondaryJsonList.length > 0) {
                  list[i].SecondaryJsonList = JSON.stringify(
                    list[i].SecondaryJsonList
                  );
                } else {
                  delete list[i].SecondaryJsonList;
                }
                this.LoanJsonList.push(list[i]);
              }
              this.LoanJsonList = JSON.stringify(this.LoanJsonList);
              this.$http
                .post(this.$url.URL + this.$url.ENCODEURL, {
                  data: this.LoanJsonList
                })
                .then(response => {
                  this.encold = response.data.data;
                });

              console.log(this.LoanJsonList);
              let str =
                this.LoanJsonList +
                this.p +
                "2121" +
                this.returnurl +
                this.resul;
              this.$http
                .post(this.$url.URL + this.$url.SIGNATURE, {
                  //获取秘钥接口
                  str: str
                })
                .then(response => {
                  console.log(form1);
                  this.Notifysurl = response.data.result;
                  MessageBox.confirm("是否前往乾多多还款页面?").then(action => {
                    form1.submit();
                  });
                });
            } else {
              MessageBox("提示", response.data.msg);
            }
          });
      } else {
        MessageBox.confirm("账户余额不够是否前往充值？").then(action => {
          this.$router.push("/mine");
        });
      }
    }
  }
};
</script>

<style scoped="scoped">
body,
html {
  width: 100%;
  height: 100%;
  background-color: #f5f5f5;
}
.headname {
  position: fixed;
  left: 0;
  top: 0;
}
.repament {
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.refundcenter {
  width: 100%;
  margin-top: 0.88rem;
  border: 1px solid #f5f5f5;
  box-sizing: border-box;
}
.rfd_way {
  height: 0.88rem;
  width: 100%;
  background-color: white;
  margin-top: 0.2rem;
  line-height: 0.88rem;
  position: relative;
  border-top: 1px solid #f5f5f5;
  box-sizing: border-box;
}
.rfd_way > input {
  border: 0;
  height: 0.26rem;
  font-size: 0.26rem;
  float: left;
  margin-left: 0.3rem;
  width: 75%;
  margin-top: 0.31rem;
  outline: none;
  font-size: #cacaca;
}
.rfd_way > div:nth-of-type(1) {
  float: left;
  font-size: 0.3rem;
  margin-left: 0.24rem;
  color: #333333;
}
.rfd_way > div:nth-of-type(2),
.rfd_way > div:nth-of-type(3) {
  float: right;
  font-size: 0.26rem;
}
.rfd_way > div:nth-of-type(2) > img {
  height: 0.3rem;
  width: 0.17rem;
  position: absolute;
  right: 0.24rem;
  top: 0.29rem;
}
.rfd_way > div:nth-of-type(3) {
  margin-right: 0.61rem;
  color: #666666;
}
#explaindss > div {
  width: 100%;
  height: 0.6rem;
  background-color: #f5f5f5;
  line-height: 0.6rem;
  font-size: 0.22rem;
  color: #666666;
  text-indent: -1.2rem;
}

#btnBotom {
  width: 80%;
  height: 0.8rem;
  background-color: #fc8e0d;
  border-radius: 6px;
  font-size: 0.34rem;
  color: #ffffff;
  margin-top: 2rem;
  margin-left: 10%;
  border: none;
}
#bottonbtn {
  position: absolute;
  bottom: 0;
  width: 100%;
}
#bottonbtn > div {
  width: 100%;
  height: 0.8rem;
  font-size: 0.24rem;
  line-height: 0.8rem;
  text-align: center;
  background: #ffffff;
  border-bottom: 1px solid #dcdcdc;
}
#bottonbtn > div:nth-last-of-type(1) {
  border: none;
}
</style>