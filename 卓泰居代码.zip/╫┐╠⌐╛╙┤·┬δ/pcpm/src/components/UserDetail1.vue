<template>
	<div>
		<topct :dataname="dataname"></topct>
		<div class="userdetailbox">
			<div class="usertop">
				全民金服的诞生
			</div>
			<div class="usermidden">
				"全民金服"是一家专注于网络金融的互联网服务平台。平台秉承透明，安全，稳健的原则，致力于为客户提供提供简易的
				便捷，高效的服务，立足于房地产交易提供应链络金融的互联网服务平台。平台秉承透明，安全，稳健的原则，致力于为客户提供提供简易的
				便捷，高效的服务，立足于房地产交易提供应链。
			</div>
			<div class="userimgs">
				
			</div>
			<div class="usermidden">
				"全民金服"是一家专注于网络金融的互联网服务平台。平台秉承透明，安全，稳健的原则，致力于为客户提供提供简易的
				便捷，高效的服务，立足于房地产交易提供应链络金融的互联网服务平台。平台秉承透明，安全，稳健的原则，致力于为客户提供提供简易的
				便捷，高效的服务，立足于房地产交易提供应链。
			</div>
			<div class="userimgs">
				
			</div>
		</div>
	</div>
</template>

<script>
	import topct from './topct'
	export default{
		data(){
			return{
				dataname:"详情"
			}
		},
		components:{
			topct
		}
	}
</script>

<style scoped="scoped">
	.userdetailbox{
		width:93.6%;
		position:absolute;
		top:1.38rem;
		left:3.2%;
	}
	.usertop{
		font-size:0.34rem;
		text-align: center;
		color:#333333;
		margin-bottom:0.5rem;
	}
	.usermidden{
		font-size:0.26rem;
		margin-bottom:0.3rem;
		text-indent: 0.24rem;
	}
	.userimgs{
		width:100%;
		height:3.6rem;
		background:gray;
		margin-bottom:0.3rem;
	}
	.userimgs>img{
		width:100%;
		height:100%;
	}
</style>