<template>
	<div class="Mfeedback">
		<topctfalse :dataname="dataname"></topctfalse>
		<div class="textareawarp">
			<div>
				<textarea class="textarecontent" v-model="content"></textarea>
			</div>
			<div>
			感谢您给我们提出的宝贵意见
			</div>
			<div id="referbtn" @click="referbtn">提交</div>
		</div>
		

	</div>
</template>

<script>
	import topctfalse from './topctfalse'
	import { MessageBox } from 'mint-ui';	
	export default{
		data(){
			return{
				dataname:"意见反馈",
				content:"",
				token:window.sessionStorage.token
			}
		},
		methods:{
			referbtn(){
				this.$http.post(this.$url.URL + this.$url.SUGGESTION,{
					content:this.content
				},{
					 headers: { Authorization:this.token}
				})
				.then((response)=>{
					MessageBox("提示","信息提交成功")
				})
				.catch(()=>{
					MessageBox("提示","信息提交失败")
				})
			}
		},
		components:{
			topctfalse
		}
	}
</script>

<style scoped="scoped">
	html,body{
		width:100%;
	}
	.textareawarp{
		width:100%;
		position:absolute;
		top:0.98rem;
		
	}
	.textareawarp>div:nth-of-type(1){
		width:100%;
		height:2.8rem;
		background-color:#FFFFFF;
	}
	.textarecontent{
		width:100%;
		height:2.8rem;
		padding:0.3rem 0.24rem;
		outline: none;
		border:none;
		font-size:0.28rem;
		overflow:scroll;
		resize:none;
	}
	.textareawarp>div:nth-of-type(2){
		font-size:0.26rem;
		color:#D83515;
		margin-left:0.24rem;
		margin-top:0.2rem;
	}
	#referbtn{
		width:6.85rem;
		height:0.8rem;
		background-color:#Fc8E0D;
		margin-left:0.325rem;
		margin-top:2rem;
		border-radius: 6px;
		text-align: center;
		line-height: 0.8rem;
		font-size:0.34rem;
		color:#FFFFFF;
		
	}
</style>