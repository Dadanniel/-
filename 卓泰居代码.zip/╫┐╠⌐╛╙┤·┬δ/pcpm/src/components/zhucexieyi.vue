<template>
	<div class="Minebeginguide">
		<topct :dataname="dataname"></topct>
	
			<iframe class="minebegguideul" :src="overall.yonghuzhucexieyi"></iframe>
	
	
		</div>
</template>

<script>
	import topct from './topct'
	export default{
		data(){
			return{
				dataname:'注册协议',
				overall:"",
			}
		},
		created(){
			this.overall=JSON.parse(window.sessionStorage.overall)
			console.log(this.overall)
		},
		components:{
			topct
		}
	}
</script>

<style scoped="scoped">
	.minebegguideul{
		width:100%;
		height:100%;
	}
	.minebegguideul{
		width:100%;
		height:100%;
		position: absolute;
		top:0.9rem;
		border:none;
	}
</style>