<template>
	<div class="xbsd_text">
		<div class="headname" style="background-color:#Fc8E0D">
			<router-link tag="div" to="/">
				<div class="headnamelist"><img @click="baberBolr2" src="../imgs/homeqietu/fanhui.png"/></div>
			</router-link>
			<div id="headname_left">标预告</div>
		</div>
		<div id="xbsd_center">
			<div id="xbsd_center_box" v-for="item in list" @click="gobtn(item)">
				<div id="xbsd_center_box_top">
					<p>预计发布时间: {{item.kaibiao_date}}</p>
					<div :style="{backgroundcolor:item.project_type.color}" class="xbsd_box_div">{{item.project_type_display}}</div>
					<div>{{item.name}}</div>
					<div><img v-show="item.is_lock" src="../imgs/homeqietu/biaodisuo.png"/></div>
				</div>
				<div id="xbsd_center_box_bottom">
					<div class="xbsd_center_box_bottom_div">
						<div>年利率</div>
						<div>{{item.rate}}%</div>
					</div>
					<div class="xbsd_center_box_bottom_div">
						<div>总额</div>
						<div>{{item.amount}}</div>
					</div>
					<div class="xbsd_center_box_bottom_div">
						<div>期限</div>
						<div>{{item.issue_count}} 个月</div>
					</div>
				</div>
				<input type="button" class="xbsdbutton" @click.stop="gotouzi(item)" :class="{xbsdbtn:item.progress>='100'}" value="我要投标" :disabled="item.progress>='100'">
					<canvas class="myCanvas"></canvas>  
			</div>
				
		</div>


	</div>
</template>

<script>
	import {drawRing} from "@/../static/plug/drawRing.js"
			
	export default{
		data(){
			return{
				set:[89,23],
				list:[],
				set:[]
			}
		},
		computed:{
			
		},
		methods:{
			baberBolr2(){
				this.$store.dispatch("baberBolr2")
			},
			gotouzi(item){
				if(window.sessionStorage.token==undefined){
					  this.$router.push({path:'goashore'})
		  			
		  	}else{
				if (item.is_lock == true) {
					MessageBox.prompt('请输入解锁密码').then(({ value, action }) => {
						this.$http  
							.post(this.$url.URL + this.$url.CHECK_PROJECT,{
							project_id: item.id,
							password: value
							}).then((response)=>{
								if(response.data.code == 0){
									this.$router.push({name:'investnvrstrepe', params: {id:item.id+'a'}})
								}else{
									MessageBox.alert("输入密码不正确", "提示")
								}
							})
					});
				}else{
					this.$router.push({name:'investnvrstrepe', params: {id:item.id+'a'}})
				}
			}
			
			},
			gobtn(item){
				this.$router.push({path:'/signdetails/'+item.id+'a'})
				sessionStorage.removeItem('particulars')
			}
		},
			
		mounted(){

		},
		created(){		
			var overall = JSON.parse(window.sessionStorage.overall).project_type_list;
			this.$http.get(this.$url.PREPROJECT)
			.then((response)=>{
				this.list=response.data.results;
				console.log(response.data)
				for(let i=0;i<this.list.length;i++){
					this.set.push(this.list[i].progress)
					for(let l=0;l<overall.length;l++){
						if(this.list[i].project_type==overall[l].code){
							this.list[i].project_type=overall[l]
						}
					}
				}
				this.$nextTick(function(){
					var wth = document.documentElement.clientWidth; 
					var that=this	
			        drawRing(that);
				})
		})
		}
	}
	
</script>

<style scoped="scoped">
 	.myCanvas{
 		position:absolute;
 		top:10%;
 		right:5.4%;
 	}
	.xbsd_text{
		height:100%;
		background-color:#f5f5f5;
	}
	#xbsd_center{
		width:100%;
		position:absolute;
		top:0.88rem;
	}
	#xbsd_center_box{
		width:100%;
		height:2.46rem;
		margin-top:0.1rem;
		background-color:#ffffff;
		position:relative;
		color:#494949;		
	}
	#xbsd_center_box_top{
		height:0.7rem;
		line-height: 0.7rem;
		border-top:1px solid white;
		box-sizing: border-box;
		position:relative;
	}
	#xbsd_center_box_top>p{
		font-size:0.2rem;
		color:#D83515;
		position:absolute;
		top:0.35rem;
		margin-left:0.9rem;
	}
	#xbsd_center_box_top>div{
		float:left;
	}
	.xbsd_box_div1{
		background-color:red;
	}
	.xbsd_box_div2{
		background-color:yellow;
	}
	.xbsd_box_div3{
		background-color:beige;
	}
	.xbsd_box_div4{
		background-color:black;
	}
	.xbsd_box_div5{
		background-color:blue;
		
	}
	.xbsd_box_div{
		width:0.44rem;
		height:0.28rem;
		font-size:0.16rem;
		text-align: center;
		line-height: 0.28rem;
		margin-top:0.17rem;
		border-radius: 4px;
		margin-left:0.24rem;
		margin-right:0.2rem;
		color:#FFFFFF;
	}
	
	@media  (min-width:300px) and (max-width: 400px) { 
	   .xbsd_box_div{
			width:26px;
			height:14px;
			font-size:12px;
			line-height:14px;
			margin-top:0.15rem;
		}
	}
	#xbsd_center_box_top>div:nth-of-type(2){
		font-size:0.32rem;
		vertical-align: middle;
	}
	#xbsd_center_box_top>div:nth-of-type(3)>img{
		width:0.2rem;
		height:0.26rem;
		vertical-align: middle;
		margin-top:-0.2rem;
		margin-left:0.3rem;
	}
	#xbsd_center_box_bottom{
		position: relative;
		margin-top:0.5rem;
	}
	.xbsd_center_box_bottom_div{
		float:left;
		text-align: center;
		margin-left:0.9rem;
		width:0.9rem;
	}

	.xbsd_center_box_bottom_div>div:nth-of-type(1){
		font-size:0.3rem;
		
	}
	.xbsd_center_box_bottom_div>div:nth-of-type(2){
		font-size:0.26rem;
		margin-top:0.2rem;
	}
	.xbsdbutton{
		width:1.6rem;
		height:0.5rem;
		background-color:#FD8F00;
		text-align: center;
		line-height: 0.5rem;
		font-size:0.26rem;
		color:#FFFFFF;
		position:absolute;
		bottom:0.2rem;
		right:0.34rem;
		border-radius: 6px;
		border:none;
	}
	.xbsdbtn{
		background:#dcdcdc;
	}
</style>