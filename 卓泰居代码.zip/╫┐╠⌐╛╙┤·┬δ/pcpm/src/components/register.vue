<template>
	<div>
		首页跳转注册有好礼
	</div>
</template>

<script>
</script>

<style>
</style>