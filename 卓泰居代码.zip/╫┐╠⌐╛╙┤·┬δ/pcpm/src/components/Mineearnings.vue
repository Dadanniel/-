<template>
	<div class="Mineearnings">
		<topct :dataname="dataname"></topct>
		<ul class="Mineearningsul">
			<li>
				<div>用户</div>
				<div>收益<span>(元)</span></div>
				<div>时间</div>
			</li>
			<li v-for="item in list">
				<div>{{item.recommended_name}}</div>
				<div>{{item.bonus}}</div>
				<div>{{item.time}}</div>
			</li>
			
		</ul>
	</div>
</template>

<script>
	import topct from './topct'
	export default{
		data(){
			return{
				dataname:"邀请好友奖励",
				list:''
			}
		},
		created(){
			this.$http.post("api//member/broker_bonus",{
				member_id:1
			})
			.then((response)=>{
				this.list = response.data.broker_dict_list
			})
		},
		components:{
			topct
		}
	}
</script>

<style scoped="scoped">
	.Mineearningsul{
		width:100%;
		margin-top:0.88rem;
		list-style: none;
	}
	.Mineearningsul>li{
		height:0.88rem;
		width:100%;
		border-top:1px solid #DcDcDc;
		background-color:#FFFFFF;
		color:#333333;
		font-size:0.24rem;
	}
	.Mineearningsul>li>div{
		width:33.33333333333%;
		height:0.88rem;
		float:left;
		text-align: center;
		line-height: 0.88rem;
	}
	.Mineearningsul>li:nth-of-type(1){
		background-color:#D8D7D7;
		font-size:0.32rem;
		color:#2F81FD;
		
	}
	.Mineearningsul>li:nth-of-type(1)>div>span{
		font-size:0.22rem;
	}
</style>