<template>
	<div class="accountschemes">
		<topctfalse :dataname="dataname"></topctfalse>
		<div class="chemeswarp">
			<div class="chemestopwarp" v-show='false'>
				<div>等额本息</div>
				<ul>
					<li>每月利息收益: 43.36元</li>
					<li>每月回本: 20,000.00</li>
				</ul>		
			</div>
			<div id="scenmesone" v-show='list1.length>0'>未还款</div>
			<ul class="schemesuls" v-show='list1.length>0'>
				
				<li><div>{{this.list1.time}}</div><div>{{this.list1.time}}元</div></li>
			</ul>	
			<div id="scenmesone" v-show='list1.length>0'>已还款</div>
			<ul class="schemesuls" v-show='list1.length>0'>			
				<li><div>{{this.list2.time}}</div><div>{{this.list2.time}}元</div></li>
			</ul>	
		</div>
	</div>
</template>

<script>
	import topctfalse from './topctfalse'
	export default{
		data(){
			return{
				dataname:"还款计划",
				list1: [],
				list2: []
			}
		},
		created() {
			var id = this.$route.params.id
			var url = "api/issue/repay_details"
			this.$http.post(url, { 'project_id': id }, { headers: { 'Authorization': window.sessionStorage.token } })
				.then((response) => {
					for(var i = 0; i < response.data.issue_details.length; i++) {
						if(response.data.issue_details[i].status == "NORMAL") {
							this.list1.push(response.data.issue_details[i])
						}
						if(response.data.issue_details[i].status == "REPAID") {
							this.list2.push(response.data.issue_details[i])
						}
					}
				})
		},
		components:{
			topctfalse
		}
	}
</script>

<style scoped="scoped">
	.chemeswarp{
		width:100%;
		position:absolute;
		top:1.08rem;
	}
	.chemestopwarp{
		background-color:#FFFFFF;
	}
	.chemestopwarp>div:nth-of-type(1){
		font-size:0.42rem;
		color:#D83515;
		padding-top:0.5rem;
		padding-bottom:0.4rem;
		text-align: center;
		
	}
	.chemestopwarp>ul{
		width:100%;
		list-style: none;
		overflow: hidden;
	}
	.chemestopwarp>ul>li{
		width:50%;
		float:left;
		text-align: center;
		font-size:0.28rem;
		color:#333333;
		padding-bottom:0.5rem;
	}
	.schemesuls{
		list-style: none;
		width:100%
	}
	.schemesuls>li{
		width:100%;
		height:0.88rem;
		line-height: 0.88rem;
		border-top:1px solid #DcDcDc;
		background-color:#FFFFFF;
	}
	.schemesuls>li>div:nth-of-type(1){
		float:left;
		font-size:0.32rem;
		text-indent: 0.24rem;
	}
	.schemesuls>li>div:nth-of-type(2){
		float:right;
		font-size:0.28rem;
		margin-right:0.24rem;
	}
	#scenmesone{
		font-size:0.32rem;
		color:#333333;
		padding-top:0.6rem;
		padding-bottom:0.2rem;
		text-indent:0.24rem;
	}
	.schemesuls>li:nth-of-type(1){
		border:none;
	}
</style>