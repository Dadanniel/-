<template>
	<div class="refuntplan">
		<div class="headname">
			<div @click="gobacktop3">
				<div class="headnamelist"><img src="../imgs/homeqietu/fanhui.png"/></div>
			</div>
			<div id="headname_left">还款计划</div>
		</div>
		<ul id="refuntpalanul">
			<li id="refuntpalanli" v-for="item in data">
				<div>
					<div>还款时间</div>
					<span>{{item.time}}</span>
					<!--<span>10:28:17</span>-->
				</div>
				<div>
					<div>还款本金</div>
					<span>￥{{item.amount}}元</span>
				</div>
				<div>
					<div>还款利息</div>
					<span>￥{{item.plan_interest}}元</span>
				</div>
				<div>
					<div>应缴罚款</div>
					<span>￥{{item.plan_fine}}元</span>
				</div>
				<div id="refuntpalanliratat">
					第一期
				</div>
				<div class="refuntpalanlibtn" :class='{refunbtn:btnbors}'>
					已还清
				</div>
			</li>
		</ul>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				btnbors:false,
				data:''
			}
			
		},
		created(){
			var id= this.$route.params.id;
			
			this.$http.post(this.$url.ISSUE_DATAILS,{
				project_id:id
			})
			.then((response)=>{
				console.log(response.data.issue_details)
				this.data=response.data.issue_details
				
			})
		},
		methods:{
			gobacktop3(){
				this.$router.go(-1)
			}
		}
	}
</script>

<style scoped="scoped">
	.headname{
		position:fixed;
		left:0;
		top:0;
		background-color:#Fc8E0D;
	}
	#refuntpalanul{
		width:100%;
		position:absolute;
		top:1.08rem;
		font-size:0.26rem;
	}
	#refuntpalanli{
		background-color:#FFFFFF;
		border-top:1px solid #FFFFFF;
		box-sizing: border-box;
		position: relative;
	}
	#refuntpalanli>div{
		margin-top:0.2rem;
		
	}
	#refuntpalanli>div>div{
		width:1.26rem;
		height:0.46rem;
		text-align: center;
		line-height: 0.46rem;
		color:#FFFFFF;
		background:#2F81FD;
		display: inline-block;
		margin-left:0.24rem;
		margin-right:0.3rem;
	}
	#refuntpalanli>div:nth-of-type(1){
		margin-top:0.3rem;
		
	}
	#refuntpalanli>div:nth-of-type(4){
		padding-bottom:0.3rem;
		
	}
	#refuntpalanliratat{
		position: absolute;
		right:0.74rem;
		top:0.64rem;
		width:0.8rem;
		height:0.8rem.;
		text-align: center;
		line-height: 0.8rem;
		background-color:#FD8F00;
		color:#FFFFFF;
		border-radius: 50%;
		font-size:0.2rem;
	}
	.refuntpalanlibtn{
		width:1.4rem;
		height:0.46rem;
		text-align: center;
		line-height: 0.46rem;
		font-size:0.24rem;
		border:1px solid #D83515;
		position:absolute;
		top:2rem;
		right:0.44rem;
		color:#D83515;
	}
	.refunbtn{
		width:1.4rem;
		height:0.46rem;
		text-align: center;
		line-height: 0.46rem;
		font-size:0.24rem;
		border:none;
		color:#333333;
		position:absolute;
		top:2rem;
		right:0.44rem;
		background:#cAcAcA;
		font-family: 666666;
	}
</style>