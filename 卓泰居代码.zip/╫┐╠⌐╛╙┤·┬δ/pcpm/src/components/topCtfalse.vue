<template>
		<div class="headname">
			<div @click="gobacktopfalse">
				<div class="headnamelist"><img src="../imgs/homeqietu/fanhui.png"/></div>
			</div>
			<div id="headname_left">{{dataname}}</div>
		</div>
</template>

<script>
	export default{
		
		props:["dataname"],
		methods:{
			gobacktopfalse(){
				this.$router.go(-1)
				this.$store.dispatch("gobacktopfalse")
			}
		}
	}
</script>

<style>
	.headname{
		position:fixed;
		left:0;
		top:0;
		background-color:#Fc8E0D;
	}

</style>