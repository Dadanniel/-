<template>
	<div class="invesitem">
		<ul class="invesitemtop">
			<li class="headname_leftli" :class="{headli1:headbol1}" @click="changeli1">默认</li>
			<li class="headname_leftli" :class="{headli2:headbol2}" @click="changeli2">期限</li>
			<li class="headname_leftli" :class="{headli3:headbol3}" @click="changeli3"><span>年利率</span>
				<img v-show="!headbol3" src="../imgs/invistimgs/paixukaobei.png"/>
				<img v-show="headbol3" src="../imgs/invistimgs/xuanzhongpaixu.png"/>
			</li>
			<li class="headname_leftli" :class="{headli4:headbol4}" @click="changeli4"><span>起投金额</span>
				<img v-show="!headbol4" src="../imgs/invistimgs/paixukaobei.png"/>
				<img v-show="headbol4" src="../imgs/invistimgs/xuanzhongpaixu.png"/>
			</li>
			<li @click='screenbtn'><img src="../imgs/invistimgs/shaixuanone.png"/></li>
		</ul>
		<div id="xbsd_center">
			<div style="width:100%;">
			<div id="loding" v-show="loadingzj">已全部加载..</div>
			<div id="loding" v-show="loading">正在加载更多..</div>
			<div id="xbsd_center_box" v-for="item in list" @click="btnprojct(item)">
				<div id="xbsd_center_box_top">
					<div :style="{background:item.project_type.color}">{{item.project_type_display}}</div>
					<div>{{item.name}}</div>
					<div><img v-show="item.is_lock" src="../imgs/homeqietu/biaodisuo.png"/></div>
				</div>
				<div id="xbsd_center_box_bottom">
					<div class="xbsd_center_box_bottom_div">
						<div>年利率</div>
						<div>{{item.rate}}%</div>
					</div>
					<div class="xbsd_center_box_bottom_div">
						<div>总额</div>
						<div>{{item.amount}}</div>
					</div>
					<div class="xbsd_center_box_bottom_div">
						<div>期限</div>
						<div>{{item.issue_count}}个月</div>
					</div>
				</div>			
					<input type="button" id="xbsdbutton" :disabled="item.progress==100" :class="{hk_bexttwo:item.progress==100}" value="我要投资" @click.stop="authenmovesd(item)"/>

				<canvas class="myCanvas"></canvas>  
			</div>
			</div>
		</div>
		
		
		
		<div class="filtratewarp"  v-show="filtrashow">
			<div @click.stop="hidescreenbtn" class="filtrateleft"></div>
		</div>
			<div class="filtrate">
				<div id="deadline">期限</div>
				<ul id="filtratul">
					<li>投资期限</li>
					<li v-for="(item,index) in radioswarp" @click="radiobtn(item,index)">
						<div class="filtratuldiv" :class="{radios:item.id ==itemlist}"><img class="filtratulimg"  src="../imgs/mineimgs/fuxuankiangxuanzhong.png"/></div> 
						<span>{{item.name}} </span> 
					</li>
					
				</ul>
				<div class="nl_V">
					年利率
				</div>
				<ul class="nianli_lv">
					<li>年利率区间</li>
					<li><input type="text"placeholder="最低利率" v-model="text1" /></li>
					<li></li>
					<li><input type="text"placeholder="最高利率"v-model="text2" /></li>
				</ul>
				<div id="qt_je">起投金额</div>
				<ul id="qt_jeul">
					<li v-for="(item,index) in content1" class="qt_jeli qt_jelia" :class="{qitou_jine:item.id==qitou}"@click="jeclick1(item,index)">{{item.name}}</li>
				</ul>
				<div id="qt_je" style="margin-top:2.2rem;">还款方式</div>
				<ul id="qt_jeu2" >
					<li class="qt_jeli qt_jelib" v-for="(item,index) in content2" :class="{qitou_jine:item.id==huankuang_fs}" @click="jeclick1a(item,index)">{{item.name}}</li>

				</ul>
				<div class="investbuttonwarp">
					<div @click="invesbtn1">重置</div>
					<div @click="invesbtn2">确定</div>
				</div>
			</div>
		
	</div>
</template>

<script>
	import {drawRing} from "@/../static/plug/drawRing.js";
	import { MessageBox } from 'mint-ui';		
	export default{
		data(){
			return{
				headbol1:true,
				headbol2:false,
				headbol3:false,
				headbol4:false,
				set:[],
				list:"",
				ordering:"",
				data:"",
				move:false,
				dataall:"",
				result:"",
				
				filtrashow:false,
				radioswarp:[{id:"S",name:"短期"},{id:"M",name:"中期"},{id:"L",name:"长期"}],		
				content1:[{id:"0",name:"0元起投"},{id:"10",name:"10元起投"},{id:"100",name:"100元起投"},{id:"1000",name:"1000元起投"}],
				content2:[{id:"rate_monthly",name:"每月还息"},{id:"once",name:"一次还清"}],
				text1:"",
				text2:"",
				qitou:"0",
				huankuang_fs:"rate_monthly",
				itemlist:"S",
				n:"1",//分页,
				loading:false,
				loadingzj:false,
			}
		},
		props:["invesid"],
		created(){
			//获取全局数据的dataalltoken
			this.dataall = JSON.parse(window.sessionStorage.overall)

			//获取我的首页的私人数据
				if(window.sessionStorage.my_data==undefined){
					this.my_data=""
				}else{
					this.data = JSON.parse(window.sessionStorage.my_data)
				}
				
				//获取投资页数据
				if(window.sessionStorage.urls==undefined){
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+"&ordering="+this.ordering+"&page="+this.n++
					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					var sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
							for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
							}
					}
					this.set = sets
					this.$nextTick(function(){
					var wth = document.documentElement.clientWidth; 
					var that=this
					drawRing(that);
					})
					
					
					
					var nScrollHight = 0; //滚动距离总长(注意不是滚动条的长度)  
			       var nScrollTop = 0;   //滚动到的当前位置  
			       var nDivHight = $("#xbsd_center").height();
					var that=this
			       $("#xbsd_center").scroll(function(){
					 
			         nScrollHight = $(this)[0].scrollHeight;  
			         nScrollTop = $(this)[0].scrollTop+39;  
			         if(nScrollTop + nDivHight >= nScrollHight){
						 
						let url = that.$url.URL+"api/project/project_list/?project_type="+that.invesid+"&ordering="+that.ordering+"&page="+that.n++
						that.$http.get(url)
						.then((response)=>{
						that.list = that.list.concat(response.data.results)
						sets=[]
						for(var i=0;i<that.list.length;i++){
							sets.push(that.list[i].progress)
								for(let l=0;l<that.dataall.project_type_list.length;l++){
									if(that.list[i].project_type==that.dataall.project_type_list[l].code){
										that.list[i].project_type=that.dataall.project_type_list[l]
										
									}
								}
						}
						that.set = sets
						that.loading=true
						setTimeout(()=>{
			         		that.loading=false
			         	},1000)
						that.$nextTick(function(){
						var wth = document.documentElement.clientWidth; 
						var thas=that
						drawRing(thas);
						})})
						.catch(()=>{
						that.loadingzj=true
						setTimeout(()=>{
							that.loadingzj=false
						},1000)
						})
				         	
			         	
			         	
			         	
			         }
			           
			         });
					
					})
					.catch(()=>{
						this.loadingzj=true
						setTimeout(()=>{
							this.loadingzj=false
						},1000)
					})
				}else{
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+window.sessionStorage.urls
					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
					}
					this.set = sets
					this.$nextTick(function(){
					var wth = document.documentElement.clientWidth; 
					var that=this
					 
					drawRing(that);
					})
				})
				}
				
		},
		mouted(){ 
		},
		methods:{
			btnprojct(item){
				this.$router.push({path:'/signdetails/'+item.id})
				sessionStorage.removeItem('particulars')
			},
			
			
			
			
			radiobtn(item,index){
				this.itemlist=item.id
				console.log(this.itemlist)
			},
			jeclick1(item,index){
				this.qitou=item.id
				console.log(this.qitou)
			},
			jeclick1a(item,index){
				this.huankuang_fs=item.id
				console.log(this.huankuang_fs)
			},
			invesbtn1(){
				this.text1 = "",
				this.text2 = "",
				this.itemlist ="S"
				this.qitou="0",
				this.huankuang_fs="rate_monthly"
			},
			invesbtn2(){
//				this.text1  1
//				this.text2  2
//				this.itemlist  S M L
//				this.huankuang_fs   rate_monthly 一次还清
//				this.qitou  0 10 100 1000
//				this.invesid  ZJD DYD



				if(/^\d+$/.test(this.text1)&&/^\d+$/.test(this.text2)){
					let text1 = parseFloat(this.text1)
					let text2 = parseFloat(this.text2)
					if(text1<text2){				
						let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+"&ordering="+this.ordering+"&issue_count="+this.itemlist+"&min_rate="+this.text1+"&max_rate="+this.text2+"&min_amount="+this.qitou+"&repay_type="+this.huankuang_fs
						let urls = "&issue_count="+this.itemlist+"&min_rate="+this.text1+"&max_rate="+this.text2+"&min_amount="+this.qitou+"&repay_type="+this.huankuang_fs
						window.sessionStorage.urls = urls	
						this.$http.get(url)
						.then((response)=>{
							this.list=response.data.results
							for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
							}
						})				
						$(".filtrate").animate({
							right:"-81%"
						},300)
						var that=this
						setTimeout(function(){
							that.filtrashow=false
							that.$store.dispatch("gobacktop")
						},300)					
					}else{
						alert("最小利率必须小于最大利率")
					}
				}else{
					alert("年利率请输入数字")
				}		
			},
			hidescreenbtn(){
				$(".filtrate").animate({
					right:"-81%"
				},300)
				var that=this
				setTimeout(function(){
					that.filtrashow=false
					that.$store.dispatch("gobacktop")
				},300)

			},
			screenbtn(){
				this.$store.dispatch("authenmoves")
				this.filtrashow=true;
				$(".filtrate").animate({
					right:0
				},300)
				
			},
			
			
			changeli1(){
				this.headbol1=true;
				this.headbol2=false;
				this.headbol3=false;
				this.headbol4=false;
				this.n=1;
				this.list=""
				if(window.sessionStorage.urls==undefined){
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid
					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
						for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
						}
					}
					this.set = sets
					this.$nextTick(()=>{
					var wth = document.documentElement.clientWidth; 				
					drawRing(this)
					})
					})
				}else{
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+window.sessionStorage.urls

					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
						for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
						}
					}
					this.set = sets
					this.$nextTick(()=>{
					var wth = document.documentElement.clientWidth; 				
					drawRing(this)
					})
				})
				}
				
			},
			changeli2(){
				this.headbol1=false;
				this.headbol2=true;
				this.headbol3=false;
				this.headbol4=false;
				this.n=1
				this.list=""
				if(this.ordering==""){
					this.ordering="date"
				}
				else if(this.ordering=="-date"){
					this.ordering="date"
				}else{
					this.ordering="-date"
				}
				
				
				
				if(window.sessionStorage.urls==undefined){
					let url =this.$url.URL+ "api/project/project_list/?project_type="+this.invesid+"&ordering="+this.ordering
					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
						for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
							}
					}
					this.set = sets
					this.$nextTick(()=>{
					var wth = document.documentElement.clientWidth; 				
					drawRing(this)
					})
					})
				}else{
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+"&ordering="+this.ordering+window.sessionStorage.urls
					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
						for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
							}
					}
					this.set = sets
					this.$nextTick(()=>{
					var wth = document.documentElement.clientWidth; 				
					drawRing(this)
					})
					})
				}
			},
			changeli3(){
				this.n=1
				this.headbol1=false;
				this.headbol2=false;
				this.headbol3=true;
				this.headbol4=false;
				this.list=""
				if(this.ordering=="rate"){
					this.ordering="-tate"
				}
				else if(this.ordering=="-tate"){
					this.ordering="rate"
				}else{
					this.ordering="rate"
				}
				if(window.sessionStorage.urls==undefined){
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+"&ordering="+this.ordering

					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
						for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
							}
					}
					this.set = sets
					this.$nextTick(()=>{
					var wth = document.documentElement.clientWidth; 				
					drawRing(this)
					})
					})
				}else{
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+"&ordering="+this.ordering+window.sessionStorage.urls

					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
						for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
							}
					}
					this.set = sets
					this.$nextTick(()=>{
					var wth = document.documentElement.clientWidth; 				
					drawRing(this)
					})
				})
				}

			},
			changeli4(){
				this.n=1
				this.headbol1=false;
				this.headbol2=false;
				this.headbol3=false;
				this.headbol4=true;
				this.list=""
				if(this.ordering=="min_amount"){
					this.ordering="-min_amount"
				}
				else if(this.ordering=="-min_amount"){
					this.ordering="min_amount"
				}else{
					this.ordering="min_amount"
				}			
				if(window.sessionStorage.urls==undefined){
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+"&ordering="+this.ordering

					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
						for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
							}
					}
					this.set = sets
					this.$nextTick(()=>{
					var wth = document.documentElement.clientWidth; 				
					drawRing(this)
					})
					})
				}else{
					let url = this.$url.URL+"api/project/project_list/?project_type="+this.invesid+"&ordering="+this.ordering+window.sessionStorage.urls
					
					this.$http.get(url)
					.then((response)=>{
					this.list = response.data.results
					let sets = []
					for(var i=0;i<this.list.length;i++){
						sets.push(this.list[i].progress)
						for(let l=0;l<this.dataall.project_type_list.length;l++){
								if(this.list[i].project_type==this.dataall.project_type_list[l].code){
									this.list[i].project_type=this.dataall.project_type_list[l]
									
								}
							}
					}
					this.set = sets
					this.$nextTick(()=>{
					var wth = document.documentElement.clientWidth; 				
					drawRing(this)
					})
				})
				}
			},
			authenmovesd(item){
				if(window.sessionStorage.token==undefined){
					  this.$router.push({path:'goashore'})		  			
		  	}else{
				if(item.progress<=100){
					if (item.is_lock == true) {
					MessageBox.prompt('请输入解锁密码').then(({ value, action }) => {
						this.$http  
							.post(this.$url.URL + this.$url.CHECK_PROJECT, {
							project_id: item.id,
							password: value
							}).then((response)=>{
								if(response.data.code == 0){
									this.$router.push({name:'investnvrstrepe', params: {id:item.id}})
								}else{
									MessageBox.alert("输入密码不正确", "提示")
								}
							})
					});
					}else{
						this.$router.push({name:'investnvrstrepe', params: {id:item.id}})
					}
				}else{
					MessageBox.alert("标已投满", "提示")
				}
				

				
		  		}
				
			}
			
		},
		mounted(){
			var that=this
			Zepto(".filtrate").on("swipeRight",function(){
				$(".filtrate").animate({
					right:"-81%"
				},300)
				var thas=that
				setTimeout(function(){
					thas.filtrashow=false
					thas.$store.dispatch("gobacktop")
				},300)
			});
					
			      
			}
		
	}

</script>

<style scoped="scoped">
	body,html{
		height:100%;
	}
	.myCanvas{
 		position:absolute;
 		top:16%;
 		right:5.2%;
 	}
	.invesitem{
		position:relative;
		height:100%;

	}
	.invesitemtop{
		width:100%;
		list-style: none;
		background-color:#FFFFFF;
		position:fixed;
		z-index:999;
		position:fixed;
	}
	.invesitemtop>li{
		height:0.7rem;
		float:left;
		line-height: 0.7rem;
		font-size:0.28rem;
	
	}
	.invesitemtop>li>span{
		vertical-align: middle;
	}
	.invesitemtop>li>img{
		width:0.12rem;
		height:0.26rem;
		vertical-align: middle;
		margin-left:0.1rem;
	}
	.headname_leftli{
		border-bottom:none;
		box-sizing: border-box;
	}
	.headli1{
		border-bottom:2px solid #D83515;
		color:#D83515;
	}
	.headli2{
		border-bottom:2px solid #D83515;
		color:#D83515;
	}
	.headli3{
		border-bottom:2px solid #D83515;
		color:#D83515;
	}
	.headli4{
		border-bottom:2px solid #D83515;
		color:#D83515;
	}
	.invesitemtop>li:nth-of-type(1){
		margin-left:0.24rem;
		margin-right:0.8rem;
	}
	.invesitemtop>li:nth-of-type(2){
		margin-right:0.8rem;
	}
	
	.invesitemtop>li:nth-of-type(3){
		margin-right:0.8rem;
	}
	.invesitemtop>li:nth-of-type(4){
		margin-right:0.8rem;
	}
	.invesitemtop>li:nth-of-type(5){
		float:right;
		position:absolute;
		right:0.24rem;
	}
	.invesitemtop>li:nth-of-type(5)>img{
		width:0.28rem;
		height:0.28rem;
		
	}

	#xbsd_center{
		width:100%;
		/*overflow: hidden;*/
		padding-top:0.7rem;
		height:85%;
		overflow-x:hidden ;
		overflow-y:auto;
		border:none;
		-webkit-overflow-scrolling:touch;
	}
	#xbsd_center_box{
		width:100%;
		height:2.46rem;
		margin-top:0.1rem;
		background-color:#ffffff;
		position:relative;
		color:#494949;
	}
	#xbsd_center>div>div:nth-of-type(1){
		margin-top:0.2rem;
	}

	#xbsd_center_box_top{
		height:0.7rem;
		line-height: 0.7rem;
		border-top:1px solid white;
		box-sizing: border-box;
	}
	#xbsd_center_box_top>div{
		float:left;
	}
	#xbsd_center_box_top>div:nth-of-type(1){
		width:0.44rem;
		height:0.28rem;
		font-size:0.16rem;
		text-align: center;
		line-height: 0.28rem;
		margin-top:0.17rem;
		border-radius: 4px;
		margin-left:0.24rem;
		margin-right:0.2rem;
		color:#FFFFFF;
	}
	@media  (min-width:300px) and (max-width: 400px) { 
	   #xbsd_center_box_top>div:nth-of-type(1){
			width:26px;
			height:14px;
			font-size:12px;
			line-height:14px;
			margin-top:0.15rem;
		}
	}
	#xbsd_center_box_top>div:nth-of-type(2){
		font-size:0.32rem;
		vertical-align: middle;
	}
	#xbsd_center_box_top>div:nth-of-type(3)>img{
		width:0.2rem;
		height:0.26rem;
		vertical-align: middle;
		margin-top:-0.2rem;
		margin-left:0.3rem;
	}
	#xbsd_center_box_bottom{
		position: relative;
		margin-top:0.5rem;
	}
	.xbsd_center_box_bottom_div{
		float:left;
		text-align: center;
		margin-left:0.9rem;
	}

	.xbsd_center_box_bottom_div>div:nth-of-type(1){
		font-size:0.3rem;
		
	}
	.xbsd_center_box_bottom_div>div:nth-of-type(2){
		font-size:0.26rem;
		margin-top:0.2rem;
	}
	#xbsdbutton{
		width:1.6rem;
		height:0.5rem;
		background-color:#FD8F00;
		text-align: center;
		line-height: 0.5rem;
		font-size:0.26rem;
		color:#FFFFFF;
		position:absolute;
		bottom:0.2rem;
		right:0.34rem;
		border-radius: 6px;
		border:none;
	}
	


	.filtratewarp{
				
		width:100%;
		min-height:100%;
		background:rgba(0,0,0,.7);
		position:absolute;
		top:-0.88rem;
		left:0;
		z-index:999;	
		overflow:hidden;
	}
	.filtrate{
		width:81%;
		
		min-height:100%;
		background:#FFFFFF;
		position:absolute;
		right:-81%;
		top:-0.88rem;
		z-index:99999
	}

	.filtrateleft{
		width:19%;
		min-height:13.4rem;
		float:left;
	}
	#deadline{
		color:#2fb1fd;
		font-size:0.3rem;
		margin-top:0.5rem;
		margin-left:0.2rem;
	}
	#filtratul{
		list-style: none;
		margin-top:0.4rem;
	}
	#filtratul>li{
		display: inline-block;
		float:left;
		font-size:0.22rem;
		margin-right:0.5rem;
	}
	#filtratul>li:nth-of-type(4){
		margin-right:0;
	}
	#filtratul>li:nth-of-type(1){
		margin-left:0.4rem;
		font-size:0.26rem;
		margin-right:0.4rem;
	}
	.filtratuldiv{
		display: inline-block;
		width:0.3rem;
		height:0.3rem;
		margin-right:0.1rem;
		border-radius:50%;
		/*background-color:#DcDcDc;*/
		border:1px solid #333333;
	}
	.filtratulimg{
		width:60%;
		height:60%;
		vertical-align: middle;
		margin-left:20%;
		line-height: 0.3rem;	
	}
	.radios{
		background-color:#D83515;
		border:none;
	}
	#filtratul>li>span{
		vertical-align: middle;
	}
	.nl_V{
		color:#2fb1fd;
		font-size:0.3rem;
		margin-top:1.4rem;
		margin-left:0.2rem;
	}
	.nianli_lv{
		list-style: none;
		margin-top:0.4rem;
	}
	.nianli_lv>li{
		display: inline-block;
		font-size:0.2rem;
		float:left;
		color:#999999
	}
	.nianli_lv>li:nth-of-type(1){
		font-size:0.26rem;
		margin-left:0.4rem;
		margin-right:0.34rem;
		color:#333333;
		height:0.4rem;
		line-height: 0.4rem;
	}
	.nianli_lv>li:nth-of-type(2)>input,.nianli_lv>li:nth-of-type(4)>input{
		width:1.5rem;
		height:0.4rem;
		text-align: center;
		line-height: 0.4rem;
		background-color:#ebeaea;
		outline: none;
		border:none;
	}
	.nianli_lv>li:nth-of-type(3){
		height: 0.2rem;
		width:0.2rem;
		border-bottom: 1px solid #333333;
		margin:0 0.1rem;
	}
	#qt_je{
		color:#2fb1fd;
		font-size:0.3rem;
		margin-top:1.4rem;
		margin-left:0.2rem;
	}
	#qt_jeul{
		margin-left:0.4rem;
		margin-top:0.4rem;
		list-style: none;
		font-size:0.2rem;
	}
	#qt_jeu2{
		margin-left:0.4rem;
		margin-top:0.4rem;
		list-style: none;
		font-size:0.2rem;
	}

	.qt_jeli{
		float:left;
		text-align: center;
		line-height: 0.4rem;
		background-color:#EBEAEA;
		border-radius: 4px;
	}

	.qitou_jine{
		color:#D83515;
		border:1px solid #D83515;
		background-color:#FFFFFF;
	}
	.qt_jeli:nth-of-type(1),.qt_jeli:nth-of-type(2),.qt_jeli:nth-of-type(3){
		width:1.6rem;
		height:0.4rem;
	}
	.qt_jeli:nth-of-type(2){
		margin-left:0.3rem;
		margin-right:0.4rem;
	}
	.qt_jeli:nth-of-type(4){
		width:1.8rem;
		height:0.4rem;
		margin-right:0.3rem;
		margin-top:0.2rem;
	}
	@media(min-width:1000px) and (max-width:1500px ) {
	.qt_jeli:nth-of-type(4){
		width:1.8rem;
		height:0.4rem;
		margin-left:0.2rem;
		margin-top:0;
	}
	}
	.qt_jeli:nth-of-type(5){
		width:2.1rem;
		height:0.4rem;
		margin-top:0.2rem;
	}

	.investbuttonwarp{
		width:4.8rem;
		height:0.6rem;
		font-size:0.3rem;
		margin:auto;
		margin-top:3rem;
		margin-bottom:2.9rem;
	}
	.investbuttonwarp>div{
		width:2rem;
		height:0.6rem;
		background-color:#D83515;
		color:#FFFFFF;
		text-align: center;
		line-height: 0.6rem;
		border-radius: 6px;
	}
	.investbuttonwarp>div:nth-of-type(1){
		float:left;
	}
	.investbuttonwarp>div:nth-of-type(2){
		float:right;
	}
	#loding{
		width:30%;
		height:0.68rem;
		text-align: center;
		line-height: 0.68rem;
		background:rgba(0,0,0,0.6);
		position:fixed;
		bottom:1.1rem;
		z-index:9999;
		left:35%;
		border-radius: 6px;
		color:#FFFFFF;
		
		}
	.hk_bexttwo{
		background:#dcdcdc !important;
	}
</style>