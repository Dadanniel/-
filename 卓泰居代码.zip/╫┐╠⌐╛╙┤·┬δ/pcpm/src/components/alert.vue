<template>
	<div class="alert">
		<div>
			<div><img src="../imgs/mineimgs/fuxuankiangxuanzhong.png"/></div>
			<p>{{alertfont}}</p>
		</div>
	</div>
</template>

<script>
	export default{
		props:["alertfont"],
		mounted(){
			$('.alert>div').animate({
				width:"60%",
				height:"20%",
				top:"40%",
				left:"20%"
			},200,function(){
				setTimeout(function(){
					$('.alert>div').hide()
				},1000
			)})
		}
	}
	
</script>

<style>
	.alert>div{
		width:0;
		height:0;
		background-color:#333333;
		border-radius: 16px;
		opacity: .8;
		position:fixed;
		top:50%;
		left:50%;
		z-index:99999;
		
		color:#FFFFFF;
		text-align: center;
	}
	.alert>div>div{
		width:1rem;
		height:1rem;
		border:3px solid #FFFFFF;
		margin:0.4rem auto;
		position:relative;
		border-radius: 50%;
	}
	.alert>div>div>img{
		width:60%;
		height:60%;
		top:20%;
		left:20%;
		position:absolute;
	}
	.alert>div>p{
		font-size:0.36rem;
		
	}
</style>