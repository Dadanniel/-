<template>
	<div class="popupboxwarp" v-show="pupbol">
		<div class="popupbox">
			{{hint}}
		</div>
		<div >
			<div @click="confirmbtn(index)" v-for="(item,index) in list">{{item}}</div>
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				list:["取消","确定"]
			}
		},
		props:["hint"],
		methods:{
			confirmbtn(index){
				this.$store.dispatch("comfirmbtn",index)
				console.log(index)
			}
		},
		computed:{
			pupbol(){
				return this.$store.state.popbol
			}
			
		},
		mounted(){
			$(".popupboxwarp").animate({
				opacity:1,
				top:"40%"
				
			},500)
		}
	}
</script>

<style scoped="scoped">
	.popupboxwarp{
		width:60%;
		position:absolute;
		top:-20%;
		left:20%;
		background:red;
		z-index:999999;
		border-radius: 8px;
		background:#FFFFFF;
		opacity: 0;
	}
	.popupbox{
		width:100%;
		border-bottom:1px solid #DBDBDB;
		box-sizing: border-box;
		font-size:0.18rem;
		text-align: center;
		padding-top:20%;
		padding-bottom:20%;
	}
	.popupboxwarp>div:nth-of-type(2){
		width:100%;
	}
	.popupboxwarp>div:nth-of-type(2)>div{
		float:left;
		text-align: center;
		width:50%;
		height:0.68rem;
		line-height:0.68rem;
		font-size:0.32rem;
		
	}
	.popupboxwarp>div:nth-of-type(2)>div:nth-of-type(1){
		border-right:1px solid #DcDcDc;
		box-sizing: border-box;
		
	}
	.popupboxwarp>div:nth-of-type(2)>div:nth-of-type(1):active{
		background-color:#DcDcDc;
		border-radius: 0 0 0 8px;
	}
	.popupboxwarp>div:nth-of-type(2)>div:nth-of-type(2):active{
		background-color:#DcDcDc;
		border-radius: 0 0  8px 0;
	}
	.popupboxwarp>div:nth-of-type(2)>div:nth-of-type(2){
		color:#FD8F00;
	}
</style>