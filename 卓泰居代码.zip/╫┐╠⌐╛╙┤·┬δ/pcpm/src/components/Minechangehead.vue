<template>
	<div class="Minechangehead">
		<topctfalse :dataname="dataname"></topctfalse>	
		<div id="headimg">
			<img :src="imgstop" alt="">
		</div>
		<div class="btn upload" @click="topimgbtn">上传头像</div>

		<div class="clipbg">
			<div id="clipArea"></div>
			<!-- <div class="loading">正在载入图片...</div> -->
			<div class="footer">
			<dl>
				<dd style="background: #fc8e0d; color: #ffffff;border: none;">打开相机<input type="file" id="file" accept="image/*" ></dd>
				<dd style="background: #fc8e0d; color: #ffffff;border: none;">打开相册<input type="file" id="file" accept="camera" ></dd>
      			<dd id="clipBtn">完成裁剪</dd>
			</dl>
			<div class="back" @click="back">取消</div>
			</div>
		</div>
	</div>
</template>
<script>
	import topctfalse from './topctfalse'
	export default{
		data(){
			return{
				dataname:"头像",
				datass:'',
				bol:false,
				imgstop:"",
				token:window.sessionStorage.token,
				my_data:JSON.parse(window.sessionStorage.my_data)
			}
		},
		components:{
			topctfalse
		},
		methods:{
			topimgbtn(){
				$(".clipbg").fadeIn()				
			},
			back(){
				$(".clipbg").fadeOut()
			},
			imgurlbtn(){
				
				
			}
		},
		mounted(){
			var that=this
			var clipArea = new  PhotoClip("#clipArea", {
				size: [400, 300],//裁剪框大小
				outputSize:[0,0],//打开图片大小，[0,0]表示原图大小
				file: "#file",
				ok: "#clipBtn",
				loadStart: function() { //图片开始加载的回调函数。this 指向当前 PhotoClip 的实例对象，并将正在加载的 file 对象作为参数传入。（如果是使用非 file 的方式加载图片，则该参数为图片的 url）
					$(".loading").removeClass("displaynone");

				},
				loadComplete: function() {//图片加载完成的回调函数。this 指向当前 PhotoClip 的实例对象，并将图片的 <img> 对象作为参数传入。
					$(".loading").addClass("displaynone");

				},
				
				done: function(dataURL) { //裁剪完成的回调函数。this 指向当前 PhotoClip 的实例对象，会将裁剪出的图像数据DataURL作为参数传入。			
					// console.log(dataURL);//dataURL裁剪后图片地址base64格式提交给后台处理
					that.imgstop=dataURL
					console.log(that.imgstop)
					$(".clipbg").fadeOut()
					var client = new OSS({
						accessKeyId: 'LTAIOoh5sY29Z7Iq',
						accessKeySecret: 'E1Hionbt9V2UAQF0da9JzbTCu0Yu6D',
						region: 'oss-cn-shenzhen',
						bucket: '<bucket-name>',
					});
					// co(function* () {
					// 	// put from local file
					// 	console.log("aaaaaaaaa")
					// 	var result = yield client.put('object-key', 'local-file');
					// 	console.log(result) 
					// }).catch(function (err) {
					// 	console.log(err);
					// });
					 var dataurls=that.imgstop
					 var my_dataindex=that.my_data
					 function dataURLtoFile(dataurl, filename) {
						var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
						bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
						console.log(bstr)
						while(n--){
						u8arr[n] = bstr.charCodeAt(n);
						}
						return new File([u8arr], filename, {type:mime});
					}
					var file = dataURLtoFile(dataurls, 'image');
					console.log(file)
					client.multipartUpload('http://xinrongzhontian-p2p.oss-cn-shenzhen.aliyuncs.com/image', file).then(function (res) {
						console.log(res)
					});
					
				}
			});
		}
	}
</script>
<style>
html,body{
	height:100%;
}
.con4{
	width: 300px;
	height: auto;
	overflow: hidden;
	margin: 20px auto;
	color: #FFFFFF;
}

.upload{
width: 100%;
height: 0.88rem;
line-height: 0.88rem;
text-align: center;
display: block;
font-size: 0.28rem;
border:1px solid #DcDcDc;
float: left;
/*margin-top:5.36rem;*/
position: fixed;
background-color:#FFFFFF;
bottom:0.88rem;
left:0;
bottom:0;
}
.upload_pic{
display: block;
width: 100%;
height: 0.88rem;
position: absolute;
left: 0;
top: 0;
opacity: 0;
}
#headimg{
width:2rem;
height:2rem;
border: 1px solid #000;
width:80%;
height:4rem;
margin-left:10%;
margin-top:2rem;
background-color:#FFFFFF;
}
#headimg>img{
	width:100%;
	height:100%;
}
.Minechangehead>img{
	width:60%;
	height:3.8rem;
	position:absolute;
	top:2.1rem;
	left:20%;

}
#saveimg{
	width:100%;
	height:0.88rem;
	border:1px solid #DcDcDc;
	font-size:0.28rem;
	text-align: center;
	line-height: 0.88rem;
	background-color:#FFFFFF;
	position:fixed;
	bottom:0;
	border-top:1px solid #FFFFFF;
}

/*截图上传页面*/
			.clipbg{
				position: fixed;
				background: black;
				top: 0;
				z-index: 999;
				width: 100%;
				height: 100%;
				left: 0;
				display: none;
			}
			.loading{
				position: absolute;
				top: 40%;
				width: 38%;
				left: 31%;
				height: 1.6rem;
				line-height: 1.6rem;
				z-index: 99999;
				text-align: center;
				color: #ffffff;
				border-radius:0.2rem ;
				background: #9f9f9f;
			}
			.clipbg #clipArea{
				width: 90%;
				height:60%;
				margin: auto;
				border:1px solid #666666;
				margin-top:0.5rem;
			}
			.clipbg .footer{
				width: 90%;
				position: fixed;
				left: 5%;
				bottom: 0px;
				text-align: center;
			}
			.clipbg dl{
				background: #ffffff;
				border-radius: 8PX;
				overflow: hidden;
				margin-bottom: 0.2rem;
			}
			.clipbg dd{
				position: relative;
				height: 0.8rem;
				line-height: 0.8rem;
				border-bottom:1px solid #999999 ;
			}
			.clipbg .back{
				height: 0.8rem;
				line-height:0.8rem;
				border-radius:8PX;
				margin-bottom: 0.2rem;
				background: #ffffff;
			}
			.clipbg dd input{
				position: absolute;
				width: 100%;
				height: 100%;
				top: 0;
				left: 0;
				z-index: 11;
				filter:alpha(opacity=0);  
			  -moz-opacity:0;  
			  -khtml-opacity: 0;  
			  opacity: 0; 
			}
</style>