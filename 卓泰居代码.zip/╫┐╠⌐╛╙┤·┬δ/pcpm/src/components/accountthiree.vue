<template>
	<div class="accounttwo" style="padding-bottom:0.98rem">
		<div v-for="(item,index) in list">
			<router-link tag="div" :to="{path:'/accountthirees/'+item.project}">
				<div id="accountop">
					<div  class="xbsd_box_div" :style="{'background-color':item.project_type.color}">{{item.project_type.name}}</div>
					<div>{{item.name}}</div>
					<div>
						<div>{{item.time.split(" ")[0]}}</div>
						<div>{{item.time.split(" ")[1]}}</div>
					</div>
				</div>
				<ul id="accountul">
					<li>
						<div>预投金额</div>
						<div>{{item.amount}}元</div>
					</li>
					<li>
						<div>年利率</div>
						<div>{{item.rate}}%</div>
					</li>
					<li>
						<div>投资期限</div>
						<div>{{item.issue_count}}</div>
					</li>
				</ul>
			</router-link>
			<div class="accountbtnwarp" :class="{accounbottom:item.prompts_message.button===null}">
				<span class="accountbtnwarpspan" :class="{accountbtnwarps:item.prompts_message.button==null}">{{item.prompts_message.msg}}</span>
					<form class="form" :action="gourl" method="post">
						<input type="" v-show="move" name="LoanJsonList" id="" :value="encold" />
						<input type="" v-show="move" name="PlatformMoneymoremore" id="" :value="p"/>
						<input type="" v-show="move" name="TransferAction" id="" value="1"/>
						<input type="" v-show="move" name="Action" id="" value="1"/>
						<input type="" v-show="move" name="TransferType" id="" value="2"/>
						<input type="" v-show="move" name="ReturnURL" id="IdentificationNo" :value="returnurl" />
						<input type="" v-show="move" name="NotifyURL" id="" :value="resul"/>
						<input type="" v-show="move" name="SignInfo" id="SignInfo" :value="Notifysurl"/>
						<input v-show="item.prompts_message.button!==null" class="buttonstye" :class="{bttoncolor:item.prompts_message.button=='债权转让中'}" @click.stop="authenmoves(item,index)" type="button"  :value="item.prompts_message.button"/>
					</form>

			</div>

		</div>
		<div id="loding" v-show="loadingzj">已全部加载..</div>
		<div id="loding" v-show="loading">正在加载更多..</div>
	</div>
</template>

<script>
	import { MessageBox } from 'mint-ui';	
	export default {
		data() {
			return {
				my_data:"",//我的个人数据
	 			move:false,
				list: [],
				showbol: false,
				loadingzj:false,
				loading:false,
				alertfont: "撤销成功",
				n:1,
				overall:"",//全局数据
				token:window.sessionStorage.token,
				gourl: "", //乾多多待支付
				encold: [], //转账列表encode过的
				p: window.sessionStorage.p, //乾多多平台标识
				resul: "", //后台通知网址
				returnurl: "", //前端通知网址
				Notifysurl: "", //秘钥
				LoanJsonList: [], //转账列表没有encode
			}
		},
		components: {
			alert 
 		},
		created() {
			//获取全局数据
			this.overall = JSON.parse(window.sessionStorage.overall);
			this.my_data=JSON.parse(window.sessionStorage.my_data);
			this.gourl = this.$url.MONEYNFIVE;//乾多多待支付
			this.returnurl = this.$url.URL + this.$url.PAYRETURN;//前端通知网址
			this.resul =this.$url.QIANDUODUO +this.overall.TRANSFER_CALLBACK; //转账后台接口
			//获取我的信息
			this._idnexlist();

			function getScrollTop() {　　
				var scrollTop = 0,
					bodyScrollTop = 0,
					documentScrollTop = 0;　　
				if(document.body) {　　　　 bodyScrollTop = document.body.scrollTop;　　 }　　
				if(document.documentElement) {　　　　 documentScrollTop = document.documentElement.scrollTop;　　 }　　 scrollTop = (bodyScrollTop - documentScrollTop > 0) ? bodyScrollTop : documentScrollTop;　　
				return scrollTop;
			}
			//文档的总高度 
			function getScrollHeight() {　　
				var scrollHeight = 0,
					bodyScrollHeight = 0,
					documentScrollHeight = 0;　　
				if(document.body) {　　　　 bodyScrollHeight = document.body.scrollHeight;　　 }　　
				if(document.documentElement) {　　　　 documentScrollHeight = document.documentElement.scrollHeight;　　 }　　 scrollHeight = (bodyScrollHeight - documentScrollHeight > 0) ? bodyScrollHeight : documentScrollHeight;　　
				return scrollHeight;
			}
			//浏览器视口的高度 
			function getWindowHeight() {　　
				var windowHeight = 0;　　
				if(document.compatMode == "cSS1compat") {　　　　 windowHeight = document.documentElement.clientHeight;　　 } else {　　　　 windowHeight = document.body.clientHeight;　　 }　　
				return windowHeight;
			}
			var that = this
			window.onscroll =() =>{
				//判断滑到底部
				if(getScrollTop() + getWindowHeight() == getScrollHeight()) {
				　this._idnexlist();
				}
			}

		},
		methods: {
			_idnexlist(){
				var url = this.$url.MY_PRE_INVESTMENT
				this.$http.get(url+"?page=" + this.n++, { headers: { 'Authorization': this.token} })
				.then((response) => {
					for(var i = 0; i < response.data.results.length; i++) {
						if(response.data.results[i].project_type==null){
							response.data.results[i].project_type="#FFF0F5"
						}
						if(response.data.results[i].issue_type == "MONTH") {
							response.data.results[i].issue_count = response.data.results[i].issue_count + "个月"
						} else {
							response.data.results[i].issue_count = response.data.results[i].issue_count + "天"
						}
						for(var l = 0; l < this.overall.project_type_list.length; l++) {
							if(response.data.results[i].project_type == this.overall.project_type_list[l].code) {
								response.data.results[i].project_type = this.overall.project_type_list[l] 	
							}
						}

					}
					
					this.loading=true
					setTimeout(()=>{
						this.loading=false
					},1000)
					this.list = this.list.concat(response.data.results)
					window.sessionStorage.accountthiree = JSON.stringify(this.list)
				})
				.catch(()=>{
					this.loadingzj=true
					setTimeout(()=>{
						this.loadingzj=false
					},1000)
					
				})
			},
			
			
			authenmoves(item,index) {
				var id = item.id
				if(item.prompts_message.click == true) {

					if(item.prompts_message.button == "撤销") {
						this.$http.post(this.$url.CANCEL_INVEST, {
								investment_id: item.id
							},{headers:{
								Authorization:this.token
							}})
							.then((response) => {
								if(response.data.code == 0) {
									this.showbol = true;
								
									setTimeout(()=>{
										this.showbol = false
									}, 1200)
									this.n=1
									this.list=[]
									this._idnexlist();
								}
							})

					}
					
					if(item.prompts_message.button == "债权转让") {
						window.sessionStorage.accountitemid = item.id
						this.$router.push({ name: 'accountmakeover' })
						this.$store.dispatch("authenmoves")
					}

					if(item.prompts_message.button == "支付") {
						this._payment(item,index);
					}

				}

			},
			 _payment(item,index) {//支付跳往乾多多的接口
	  console.log(item) 
	  let id = item.id;
	  this.LoanJsonList = []; //点击前先让转账列表变为空
	  console.log(this.$url.URL + this.$url.PAY_INVEST)
	   if (Number(item.amount) <= Number(this.my_data.available_remain)) {
		    this.$http
          .post(
            this.$url.URL + this.$url.PAY_INVEST,
            {
              investment_id: id
            },
            { headers: { Authorization:this.token } }
          )
          .then(response => {
            let list = response.data.LoanJsonList;
            console.log(response);
            if (list !== undefined) {
              for (let i = 0; i < list.length; i++) {
                if (list[i].SecondaryJsonList.length > 0) {
                  list[i].SecondaryJsonList = JSON.stringify(
                    list[i].SecondaryJsonList
                  );
                } else {
                  delete list[i].SecondaryJsonList;
                }
                this.LoanJsonList.push(list[i]);
              }
              this.LoanJsonList = JSON.stringify(this.LoanJsonList);
              this.$http
                .post(this.$url.URL + this.$url.ENCODEURL, {
                  data: this.LoanJsonList
                })
                .then(response => {
                  this.encold = response.data.data;
                });

              let str =
                this.LoanJsonList +
                this.p +
                "112" +
                this.returnurl +
                this.resul;
              this.$http
                .post(this.$url.URL + this.$url.SIGNATURE, {
                  //获取秘钥接口
                  str: str
                })
                .then(response => {
                  this.Notifysurl = response.data.result;
                //   this.$confirm("是否前往乾多多支付页面?", "提示", {
                //     confirmButtonText: "确定",
                //     cancelButtonText: "取消",
                //     type: "warning"
                //   })
                //     .then(() => {
                //       var forms = document.querySelectorAll(".form");
                //       forms[index].submit();
                //     })
				//     .catch(() => {});
				MessageBox.confirm('是否前往乾多多投资页面?').then(action => {
					var forms = document.querySelectorAll(".form");
                    forms[index].submit();
				});
                });
            } else {
			   MessageBox.alert(response.data.msg, "提示")
            }
          });
	   }else{
		   MessageBox.alert("账户余额不足", "提示")
	   }
    }
		}
	}
</script>

<style scoped="scoped">
	#accountop {
		height: 0.88rem;
		width: 100%;
		background-color: #FFFFFF;
		border-bottom: 1px solid #DcDcDc;
		overflow: hidden;
		margin-top: 0.1rem;
		position: relative;
	}
	
	#accountop>div {
		float: left;
		font-size: 0.3rem;
	}
	
	.accounttwo {
		width: 100%;
		overflow: hidden;
	}
	
	.xbsd_box_div {
		width: 0.44rem;
		height: 0.28rem;
		font-size: 0.16rem!important;
		line-height: 0.28rem;
		text-align: center;
		background: red;
		border-radius: 4px;
		position: absolute;
		top: 0.27rem;
		left: 0.24rem;
		color: #FFFFFF;
	}
	
	.xbsd_box_div1 {
		background-color: red!;
	}
	
	.xbsd_box_div2 {
		background-color: yellow;
	}
	
	.xbsd_box_div3 {
		background-color: beige;
	}
	
	.xbsd_box_div4 {
		background-color: black;
	}
	
	.xbsd_box_div5 {
		background-color: blue;
	}
	
	@media(max-width:400px)and (min-width:300px) {
		.xbsd_box_div {
			width: 25px;
			height: 14px;
			font-size: 12px;
			line-height: 14px;
			text-align: center;
			background: red;
			border-radius: 4px;
			position: absolute;
			top: 0.26rem;
			left: 0.24rem;
			color: #FFFFFF;
		}
	}
	
	#accountop>div:nth-of-type(2) {
		margin-left: 0.88rem;
		height: 0.88rem;
		line-height: 0.88rem;
	}
	
	#accountop>div:nth-of-type(3) {
		float: right;
		margin-right: 0.24rem;
		font-size: 0.2rem;
		color: #666666;
		height: 0.88rem;
		margin-top: 0.15rem;
		text-align: center;
		border-top: 1px solid #FFFFFF;
		box-sizing: border-box;
	}
	
	#accountop>div:nth-of-type(3)>div:nth-of-type(2) {
		margin-top: 0.1rem;
	}
	
	#accountul {
		list-style: none;
		width: 100%;
		float: right;
		background-color: #FFFFFF;
	}
	
	#accountul>li {
		width: 80%;
		border-bottom: 1px solid #DcDcDc;
		line-height: 0.88rem;
		overflow: hidden;
		background-color: #FFFFFF;
		float: right;
	}
	
	#accountul>li>div:nth-of-type(1) {
		float: left;
		font-size: 0.28rem;
	}
	
	#accountul>li>div:nth-of-type(2) {
		float: right;
		font-size: 0.26rem;
		margin-right: 0.24rem;
	}
	
	#accountul>li:nth-of-type(3) {
		border: none;
	}
	
	.accountbtnwarp {
		width: 100%;
		height: 1rem;
		font-size: 0.26rem;
		background-color: #fde8cd;
		position: relative;
		margin-top: 2.64rem;
	}
	
	.accounbottom {
		background-color: #DcDcDc !important;
	}
	
	.accountbtnwarpspan {
		width: 100%;
		margin-left: 0.24rem;
		display: inline-block;
		height: 1rem;
		line-height: 1rem;
	}
	
	.buttonstye {
		width: 1.9rem;
		height: 0.6rem;
		text-align: center;
		line-height: 0.6rem;
		color: #FFFFFF;
		background-color: #FD8F00;
		border-radius: 6px;
		position: absolute;
		top: 0.2rem;
		right: 0.24rem;
		display: inline-block;
		border: none;
	}
	
	.bttoncolor {
		background-color: #999999;
	}
	
	.accountbtnwarps {
		text-align: center;
		width: 95%;
	}
	#loding{
		width:30%;
		height:0.68rem;
		text-align: center;
		line-height: 0.68rem;
		background:rgba(0,0,0,0.6);
		position:fixed;
		bottom:1.1rem;
		z-index:9999;
		left:35%;
		border-radius: 6px;
		color:#FFFFFF;
		
		}
</style>