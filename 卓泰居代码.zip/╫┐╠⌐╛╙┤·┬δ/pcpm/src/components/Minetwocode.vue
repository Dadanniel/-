<template>
<div class="Minetwocode">
	<div class="headname">
			<div @click="goMinezx">
				<div class="headnamelist"><img src="../imgs/homeqietu/fanhui.png"/></div>
			</div>
			<div id="headname_left">我的二维码</div>
			<img src="../imgs/homeqietu/zhuanfathree.png" alt="" />
	</div>
	<div class="Minecodewarp">
		<div class="Minecodewarphead">
			<img :src="srcimg" alt="" />
			{{personaldetails.member_name}}
		</div>
		<div class="Mine_erwm">
			<img src="http://192.168.1.164:8000/qrcode/https://www.baidu.com/"/>
		</div>
		<div class="Mine_setcenter">
		<div>扫一扫轻松加入</div>
		<div>全民金服</div>
		</div>
	</div>
</div>
</template>

<script>
 	export default{
 		data(){
 			return{
 			personaldetails:"",
 			srcimg:window.localStorage.headimg,
 			}
 		},
 		created(){
 			this.personaldetails=JSON.parse(window.sessionStorage.personaldetails)
 			
 		},
 		methods:{
 			goMinezx(){
 				this.$router.go(-1)
 			}
 		}
 	}
</script>

<style>
html,body{
	height:100%;
	
}
.headname{
		position:fixed;
		left:0;
		top:0;
	}
	.headname>img{
		position:fixed;
		width:0.37rem;
		height:0.35rem;
		right:0.24rem;
		top:0.27rem;
	}
	.Minetwocode{
		width:100%;
		height:100%;
		background:#333333;
	}
	.Minecodewarp{
		width:4.5rem;
		height:6rem;
		background-color:#FFFFFF;
		position:relative;
		top:2.88rem;
		margin:auto;
	}
	.Minecodewarphead{
		width:100%;
		height:1.8rem;
		line-height: 1.8rem;
		font-size:0.3rem;
		color:#333333;
		text-indent: 1.8rem;
	}

	.Minecodewarphead>img{
		width:1rem;
		height:1rem;
		position:absolute;
		top:0.4rem;
		left:0.4rem;
	}
	.Mine_erwm{
		width:3.3rem;
		height:3.3rem;
		background-color:#333333;
		margin:0 auto;
		text-align: center;
	}
	.Mine_erwm>img{
		width:100%;
		height:100%;
	}
	.Mine_setcenter{
		margin:0.33rem auto;
		font-size:0.26rem;
		color:#2F81FD;
		margin-left:0.65rem;
	}
	.Mine_setcenter>div{
		float:left;
	
	}
	.Mine_setcenter>div:nth-of-type(2){
		margin-left:0.3rem;
	}
</style>
