<template>
	<div class="Minedeposit">
		<topct :dataname="dataname"></topct>
		<div class="minedepositliwarp">
			<ul id="minedepositli">
				<li><p>充值金额</p>
					<input type="text" v-model="money"/>
				</li>
			</ul>
			<div>预计充值到帐时间 24 小时内</div>
			<div>
			<form :action="gourl" method="post" name="myform">
				<input type="" v-show="move" name="RechargeMoneymoremore" id="" :value="data.deposit_id" />
				<input type="" v-show="move" name="PlatformMoneymoremore" id="" :value="p"/>
				<input type="" v-show="move" name="OrderNo" id="RealName" :value="order_no"/>
				<input type="" v-show="move" name="Amount" id="RealName" :value="money" />
				<input type="" v-show="move" name="RechargeType" id="RechargeType" value="2"/>					
				<input type="" v-show="move" name="FeeType" id="FeeType" value="1"/>
				<input type="" v-show="move" name="ReturnURL" id="ReturnURL" :value="returnurl" />
				<input type="" v-show="move" name="NotifyURL" id="NotifyURL" :value="notifyurl" />
				<input type="" v-show="move" name="SignInfo" id="" :value="result" />
				<input class="submits" type="button" value="确定" @click="submitbtn"/>
			</form>
			</div>
		</div>
	</div>
</template>

<script>
	import topct from'./topct'
	import { MessageBox } from 'mint-ui';
	export default{
		data(){
			return{
				dataname:"充值",
				gourl:"",//钱多多充值接口
				move:false,
				money:"",
				result:"",//秘钥
				p:"",//平台钱多多标识
				data:"",
				order_no:"",//充值提现获取订单号
				returnurl:"",//钱多多前端返回页面
				notifyurl:"",//钱多多后台返回页面
				token:window.sessionStorage.token
			}
		},
		created(){
			this.gourl=this.$url.MONEYNTHREE//充值接口
			this.data = JSON.parse(window.sessionStorage.my_data)//个人资料
			this.p=window.sessionStorage.p
			this.returnurl=this.$url.URL+this.$url.PAYRETURN,//钱多多前端返回页面
			this.notifyurl = this.$url.QIANDUODUO+JSON.parse(window.sessionStorage.overall).RECHARGE_CALLBACK//充值后台接收
		},
		methods:{
			submitbtn(){
				//获取签名
						this.$http.post(this.$url.URL+this.$url.MONEY_IN_OUT,{//充值提现获取订单号
							 type:"RECHARGE",
							 amount:this.money
						},{headers: {'Authorization':this.token}})
						.then((response)=>{
							this.order_no=response.data.order_no
							console.log(this.order_no)
							var str=this.data.deposit_id+this.p+this.order_no+this.money+"21"+this.returnurl+this.notifyurl
								console.log(str)
								this.$http.post(this.$url.URL+this.$url.SIGNATURE,{//获取秘钥接口
									str: str
								})
								.then((response) => {
										this.result = response.data.result
										console.log(this.result)
										if(response.status=="200"&&this.Notifysurl!==""){
										MessageBox.confirm('是否前往充值页面?').then(action => {
											myform.submit()
										});
										}
								})					
						})
						.catch(()=>{
							MessageBox('提示','获取订单号失败')
						})	
			}
		},
		components:{
			topct
		}
	}
</script>

<style scoped="scoped">
	html,body{
		height:100%;

	}
	*{
		margin:0;
		padding:0;
	}
	.minedepositliwarp{
		width:100%;
		position:absolute;
		top:1.08rem;
		
	}
	#minedepositli{
		list-style: none;
		width:100%;
	}
	#minedepositli>li{
		width:100%;
		height:0.88rem;
		background-color:#FFFFFF;
		line-height: 0.88rem;
		position:relative;
		margin-bottom:0.2rem;
		font-size:0.32rem;
	}
	#minedepositli>li>p{
		display: inline-block;
	}
	#minedepositli>li>p:nth-of-type(1){
		margin-left:0.24rem;
	}
	#minedepositli>li>input{
		width:70%;
		outline: none;
		border:none;
		margin-left:0.24rem;
	}
	.minedepositliwarp>div:nth-of-type(1){
		font-size:0.26rem;
		color:#666666;
		margin-left:0.24rem;
	}
	.minedepositliwarp>div:nth-of-type(2){
		width:6.84rem;
		height:0.8rem;
		background-color: #Fc8E0D;
		color:#FFFFFF;
		font-size: 0.34rem;
		text-align: center;
		line-height: 0.8rem;	
		margin:auto;
		margin-top:2rem;
		border-radius: 6px;
	}
	.submits{
		width:100%;
		height:100%;
		background:#Fc8E0D;
		border:none;
		outline: none;
		color:#ffffff;
	}
</style>