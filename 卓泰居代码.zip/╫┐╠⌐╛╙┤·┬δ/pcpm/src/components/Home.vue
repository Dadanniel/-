<template>
	<div class="home">
		<ul class="home_thisbox" :class="{home_thisanimation1:animationhome}">
			<li>新手指南</li>
			<li>邀请好友</li>
			<li>客户电话</li>
		</ul>
		<div class="headname">
			<div id="headname_left">首页</div>
			<div id="headname_right"><img src="../imgs/homeqietu/shouyegengduo.png" @click='homebtn1'></div>
		</div>
		<div class="centers">
		  		<!--<div class="swiper-container">
			    <div class="swiper-wrapper">
			        <div class="swiper-slide" v-for="item in alldata.banner_list">
			        	<img :src="item.url" alt="" />
			        </div>
			    </div>
			    <!-- 如果需要分页器 -->
			    <!--<div class="swiper-pagination"></div>-->
			    <mt-swipe :auto="4000">
				  <mt-swipe-item v-for="item in alldata.banner_list">
				  	<img :src="item.url" alt="" />
				  </mt-swipe-item>
				  
				</mt-swipe>
			</div>
		  <!--标预告-->
		  	<router-link tag="ul" to="/foreshow" id="foreshow" >
				<li><img src="../imgs/homeqietu/xinbiaosudi.png"/></li>
				<li>标预告</li>
				
				<li id="moveli">
					<div id="movediv">
						<div v-for="item in alldata.pre_project_list">
							{{item.name}}
						</div>
					</div>
				</li>
			</router-link>
		
		<!--通道-->
			<div id="warpaisle">
				<div @click="borrowbtn">
					<div class="warpaisleimgs"><img src="../imgs/homeqietu/shouqian.png" alt="" /></div>
					<div class="warpaislefont">借款通道</div>
				</div>
				<router-link tag="div" to="/invest" @click.native="goinvest">
					<div class="warpaisleimgs"><img src="../imgs/homeqietu/qianpiaozi.png" alt="" /></div>
					<div class="warpaislefont">投资通道</div>
				</router-link>
				<div @click="repaybtn">
					<div class="warpaisleimgs"><img src="../imgs/homeqietu/yinghangka.png"/></div>
					<div class="warpaislefont">还款通道</div>
				</div>
			</div>
			<!--统计-->
			<div id="rental">
				<div>
					<div>平台累计交易金额</div>
					<div>{{alldata.total_amount}}</div>
				</div>
				<div>
					<div>交易总笔数</div>
					<div>{{alldata.total_times}}</div>
				</div>
			</div>
			<!--首页注册接口-->
			<div id="homeregister">
				<img src="../imgs/homeqietu/shouyeguanggao.jpg" alt="">
			</div>
			<!--新标速递-->
			<router-link tag="div" id="xb_sd" to="/xbsd" style="background:white">
				<div>新标速递</div>
				<div><img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" /></div>
			</router-link>
			<ul id="bottomcenter" style="background-color:#FFFFFF">
				<li v-for="item in alldata.new_project_list" @click="gobtn(item)">
					<div :style="{background:item.project_type.color}">{{item.project_type.name}}</div>
					<div>{{item.name}}</div>
					<div>年利率</div>
					<div>{{item.rate}}%</div>
				</li>
			</ul>
			<div id="qddtg">
				<div>
					<div><img src="../imgs/homeqietu/zhanghuxuanzhongtwo.png"/></div>
					<div>账户资金由乾多多第三方资金托管</div>
					<div>安全更高效</div>
				</div>
				
			</div>
		</div>
		
	</div>
</template>
<script>
import { MessageBox } from 'mint-ui';	
  export default {
  	
    name: 'carrousel',
    //数据存数位置
    data() {
      return {
        alldata:"",//我的首页数据
        animationhome:false,
        data:""//全局数据
      }
    },
    //数据获取
    created(){
			//获取全局数据存储缓存
			if(window.sessionStorage.overall==undefined){
				var token = window.sessionStorage.token
				this.$http.post(this.$url.AGLOBAL_DATA)
				.then((response)=>{
					window.sessionStorage.overall=JSON.stringify(response.data)
					window.sessionStorage.p=response.data.PLATFORM_MONEY_MORE_MORE
					this.data=response.data
				})
			}else{
				this.data = JSON.parse(window.sessionStorage.overall)
				window.sessionStorage.p=this.data.PLATFORM_MONEY_MORE_MORE
//				console.log(this.data)
			}
			
			
    		this.$http.post(this.$url.INDEX_DATA)
			.then((response)=>{					
					this.alldata=response.data 
					for(let i=0;i<this.alldata.new_project_list.length;i++){
						for(let l=0;l<this.data.project_type_list.length;l++){
							if(this.alldata.new_project_list[i].project_type==this.data.project_type_list[l].code){
								this.alldata.new_project_list[i].project_type=this.data.project_type_list[l]
							}
						}
					}
					this.alldata=response.data
					this.$nextTick(() => {
						var animates=0;
						var setmove = setInterval(()=>{
							animates=animates-0.8;
							  $("#movediv").animate({top:animates+"rem"});
							  if(animates==-3.2){
							  	animates=0.8
							  }
							  if(this.$route.name!=='Home'){
							  	 clearInterval(setmove)
							  }
						},3000)
					})
			})
			


    },
 	//计算属性
    computed: {

    },
    //计算方法
    methods:{
		gobtn(item){
			this.$router.push({path:'/signdetails/'+item.id})
			sessionStorage.removeItem('particulars')
		},
		homebtn1(){
			this.animationhome=!this.animationhome
		},
		goinvest(){
			this.$store.dispatch("goinvest")
		},
		borrowbtn(){
			if(window.sessionStorage.token==undefined){
				MessageBox.alert("还未登录，请先登录！", "提示")
			}else{
				this.$router.push("/borrowmoney")
			}
		},
		repaybtn(){
			if(window.sessionStorage.token==undefined){
				MessageBox.alert("还未登录，请先登录！", "提示")
			}else{
				this.$router.push("/repayments")
			}
		}

	},
	mounted(){
//		  var mySwiper = new Swiper ('.swiper-container', {
//		    autoplay:3000,//可选选项，自动滑动
//			pagination:'.swiper-pagination',//分页器
//			prevButton:'.swiper-button-prev',
//			loop: true,
//			autoplayDisableOnInteraction:false
//		  })     
	}
  }
</script>
	
<style type="text/css">
	@keyframes myfirst{
		from{
		opacity: 0;
		height:0rem;
		display: block;
		};
		to{
		opacity: 1;
		height:1.8rem;
		display: block;
		}
	}
	html,body{
		width:100%;
		height:100%;
	}
	#foreshow{
		margin-top:0.88rem;
	}
	#foreshow>li{
		float:left;
		vertical-align: middle;
		
	}
	.headname{
		background-color:#Fc8E0D;
	}
	#headname_right>img{
		position:fixed;
		width:0.4rem;
		height:0.4rem;
		top:0.24rem;
		right:0.24rem;
		vertical-align: middle;
		
	}
	.centers{
		position:relative;
		top:0.88rem;
		width:100%;
		height:4rem;
	}
	.centers img{
		width:100%;
		height:100%;
	}

	/*新标速递*/
	#foreshow{
		width:100%;
		height:0.8rem;
		list-style: none;
		
		background-color:#FFFFFF;
	}
	#foreshow>li:nth-of-type(1){
		margin-left:0.24rem;
		height:0.8rem;	
		line-height: 0.8rem;
		
	}
	#foreshow>li>img{
		width:0.4rem;
		height:0.32rem;
		vertical-align: middle;
		margin-top:-0.06rem;
	}
	#foreshow>li:nth-of-type(2){
		font-size:0.3rem;
		color:#fd8f00;
		margin-left:0.2rem;
		margin-right:0.3rem;
		font-weight: bold;
		vertical-align: middle;
		border-right:2px solid #fd8f00;
		height:0.4rem;
		line-height: 0.4rem;
		margin-top:0.2rem;
		padding-right:0.2rem;
	}
	#moveli{
		font-size:0.28rem;
		color:#333333;
		float:left;
		vertical-align: middle;
		position:relative;
		line-height: 0.8rem;
		height:0.8rem;
		width:60%;
		overflow:hidden;
	}
	#movediv{
		position: absolute;
		width:100%;
		
	}
	#movediv>div{
		width:100%;
		height:0.8rem;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
	}
	.home_thisbox{
		list-style: none;
		width:1.5rem;
		line-height: 0.6rem;
		position:fixed;
		top:0.88rem;
		right:0;
		height:0;
		overflow:hidden;
		z-index:999999
	}
	.home_thisanimation1{

		height:1.8rem;

		animation:myfirst 0.6s linear;
	}
	.home_thisbox>li{
		width:1.5rem;
		height:0.6rem;
		border:1px solid #bbbbbb;
		background-color:#999999;
		opacity: 0.6;
		box-sizing: border-box;
		font-size:0.24rem;
		text-align: center;
		
	}
	#warpaisle{
		width:100%;
		height:2.7rem;
		background-color:#f5f5f5;
		font-size:0.32rem;
	}
	#warpaisle>div{
		width:33.333333%;
		float:left;
		
	}
	.warpaisleimgs{
		width:100%;
		text-align: center;
	}
	.warpaisleimgs>img{
		width:1rem;
		height:1rem;
		margin-top:0.6rem;
		
	}
	.warpaislefont{
		font-size:0.32rem;
		color:#333333;
		margin-top:0.2rem;
		text-align: center;
		font-weight: bold;
	}
	#rental{
		width:100%;
		height:1.12rem;
		background-color:#ffffff;
	}
	#rental>div{
		width:50%;
		float:left;
	}
	#rental>div>div:nth-of-type(1){
		font-size:0.28rem;
		color:#333333;
		text-align: center;
		margin-top:0.223rem;
		font-weight: bold;
	}
	#rental>div>div:nth-of-type(2){
		font-size:0.20rem;
		color:#D83515;
		text-align: center;
		margin-top:0.18rem;
	}
	#homeregister{
		width:100%;
		height:1.6rem;
		background-color:#F5F5F5;
		padding:0.2rem 0;
	}
	#homeregister>img{
		width:100%;
		height:100%;
	}

	#xb_sd{
		width:100%;
		height:0.7rem;
		background-color:#fffff;
		line-height: 0.7rem;
		border-bottom: 1px solid #dcdcdc;
	}
	#xb_sd>div:nth-of-type(1){
		float:left;
		color:#FD8F00;
		font-size:0.34rem;
		margin-left:0.24rem;
		vertical-align: middle;
		font-weight: bold;
	}
	#xb_sd>div:nth-of-type(2){
		float:right;
		margin-right:0.24rem;
		vertical-align: middle;
	}
	#xb_sd>div>img{
		width:0.17rem;
		height:0.3rem;
		vertical-align: middle;
		margin-top:-0.1rem
	}
	#bottomcenter{
		width:100%;
		list-style: none;
	}
	#bottomcenter>li{
		width:100%;
		height:0.7rem;
		line-height: 0.7rem;
		border-top:1px solid #DcDcDc;
	}
	#bottomcenter>li>div{
		float:left;
		
	}
	#bottomcenter>li>div:nth-of-type(1){
		width:0.44rem;
		height:0.28rem;
		font-size:0.16rem;
		background-color:red;
		text-align: center;
		line-height: 0.28rem;
		margin-left:0.24rem;
		margin-right:0.2rem;
		border-radius: 4px;
		margin-top:0.2rem;
		color:#FFFFFF;
		overflow: hidden;
	}
	@media  (min-width:300px) and (max-width: 400px) { 
	    #bottomcenter>li>div:nth-of-type(1){
			width:26px;
			height:14px;
			font-size:12px;
			background-color:red;
			line-height:14px;
			margin-top:0.15rem;
		}
	}
	#bottomcenter>li>div:nth-of-type(2){
		font-size:0.28rem;
		width:55%;
		height:100%;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
	}
	#bottomcenter>li>div:nth-of-type(3){
		font-size:0.28rem;
		margin-left:0.4rem;
	}
	#bottomcenter>li>div:nth-of-type(4){
		font-size:0.28rem;
		margin-left:0.08rem;
		color:#d83515;
	}
	#bottomcenter>li:nth-of-type(1){
		border-top:none;
	}
	#qddtg{
		width:100%;
		height:0.7rem;
		background-color:#F5F5F5;
		line-height: 0.7rem;
		margin-bottom:0.98rem;
		text-align: center;
	}
	#qddtg>div{
		display: inline-block;
	}
	#qddtg>div>div{
		float:left;
		font-size:0.24rem;
		margin-left:0.2rem;
		vertical-align: bottom;
		display: inline-block;
	}
	#qddtg>div>div>img{
		height:0.35rem;
		margin-top:0.1755555rem;
		/*margin-left:0.8rem;*/
		vertical-align:top;
	}
	.bannerimg{
		width:100%;
		height:3.8rem;
	}
</style>