<template>
<div class="Minvitefriends">
	<div>
		<topct :dataname="dataname"></topct>
		<router-link to="/Mineshare">
			<div class="Mineitefriendstop">
				分享记录
			</div>
		</router-link>
		
	</div>
	<div id="friendswarp">
		<div id="friendtop">
			邀请码邀请
		</div>
		<div id="friendtextwarp">
			我的邀请码
			<span>{{Invitation}}</span>
		</div>
		<div id="friendbottom">
			更多邀请方式
		</div>
		<div id="friend_botom">
			<div @click="wechatFriend">
				<img src="../imgs/mineimgs/weixindenglu.png" alt="" />
			</div>
			<div @click="wechatTimeline">
				<img src="../imgs/mineimgs/pengyouquanfengx.png" alt="" />
			</div >
			<div @click="qqFriend">
				<img src="../imgs/mineimgs/qqotuxiang.png" alt="" />
			</div>
			<div @click="weibo">
				<img src="../imgs/mineimgs/xinlangfengxiang.png" alt="" />
			</div>
		</div>
	</div>
	
</div>
</template>
<script>
	import NativeShare from'../../static/NativeShare'
	import topct from './topct'
	export default{
		data(){
			return{
				dataname:"邀请好友",
				Invitation:13245
			}
		},
		components:{
			topct
		},
		methods:{
			wechatFriend(){
				var nativeShare = new NativeShare()
				console.log(nativeShare)
		       	nativeShare.setShareData({
			    icon: 'https://pic3.zhimg.com/v2-080267af84aa0e97c66d5f12e311c3d6_xl.jpg',
//			    link: 'http://192.168.1.141:8080/#/',
			    title: '全民金服',
			    desc: '全民金服介绍',
			    from: '@fa-ge',
				})
		       // 唤起浏览器原生分享组件(如果在微信中不会唤起，此时call方法只会设置文案。类似setShareData)
				try {
					nativeShare.call('wechatFriend')
				    // 如果是分享到微信则需要 nativeShare.call('wechatFriend')
				    // 类似的命令下面有介绍
				} catch(err) {
				  // 如果不支持，你可以在这里做降级处理
				}
			},
			wechatTimeline(){
				var nativeShare = new NativeShare()
				console.log(nativeShare)
		       	nativeShare.setShareData({
			    icon: 'https://pic3.zhimg.com/v2-080267af84aa0e97c66d5f12e311c3d6_xl.jpg',
//			    link: 'http://192.168.1.141:8080/#/',
			    title: '全民金服(邀请码为12345)',
			    desc: '全民金服介绍,',
			    from: '@fa-ge',
				})
		       // 唤起浏览器原生分享组件(如果在微信中不会唤起，此时call方法只会设置文案。类似setShareData)
				try {
					nativeShare.call('wechatTimeline')
				    // 如果是分享到微信则需要 nativeShare.call('wechatFriend')
				    // 类似的命令下面有介绍
				} catch(err) {
				  // 如果不支持，你可以在这里做降级处理
				}
			},
			qqFriend(){
				var nativeShare = new NativeShare()
				console.log(nativeShare)
		       	nativeShare.setShareData({
			    icon: 'https://pic3.zhimg.com/v2-080267af84aa0e97c66d5f12e311c3d6_xl.jpg',
//			    link: 'http://192.168.1.141:8080/#/',
			    title: '全民金服',
			    desc: '全民金服介绍',
			    from: '@fa-ge',
				})
		       // 唤起浏览器原生分享组件(如果在微信中不会唤起，此时call方法只会设置文案。类似setShareData)
				try {
					nativeShare.call('qqFriend')
				    // 如果是分享到微信则需要 nativeShare.call('wechatFriend')
				    // 类似的命令下面有介绍
				} catch(err) {
				  // 如果不支持，你可以在这里做降级处理
				}
			},
			weibo(){
				var nativeShare = new NativeShare()
				console.log(nativeShare)
		       	nativeShare.setShareData({
			    icon: 'https://pic3.zhimg.com/v2-080267af84aa0e97c66d5f12e311c3d6_xl.jpg',
//			    link: 'http://192.168.1.141:8080/#/',
			    title: '全民金服',
			    desc: '全民金服介绍',
			    from: '@fa-ge',
				})
		       // 唤起浏览器原生分享组件(如果在微信中不会唤起，此时call方法只会设置文案。类似setShareData)
				try {
					nativeShare.call('weibo')
				    // 如果是分享到微信则需要 nativeShare.call('wechatFriend')
				    // 类似的命令下面有介绍
				} catch(err) {
				  // 如果不支持，你可以在这里做降级处理
				}
			}
		},
		mounted(){
			
		}
	}
</script>

<style>
	.Minvitefriends{
		width:100%;
	}
	.Mineitefriendstop{
		position:absolute;
		font-size:0.26rem;
		color:#FFFFFF;
		top:0.3rem;
		right:0.24rem;
		z-index: 999;
	}
	#friendswarp{
		width:100%;
		position:absolute;
		top:1.28rem;
		left:0;
	}
	#friendtop{
		margin-left:0.24rem;
		font-size:0.3rem;
		color:#D83515;
	}
	#friendtextwarp{
		text-indent: 0.24rem;
		width:100%;
		height:0.88rem;
		margin-top:0.2rem;
		line-height: 0.88rem;
		font-size:0.31rem;
		background-color:#FFFFFF;
	}
	#friendtextwarp>span{
		display: inline-block;
		margin-left:0.1rem;
		color:#2F81FD;
	}
	#friendbottom{
		font-size:0.3rem;
		color:#D83515;
		margin-left:0.24rem;
		margin-top:0.6rem;
	}
	#friend_botom{
		width:100%;
	}
	#friend_botom>div{
		float:left;
		width:25%;
		text-align: center;
	}
	#friend_botom>div>img{
		width:0.9rem;
		height:0.9rem;
	}
</style>