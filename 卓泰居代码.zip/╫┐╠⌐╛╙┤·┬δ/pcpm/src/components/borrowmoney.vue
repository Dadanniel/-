<template>
	<div class="borrowmoney">
		<topct :dataname="dataname"></topct>
		<div class="money" >
			 <div class="monetdiv" @click="moneyclick1">
			 	<div>标的类型</div>
			 	<div class="monetdivtext1">{{moneycontent1}}</div>
			 	<div :class="{rightarrowd1:arrowsbol1}" class="rightarrows"></div>
			 </div>
			 <div class="monetdiv">
			 	<div>借款金额</div>
			 	<input type="text" placeholder="请输入你的金额" v-model="moneycontent6"/>
			 	
			 </div>
			 <div class="monetdiv" @click="moneyclick2">
			 	<div>借款期限</div>
			 	<div class="monetdivtext2" v-show="showbol">{{moneycontent2}}</div>
			 	<div class="monetdivtext3" v-show="!showbol">可以选择年或者日</div>
			 	<div :class="{rightarrowd2:arrowsbol2}" class="rightarrows"></div>
			 </div>
			 <div class="monetdiv" @click="moneyclick3">
			 	<div>借款用途</div>
			 	<div class="monetdivtext3">{{moneycontent3}}</div>
			 	<div :class="{rightarrowd3:arrowsbol3}" class="rightarrows"></div>
			 </div>
			 <div class="monetdiv" @click="moneyclick5">
			 	<div>满标期限</div>
			 	<div class="monetdivtext5">{{moneycontent5}}</div>
			 	<div :class="{rightarrowd5:arrowsbol5}" class="rightarrows"></div>
			 </div>
			 <div class="monetdiv"  @click="moneyclick4">
			 	<div>还款方式</div >
			 	<div class="monetdivtext4">{{moneycontent4}}</div>
			 	<div :class="{rightarrowd4:arrowsbol4}" class="rightarrows"></div>
			 </div>
			 <div id="borowmoneybut" @click="clickbtn">提交</div>
		</div>
	</div>
</template>

<script>
	import Picker from 'better-picker'
	import topct from '@/components/topct'
	import {MessageBox} from 'mint-ui';
	export default{
		data(){
			return{
				data:'',
				dataname:"借款通道",
				arrowsbol1:false,
				arrowsbol2:false,
				arrowsbol3:false,
				arrowsbol4:false,
				arrowsbol5:false,
				datanames:[],
				datalist:[],
				purpose:[],
				bondloan1:[],
				bondloan:[],
				moneycontent4:"",
				moneycontent3:'',
				moneycontent2:'',
				moneycontent1:"",
				moneycontent5:"",
				moneycontent6:"",
				moneytext:'',
				showbol:false,
				token:window.sessionStorage.token,
				repay_type:"",//还款方式
				mb_limit_type:"",//满标期限
				use_type:"",//借款用途
				
			}
		},
		created(){
				//获取全局数据
				this.data = JSON.parse(window.sessionStorage.overall)
				for(var i=0;i<this.data.project_type_list.length;i++){
					var set ={text:this.data.project_type_list[i].name} 
					this.datanames.push(set)
				}
				for(var i=0;i<this.data.loan_limit_type.length;i++){
					var set ={text:this.data.loan_limit_type[i].desc} 
					this.datalist.push(set)
					
				}
				for(var i=0;i<this.data.use_type.length;i++){
					var set ={text:this.data.use_type[i].desc} 
					this.purpose.push(set)
					
				}
				for(var i=0;i<this.data.mb_limit_type.length;i++){
					var set ={text:this.data.mb_limit_type[i].desc} 
					this.bondloan1.push(set)
					
				}
				for(var i=0;i<this.data.repay_type.length;i++){
					var set ={text:this.data.repay_type[i].desc} 
					this.bondloan.push(set)
					
				}

		},
		components:{
			topct
		},
		methods:{
			
			clickbtn(){
			if(this.moneycontent3&&this.moneycontent1&&this.moneycontent2&&this.moneycontent4&&this.moneycontent5&&this.moneycontent6){
				this.$http.post(this.$url.URLSETTWO,{
					"project_type":this.moneytext,
					"amount":this.moneycontent6,
					"issue_count":this.moneycontent2[0],
					"purpose":this.use_type,
					"limit":this.mb_limit_type,
					"repay_type":this.repay_type	
				},{headers: {'Authorization':this.token}})
				.then((response)=>{
					console.log(response)
					if(response.data!==undefined||response.status=="201"){
						MessageBox("提示",'借款成功')
					}
				}).catch(()=>{
					MessageBox("提示",'借款失败')
				})
			}else{
				MessageBox("提示",'请填完以上选项')
			}
				
			},
			moneyclick1(){
				this.arrowsbol1=true
				
				var that=this
				
				
				var nameEl = document.querySelector('.monetdiv');
				var data1 = this.datanames;
				var picker = new Picker({
					data: [data1],
					selectedIndex: [0],
					title: '标的类型'
				});

				picker.on('picker.select', function (selectedVal, selectedIndex) {
					that.moneycontent1 = data1[selectedIndex[0]].text
					that.arrowsbol1=false
					
					var dataall = JSON.parse(window.sessionStorage.overall).project_type_list
					for(let i=0;i<dataall.length;i++){
						if(that.moneycontent1==dataall[i].name){
							that.moneytext=dataall[i].code
						}
					}
				});
				picker.on('picker.cancel',function(){
					that.arrowsbol1=false
				})
				picker.show()
			},
			moneyclick2(){
				this.arrowsbol2=true
				this.showbol=true
				var that=this
				
				var nameEl = document.querySelector('.monetdiv');
				var data1 = this.datalist;
				var data2=this.datafloat
				var picker = new Picker({
					data: [data1],
					selectedIndex: [0],
					title: '借款期限'
				})
				picker.on('picker.select', function (selectedVal, selectedIndex) {
					that.moneycontent2 = data1[selectedIndex[0]].text
					that.arrowsbol2=false
					
				})
                
				picker.on('picker.cancel',function(){
					that.arrowsbol2=false
				})
				picker.show()

			},
			moneyclick3(){
				this.arrowsbol3=true
				
				var that=this
				var nameEl = document.querySelector('.monetdiv');
				var data1 = this.purpose;
				var picker = new Picker({
					data: [data1],
					selectedIndex: [0],
					title: '借款用途'
				});
				picker.on('picker.select', function (selectedVal, selectedIndex) {
					that.moneycontent3 = data1[selectedIndex[0]].text
					for(let i=0;i<that.data.use_type.length;i++){
						if(data1[selectedIndex[0]].text==that.data.use_type[i].desc){
							that.use_type=that.data.use_type[i].code
						}
					}
					that.arrowsbol3=false
				})
				
				picker.on('picker.cancel',function(){
					that.arrowsbol3=false
				})
				picker.show()
			},
			moneyclick4(){
				this.arrowsbol4=true
				var that=this
				var nameEl = document.querySelector('.monetdiv');
				var nametext = document.querySelector('.monetdivtext4')
				var data1 = this.bondloan;
				var picker = new Picker({
					data: [data1],
					selectedIndex: [0],
					title: '借款方式'
				});
				picker.on('picker.select', function (selectedVal, selectedIndex) {
					that.moneycontent4= data1[selectedIndex[0]].text
					for(let i=0;i<that.data.repay_type.length;i++){
						if(data1[selectedIndex[0]].text==that.data.repay_type[i].desc){
							that.repay_type=that.data.repay_type[i].code
						}
					}
					that.arrowsbol4=false
				})

				picker.on('picker.cancel',function(){
					that.arrowsbol4=false
				})
				picker.show()
			},
			moneyclick5(){
				this.arrowsbol5=true
				var that=this
				var nameEl = document.querySelector('.monetdiv');
				var nametext = document.querySelector('.monetdivtext5')
				var data1 = this.bondloan1;
				var picker = new Picker({
					data: [data1],
					selectedIndex: [0],
					title: '满标期限'
				});
				picker.on('picker.select', function (selectedVal, selectedIndex) {
					that.moneycontent5= data1[selectedIndex[0]].text
					for(let i=0;i<that.data.mb_limit_type.length;i++){
						if(data1[selectedIndex[0]].text==that.data.mb_limit_type[i].desc){
							that.mb_limit_type=that.data.mb_limit_type[i].code
						}
					}
					that.arrowsbol5=false
				})
				picker.on('picker.cancel',function(){
					that.arrowsbol5=false
				})
				picker.show()
			}
		},
		mounted(){
		}
	}
</script>

<style scoped="scoped">
	.money{
		width:100%;
		position:absolute;
		top:0.88rem;
	}

	.monetdiv{
		width:100%;
		height:0.88rem;
		background:#FFFFFF;
		border-bottom:1px solid #f5f5f5;
		line-height: 0.88rem;
		font-size:0.3rem;
		position:relative;
	}
	.monetdiv>div:nth-of-type(1){
		float:left;
		margin-left:0.24rem;
	}
	.monetdiv>div:nth-of-type(2){
		float:left;
		margin-left:0.3rem;
		color:#2f81fd;
	}
	.monetdivtext2{
		float:left;
		margin-left:0.3rem;
		color:#2f81fd;
	}
	.monetdivtext3{
		float:left;
		margin-left:0.3rem;
		color:#A9A9A9;
		font-size:0.3rem;
	}
	.rightarrows{
		position: absolute;
		width:0.17rem;
		height:0.3rem;
		background:url(../imgs/homeqietu/shiliangzhinengkaob.png) no-repeat;
		right:0.24rem;
		top:0.29rem;
		background-size:0.17rem 0.3rem;
	}
	
	.rightarrowd1{
		position: absolute;
		width:0.3rem;
		height:0.17rem;
		background:url(../imgs/homeqietu/gengduojiantou.png) no-repeat;
		right:0.24rem;
		top:0.35rem;
		background-size:0.3rem 0.17rem;
	}
	
	.rightarrowd2{
		position: absolute;
		width:0.3rem;
		height:0.17rem;
		background:url(../imgs/homeqietu/gengduojiantou.png) no-repeat;
		right:0.24rem;
		top:0.35rem;
		background-size:0.3rem 0.17rem;
	}
	.rightarrowd3{
		position: absolute;
		width:0.3rem;
		height:0.17rem;
		background:url(../imgs/homeqietu/gengduojiantou.png) no-repeat;
		right:0.24rem;
		top:0.35rem;
		background-size:0.3rem 0.17rem;
	}
	.rightarrowd4{
		position: absolute;
		width:0.3rem;
		height:0.17rem;
		background:url(../imgs/homeqietu/gengduojiantou.png) no-repeat;
		right:0.24rem;
		top:0.35rem;
		background-size:0.3rem 0.17rem;
	}
	.rightarrowd5{
		position: absolute;
		width:0.3rem;
		height:0.17rem;
		background:url(../imgs/homeqietu/gengduojiantou.png) no-repeat;
		right:0.24rem;
		top:0.35rem;
		background-size:0.3rem 0.17rem;
	}
	.monetdiv>input{
		border:0;
		height:100%;
		font-size:0.26rem;
		float:left;
		margin-left:0.3rem;
		width:75%;
		Outline:none;
		font-size:#cacaca
	}
	#borowmoneybut{
		width:6.84rem;
		height:0.8rem;
		background-color:#Fc8E0D;
		margin:1.1rem auto;
		border-radius: 6px;
		font-size:0.34rem;
		text-align: center;
		line-height: 0.8rem;
		color:#FFFFFF;
	}	
</style>