<template>
	<div class="Mineremovephone">
		<topctfalse :dataname="dataname"></topctfalse>
		<div class="Minerphone">
			<div class="phonehine">
				为了您的账户安全，建议绑定您常用的手机号码
			</div>
			<input type="text" class="newphone1" v-model="authname"/>
			<div class="Mineerbottom">
				<input type="text" v-model="authcode"/>
				<div @click="authcodebtn">{{yzmname}}</div>
			</div>

		</div>
		<div class="personalbtn" @click="personalbtn">
			提交
		</div>
	</div>
	
</template>

<script>
	import topctfalse from './topctfalse'
	import { MessageBox } from 'mint-ui';
	export default{
		data(){
			return{
				dataname:"更换手机号码",
				authname:'',//新手机号码
				authcode:"",//验证码
				name:"",
				login_data:"",//登录信息
				token:window.sessionStorage.token,
				yzmname:"获取验证码",
				nonberdate:180,
			}
		},
		created(){

		},
		methods:{
			authcodebtn(){
				if(this.yzmname=="获取验证码"){
					var number = /^[1][3,4,5,7,8][0-9]{9}$/;
					if (!this.authname) {
						MessageBox("提示","手机号码不能为空！");
						return;
					}
					console.log(number.test(this.authname))
					if (!number.test(this.authname)) {
						MessageBox("提示","手机格式不对！"); 
						return;
					}
					
					var sets=setInterval(()=>{
						this.nonberdate--
						this.yzmname=this.nonberdate+"秒"
						if(this.nonberdate=="-1"){
							clearInterval(sets)
							this.yzmname="获取验证码"
							this.nonberdate=180
						}
					},1000)
					this.$http.post(this.$url.URL+this.$url.URLYZM,{
					type:"MODIFY_MOBILE",
					mobile:this.authname,
					}, { headers: { "Authorization":this.token}})
					.then((response)=>{
						console.log(response)
					})	
				}
				
			},
			personalbtn(){
				console.log("aaaaa")
				var number = /^1[3|4|5|8]\d{9}$/;
				if (!this.authname) {
					MessageBox("提示","手机号码不能为空！");
					return;
				} else if (!number.test(this.authname)) {
					MessageBox("提示","手机格式不对！");
					return;
				}else if(this.authcode==""){
					MessageBox("提示","验证码不能为空！");
					return;
				}
				this.$http.post(this.$url.URL+this.$url.MODIFY_MOBILE,{
					code:this.authcode,
					mobile:this.authname,
				}, { headers: { "Authorization": this.token } })
				.then((response)=>{
					console.log(response.data.code)
					if(response.data.code=="0"){
						MessageBox("提示","修改手机号码成功");
							this.$http
							.get(this.$url.URL + this.$url.MY_INDEX_DATA, {
							headers: { Authorization:this.token }
							})
							.then(response => {
							window.sessionStorage.my_data = JSON.stringify(response.data);
							this.$router.push({path:"Minepersonal"})
							});
					}else{
						MessageBox("提示",response.data.msg);
					}
					
				})
			}
		},
		components:{
			topctfalse
		}
	}
</script>

<style scoped="scoped">
	.Minerphone{
		width:100%;
		position:absolute;
		top:1.18rem;
		overflow: nidden;
	}
	.phonehine{
		margin-left:0.24rem;
		font-size:0.26rem;
		color:#999999;
	}
	.newphone1{
		width:100%;
		height:0.88rem;
		border:none;
		Outline:none;
		margin-top:0.2rem;
		background-color:#FFFFFF;
		margin-left:0;
		text-indent:0.24rem;
	}
	.Mineerbottom{
		width:100%;
		height:0.88rem;
		background-color:#FFFFFF;
		margin-top:0.2rem;
		position:relative;
	}
	.Mineerbottom>input{
		position: absolute;
		width:70%;
		height:0.88rem;
		top:0;
		text-indent: 0.24rem;
		Outline:none;
		border:none;
	}
	.Mineerbottom>div{
		width:1.5rem;
		height:0.46rem;
		position:absolute;
		right:0.24rem;
		top:0.21rem;
		border-radius: 6px;
		border:1px solid #D83515;
		font-size:0.26rem;
		text-align: center;
		line-height: 0.46rem;
		color:#D83515;
	}
	.personalbtn{
		width:90%;
		height:0.8rem;
		font-size:0.34rem;
		background-color:#Fc8E0D;
		border-radius: 6px;
		position:absolute;
		bottom:1.5rem;
		left:5%;
		text-align: center;
		line-height: 0.8rem;
		color:#FFFFFF;
	}
</style>