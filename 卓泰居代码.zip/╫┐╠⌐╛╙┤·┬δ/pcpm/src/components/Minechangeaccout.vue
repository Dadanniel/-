<template>
	<div class="Minechangeaccout">
		<topctfalse :dataname="dataname"></topctfalse>
		<div class="changeccoutname">
			<input type="text" v-model="changename"/>
			<img @click="changenamemove" src="../imgs/mineimgs/cancelone.png" alt="" />
		</div>
		
		<div class="changebtn_1" @click="confirmchange">确定更改</div>
	</div>
</template>

<script>
	import topctfalse from './topctfalse'
	import { MessageBox } from 'mint-ui';
	export default{
		data(){
			return{
				dataname:"用户名",
				changename:"",
				token:window.sessionStorage.token
			}
		},
		created(){
			//获取我登录的个人资料	
		},
		computed:{
		},
		methods:{
			changenamemove(){
				this.changename=""
			},
			confirmchange(){
				if(this.changename==""){
					MessageBox("提示","请输入名字")
				}else{
					this.$http.post(this.$url.URL + this.$url.MODIFY_NAME,{
						new_name:this.changename
					}, { headers: { Authorization: this.token } })
					.then((response)=>{
						if(response.data.code=="0"){
							 this.$http
							.get(this.$url.URL + this.$url.MY_INDEX_DATA, {
							headers: { Authorization:this.token }
							})
							.then(response => {
							window.sessionStorage.my_data = JSON.stringify(response.data);
							this.$router.push({path:"Minepersonal"})
							});
							
						}if(response.data.code=="1"){
							MessageBox("提示",response.data.msg)
						}
					})
					.catch(()=>{
						MessageBox("提示","修改名字失败")
					})
				}
				
				
			}
		},
		components:{
			topctfalse
		}
	}
</script>

<style>
	.changeccoutname{
		width:100%;
		height:0.88rem;
		position:absolute;
		top:1.08rem;
		background-color:#FFFFFF;
		line-height: 0.88rem;

	}
	.changeccoutname>img{
		position:absolute;
		width:0.4rem;
		height:0.4rem;
		right:0.24rem;
		top:0.24rem;

	}
	.changeccoutname>input{
		width:80%;
		height:0.88rem;
		position:absolute;
		top:0;
		left:0.24rem;
		border:none;
		outline: none;
	}
	.changebtn_1{
		width:90%;
		height:0.8rem;
		font-size:0.34rem;
		background-color:#Fc8E0D;
		border-radius: 6px;
		position:absolute;
		bottom:1.5rem;
		left:5%;
		text-align: center;
		line-height: 0.8rem;
		color:#FFFFFF;
	}
</style>