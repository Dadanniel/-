<template>
	<div class="invest">
		<div class="headname">
			<div id="headname_left">
				<router-link tag="div" to="/investone" class="headname_leftdiv" :class="{invechange_1:invesbol1}" @click.native="invesone">置家贷</router-link>
				<router-link tag="div" to="/investtwo" class="headname_leftdiv" :class="{invechange_2:invesbol2}" @click.native="investwo">抵押标</router-link>
				<router-link tag="div" to="/investthiree" class="headname_leftdiv" :class="{invechange_3:invesbol3}" @click.native="investhiree">赎楼贷</router-link>
				<router-link tag="div" to="/investfour" class="headname_leftdiv" :class="{invechange_4:invesbol4}" @click.native="invesfour">债权转让</router-link>
				<router-link tag="div" to="/investfive" class="headname_leftdiv" :class="{invechange_5:invesbol5}" @click.native="insvefive">体验区</router-link>
			</div>
			<router-view></router-view>
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{

			}
		},
		computed:{
			invesbol1(){
				return this.$store.state.invesbol1
			},
			invesbol2(){
				return this.$store.state.invesbol2
			},
			invesbol3(){
				return this.$store.state.invesbol3
			},
			invesbol4(){
				return this.$store.state.invesbol4
			},
			invesbol5(){
				return this.$store.state.invesbol5
			}

		},
		methods:{
			hidescreenbtn(){
				this.$store.dispatch("showmoveleft")
				var that=this
				setTimeout(function(){
					that.$store.dispatch("hidescreenbtn")
				},400)
				
				
			},
			invesone(){
				this.$store.dispatch("invesone")
			},
			investwo(){
				this.$store.dispatch("investwo")
			},
			investhiree(){
				this.$store.dispatch("investhiree")
			},
			invesfour(){
				this.$store.dispatch("invesfour")
			},
			insvefive(){
				this.$store.dispatch("insvefive")
			}

		}
	}
</script>

<style scoped="scoped">

	.invest{
		width:100%;
		height:100%;
	}
	.headname{
		height:100%;
		background-color:#F5F5F5;
	}
	#headname_left{
		width:100%;
		height:0.88rem;
		background-color:#Fc8E0D;
		position:fixed;
		top:0;
		left:0;
		z-index:666;
	}
	.headname_leftdiv{
		width:20%;
		height:0.88rem;
		text-align: center;
		line-height: 0.88rem;
		float:left;
		font-size:0.32rem;
		color:#ff9a87;
	}
	.invechange_1{
		color:#FFFFFF;
	}
	.invechange_2{
		color:#FFFFFF;
	}
	.invechange_3{
		color:#FFFFFF;
	}
	.invechange_4{
		color:#FFFFFF;
	}
	.invechange_5{
		color:#FFFFFF;
	}
</style>