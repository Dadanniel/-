<template>
	<div class="Minesystembid">
		<topct :dataname="dataname"></topct>
		<div class="minetembidwarp">
			<div id="bind_top">
				<div>
					<div>您当前排名</div>
					<div>26526名</div>
				</div>
				<div>
					<div>账户可用余额</div>
					<div>36252.00元</div>
				</div>
			</div>
			<div id="bind_ulwarp">
				<ul>
					<li id="bind_ul_li">
						<div>年利率范围</div>
						
						<div @click="bidmoneybtn">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</div>
						<div>{{rateone}}%~{{ratetwo}}%</div>
					</li>
					
					<li id="bind_ul_li" style="position:relative;">
						<div style="position:absolute;left:0.24;">投资期限</div>
						
						<div @click="deadlinebtn">
							<img src="../imgs/homeqietu/shiliangzhinengkaob.png" alt="" />
						</div>
						<div>{{deadlineone}}~{{deadlinetwo}}  个月</div>
					</li>
					<li id="bind_ul_li" style="position:relative;">
						<div>投标金额<span style="font-size:0.23rem;">(元)</span></div>
						<input @blur="changecount" placeholder="最小金额" style="margin-left:0.24rem; height:0.68rem; margin-top:0.1rem; width:26%; position:absolute; border:1px solid #999999; outline: none;"type="text" v-model="text1"/>
						<p></p>
						<input @blur="changecounttwo" placeholder="最大金额" style="margin-left:1%; height:0.68rem; margin-top:0.1rem; width:26%; position:absolute; border:1px solid #999999; outline: none;"type="text" v-model="text2"/>
						
					</li>
				</ul>
			</div>
			<div id="bind_ulwarp">
				<ul>
					<li id="bind_ul_li">
						<div>选择投资项目<span>(多选)</span></div>
						
					</li>
					<li id="bind_ul_li2" style="font-size:0.28rem;">
						<div@click="radio1" class="filtwarp">
						<div class="filtratuldiv" :class="{radios:imgbol1=='ZJD'}"><img class="filtratulimg" src="../imgs/mineimgs/fuxuankiangxuanzhong.png"/></div>
						<span>置家贷</span>
						</div>
						<div@click="radio2" class="filtwarp">
						<div class="filtratuldiv" :class="{radios:imgbol2=='DYD'}"><img class="filtratulimg" src="../imgs/mineimgs/fuxuankiangxuanzhong.png"/></div>
						<span>抵押贷</span>
						</div>
						<div@click="radio3" class="filtwarp">
						<div class="filtratuldiv" :class="{radios:imgbol3=='SLD'}"><img class="filtratulimg" src="../imgs/mineimgs/fuxuankiangxuanzhong.png"/></div>
						<span>赎楼贷</span>
						</div>
						<div@click="radio4" class="filtwarp">
						<div class="filtratuldiv" :class="{radios:imgbol4=='ZQZR'}"><img class="filtratulimg" src="../imgs/mineimgs/fuxuankiangxuanzhong.png"/></div>
						<span>债权转让</span>
						</div>
					</li>
				</ul>
			</div>
			
			<div class="bind_bottom">
				<span>自动投标于</span>
				<input style=" margin-left:0; width:26%; border:1px solid #999999;height:0.66rem; text-align: center;"  type="text" name="" id="" value="" placeholder="2017-10-06"/>
				<span>自动取消</span>
			</div>
			<div class="bind_bottom">
				保留金额
				<input  type="text" name="" id="" value="" placeholder="请输入你要保留的金额"/>
			</div>
			<div id="bind_bottom_set">
				自动投标保留金额，最少金额不少于系统最低投资金额
			</div>
			<div class="bind_bottom_btn">
				<div class="bind_bottom_left">
					<div>保存设置</div>
				</div>
				<div class="bind_bottom_right">
					<div>启动自动投标</div>
				</div>
			</div>
		</div>
	</div>
	
</template>

<script>
	import topct from './topct'
	import Picker from 'better-picker'
	export default{
		name: 'carrousel',
		data(){
			return{
				dataname:"系统自动投标",
				bidmoney:false,
				notNextTick: true,
				names:"",
				imgbol1:"",
				imgbol2:"",
				imgbol3:"",
				imgbol4:"",
				rate1:[{text:"1",value:1},{text:"2",value:2},{text:"3",value:3},{text:"4",value:4},
				{text:"5",value:5},{text:"6",value:6},{text:"7",value:7},{text:"8",value:8},{text:"9",value:9},{text:"10",value:10}],	
				rate2:[{text:"1",value:1},{text:"2",value:2},{text:"3",value:3},{text:"4",value:4},
				{text:"5",value:5},{text:"6",value:6},{text:"7",value:7},{text:"8",value:8},{text:"9",value:9},{text:"10",value:10}],
				rateone:'8',
				ratetwo:"10",
				deadline1:[{text:"1",value:1},{text:"2",value:2},{text:"3",value:3},{text:"4",value:4},
				{text:"5",value:5},{text:"6",value:6},{text:"7",value:7},{text:"8",value:8},{text:"9",value:9},{text:"10",value:10}],	
				deadline2:[{text:"1",value:1},{text:"2",value:2},{text:"3",value:3},{text:"4",value:4},
				{text:"5",value:5},{text:"6",value:6},{text:"7",value:7},{text:"8",value:8},{text:"9",value:9},{text:"10",value:10}],
				deadlineone:"1",
				deadlinetwo:"2",
				text1:"",
				text2:""
			}
		},
		components:{
			topct
		},
		methods:{
			changecount() {
        	if(Number(this.text1)<10){
        		alert("投标最小金额为十元")
        		this.text1=""
        	}
    		},
    		changecounttwo(){
    			if(Number(this.text2)<Number(this.text1)){
    				alert("最大金额要比最小金额大")
    				this.text2=""
    			}
    		},
			bidmoneybtn(){
				this.bidmoney=true;
				this.arrowsbol1=true
				
				var that=this
				var data1 = this.rate1;
				var data2 = this.rate2;
				var picker = new Picker({
					data: [data1,data2],
					selectedIndex: [0,1],
					title: '年利率范围'
				});

				picker.on('picker.select', function (selectedVal, selectedIndex) {
					if(data1[selectedIndex[0]].text<data2[selectedIndex[1]].text){
						that.rateone = data1[selectedIndex[0]].text
						that.ratetwo = data2[selectedIndex[1]].text
						that.arrowsbol1=false
					}else{
						alert("投资范围前面值比后面值大")
					}
					
				});
				picker.on('picker.cancel',function(){
					that.arrowsbol1=false
				})
				picker.show()
			},
			deadlinebtn(){
				var that=this
				var data1 = this.deadline1;
				var data2 = this.deadline2;
				var picker = new Picker({
					data: [data1,data2],
					selectedIndex: [0,1],
					title: '投资期限'
				});

				picker.on('picker.select', function (selectedVal, selectedIndex) {
					if(data1[selectedIndex[0]].text<data2[selectedIndex[1]].text){
						that.deadlineone = data1[selectedIndex[0]].text
						that.deadlinetwo = data2[selectedIndex[1]].text
						that.arrowsbol1=false
					}else{
						alert("投资期限前面值比后面值大")
					}
				});
				picker.on('picker.cancel',function(){
					that.arrowsbol1=false
				})
				picker.show()
			},
			btncallaff(){
				this.bidmoney=false;
				
			},
			btnconfrim(){
				this.bidmoney=false;
			},
			radio1(){
				if(this.imgbol1==""){
					this.imgbol1="ZJD"
				}else{
					this.imgbol1=""
				}
			},
			radio2(){
				if(this.imgbol2==""){
					this.imgbol2="DYD"
				}else{
					this.imgbol2=""
				}
			},
			radio3(){
				if(this.imgbol3==""){
					this.imgbol3="SLD"
				}else{
					this.imgbol3=""
				}
			},
			radio4(){
				if(this.imgbol4==""){
					this.imgbol4="ZQZR"
				}else{
					this.imgbol4=""
				}
			}
		},
		computed: {
			 swiper() {
		        return this.$refs.mySwiper.swiper
		      }
			
	   },
	    mounted() {
 		
    }
	}
</script>

<style scoped="scoped">
	.wiperlis{

		background:red;
	}
	.minetembidwarp{
		position:absolute;
		top:1.08rem;
		width:94%;
		left:3%;
	}
	#bind_top{
		width:100%;
		height:1.02rem;
		
	}
	#bind_top>div:nth-of-type(1){
		float:left;
		height:1.02rem;
		width:3.42rem;
		background-color:#FFFFFF;
		text-align: center;
	}
	#bind_top>div:nth-of-type(2){
		float:right;
		height:1.02rem;
		width:3.42rem;
		background-color:#FFFFFF;
		text-align: center;
	}
	#bind_top>div>div:nth-of-type(1){
		font-size:0.3rem;
		color:#333333;
		padding-top:0.16rem;
	}
	#bind_top>div>div:nth-of-type(2){
		font-size:0.24rem;
		color:#D83515;
		margin-top:0.05rem;
	}
	#bind_ulwarp{
		width:100%;
		margin-top:0.2rem;
		background-color:#FFFFFF;
	}
	#bind_ulwarp>ul>li{
		list-style: none;
		width:95%;
		height:0.88rem;
		margin:auto;
		border-top:1px solid #DcDcDc;
		line-height: 0.88rem;
	}
	#bind_ulwarp>ul>li:nth-of-type(1){
		border-top:none;
		
	}
	#bind_ul_li>div{
		float:left;
	}
	#bind_ul_li>div>span{
		font-size:0.18rem;
		color:#999999;
	}
	#bind_ul_li>div:nth-of-type(1){
		font-size:0.3rem;
		color:#333333;
		
	}
	#bind_ul_li>div:nth-of-type(2){
		position:relative;
		color:#333333;
		float:right;
		width:0.17rem;
		height:0.3rem;
		margin-top:0.29rem;
	}
	#bind_ul_li>div:nth-of-type(2)>img{
		position: absolute;
		width:0.17rem;
		height:0.3rem;
		top:0;
		left:0;
	}
	#bind_ul_li>div:nth-of-type(3){
		font-size:0.26rem;
		color:#333333;
		float:right;
		margin-right:0.1rem;
	}
	#bind_ul_li>p{
		height:0.34rem;
		display: inline-block;
		margin-left:31%;
		width:4%;
		box-sizing: border-box;
		text-align: center;
		border-top:1px solid #999999;
		
	}
	#bind_ul_li>input{
		text-align: center;
	}
	.bind_bottom{
		width:100%;
		margin-top:0.2rem;
		height:0.8rem;
		background-color:#FFFFFF;
		overflow: hidden;
		font-size:0.3rem;
		line-height: 0.8rem;
		text-indent: 0.2rem;
	}
	.bind_bottom>input{
		margin-left:0.24rem;
		border:none;
		outline: none;
	}
	#bind_bottom_set{
		padding:0.2rem 0;
		font-size:0.24rem;
		color:#cAcAcA;
		
		text-indent: 0.15rem;
	}
	.bind_bottom_btn{
		width:100%;
		height:0.7rem;
		margin-top:1.3rem;
	}
	.bind_bottom_btn>div{
		width:50%;
		height:0.7rem;
		float:left;
	}
	.bind_bottom_btn>div>div{
		width:3.1rem;
		height:0.7rem;
		margin:auto;
		border:1px solid #D83515;
		color:#D83515;
		font-size:0.3rem;
		text-align: center;
		line-height: 0.7rem;
		border-radius: 6px;
		
	}

	.pop_upboxonewarp{
		width:100%;
		height:100%;
		position:absolute;	
		background-color:rgba(0,0,0,.6);
		top:0;
		left:0;
		z-index:999;
	}
	.pop_upboxone{
		width:5.6rem;
		height:3.62rem;
		background-color:rgba(255,255,255,1);
		margin:4.4rem auto;
		opacity: 1;
		border-radius: 8px;
		position:relative;
	}

	#pop_upboxcenter{
		height:1.94rem;
		
	}
	#pop_upboxcenter>div{
		float:left;
		width:50%;
		height:1.94rem;
		overflow:hidden;
		text-align: center;
		line-height: 1.94rem;
		text-align: center;
	}

	#pop_upboxcenter>div>div{
		height:1.94rem;
		font-size:0.5rem;
		display: inline-block;
		width:100%;
		position:relative;
		text-align: center;
	}
	#pop_upboxone_top{
		width:100%;
		height:0.88rem;
		font-size:0.33rem;
		text-align: center;
		line-height: 0.88rem;
		color:#333333;
		border-bottom:1px solid #DcDcDc;
	}
	#pop_upboxone_to{
		margin-top:0.2rem;
		text-align: right;
		font-size:0.22rem;
		color:#999999;
		margin-right:0.24rem;
	}
	#pop_upboxone_textwarp{
		height:1rem;
		width:100%;

		line-height: 1rem;
		text-align: center;
	}
	#pop_upboxone_textwarp>input{
		width:4.9rem;
		height:0.6rem;
		border:1px solid #DcDcDc;
		border-radius: 6px;
		Outline:none;
		
	}
	.pop_upbox_btnwarp{
		width:100%;
		height:0.8rem;
		position:absolute;
		bottom:0;
		left:0;
		border-top:1px solid #DcDcDc;
	}
	.pop_upbox_btnwarp>div{
		float:left;
		width:50%;
		height:0.8rem;
		text-align: center;
		line-height: 0.8rem;
		font-size:0.3rem
	}
	.pop_upbox_btnwarp>div:nth-of-type(1){
		color:#666666;
		border-right:1px solid #DcDcDc;
		box-sizing: border-box;
	}
	.pop_upbox_btnwarp>div:nth-of-type(2){
		color:#D83515;
		
	}
	.filtwarp{
		width:25%;
		height:0.88rem;
		float:left;
		
	}
	.filtwarp>span{
		vertical-align: middle;
	}
	.filtratuldiv{
		display: inline-block;
		width:0.3rem;
		height:0.3rem;
		margin-right:0.1rem;
		border-radius:50%;
		float:left;
		margin-top:0.29rem;
		border:1px solid #333333;
		position:relative;
	}
	.filtratulimg{
		position:absolute;
		width:60%;
		height:60%;
		vertical-align: middle;
		margin-left:20%;
		margin-top:20%;
		vertical-align: middle;
		
	}
	.radios{
		background-color:#D83515;
		border:none;
	}
	#bind_ul_li2>div:nth-of-type(1){
		position:absolute;
	}
	#bind_ul_li2>div:nth-of-type(2){
		position:absolute;
		left:25%;
		
		
	}
	#bind_ul_li2>div:nth-of-type(3){
		position:absolute;
		right:25%;
		
	}
	#bind_ul_li2>div:nth-of-type(4){
		position:absolute;
		right:0;
		
	}
	#bind_ul_li2>div:nth-of-type(2)>div,#bind_ul_li2>div:nth-of-type(3)>div{
		margin-left:10%;
	}
	#bind_ul_li2>div:nth-of-type(4)>div{
		margin-left:8%;
	}
</style>