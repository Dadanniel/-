<template>
	<div class="Homeprelaunch">
		<topct :dataname="dataname"></topct>
		<div class="prelaunchconten">
			<div id="contentop">
				<div>
					<div :style="{backgroundcolor:color}" class="xbsd_box_div">{{texts.project_type_display}}</div>
					<div>{{texts.name}}</div>
					<div><img v-show="texts.is_lock" src="../imgs/homeqietu/biaodisuo.png"/></div>
				</div>

				<div id="contentopbox">
						<div>
							<div>年利率</div>
							<div>{{texts.rate}}%</div>
						</div>
						<div>
							<div>总额<span>(元)</span></div>
							<div>{{texts.amount}}</div>
						</div>
						<div>
							<div>期限</div>
							<div>{{texts.issue_count}}</div>
						</div>
						<div>
							<div>可{{touziname}}<span>(元)</span></div>
							<div>{{texts.fill_amount}}</div>
						</div>
				</div>

			</div>
			<ul id="contentuls">
				<li>
					{{touzimingcheng}}<input type="text" :placeholder="'账户可用余额'+my_data.available_remain+'元'" v-model="amount"/>
				</li>
				<li>
					<span>投资期限</span><span>{{texts.issue_count}}</span>
				</li>
				<li><span>计息方式</span><span>满标即计息</span></li>
				<li><span>投资收益</span><span>{{investment}}</span></li>
			</ul>
			<div id="contenbottom" v-show="pre==1">预投成功，标的上线时系统将自动帮您转为投资</div>
			<form id="myform" :action="gourl" method="post">
				<input type="" v-show="move" name="LoanJsonList" id="" :value="encold" />
				<input type="" v-show="move" name="PlatformMoneymoremore" id="" :value="p"/>
				<input type="" v-show="move" name="TransferAction" id="" value="1"/>
				<input type="" v-show="move" name="Action" id="" value="1"/>
				<input type="" v-show="move" name="TransferType" id="" value="2"/>
				<input type="" v-show="move" name="ReturnURL" id="IdentificationNo" :value="payreturn" />
				<input type="" v-show="move" name="NotifyURL" id="" :value="resul"/>
				<input type="" v-show="move" name="SignInfo" id="SignInfo" :value="Notifysurl"/>
				<input  id="contenbtn" type="button" :disabled="texts.progress>=100" value="下一步" @click="clickbtn"/>
			</form>
		</div>
		
	</div>
</template>

<script>
	import topct from './topct'
	import { MessageBox } from 'mint-ui';
	export default{
		data(){
			return{
				id:"",//项目id
				move:false,
				dataname:"我要投资",
				touziname:"",
				touzimingcheng:"投资金额",
				token:window.sessionStorage.token,
				texts:"",
				amount:"",//输入的投资金额
				dataall:"",
				investment:"",//投资收入
				dataitem:"",//投资期限
				color:"",//颜色
				my_data:JSON.parse(window.sessionStorage.my_data),//我的个人数据
				gourl:"",//乾多多支付接口
				LoanJsonList:[],//转账列表	
				resul:"",//后台通知网址
				payreturn: "", //前端通知网址
				p: window.sessionStorage.p, //平台乾多多标识	
				Notifysurl: "", //秘钥	
				pre:"",
				encold:"",
				
				}
		},
		created(){
			//获取全局数据
			this.dataall = JSON.parse(window.sessionStorage.overall).project_type_list
			this.gourl = this.$url.MONEYNFIVE;//乾多多支付接口
			this.payreturn=this.$url.URL + this.$url.PAYRETURN;
			this.resul =this.$url.QIANDUODUO +this.dataall.TRANSFER_CALLBACK; //转接口
			var id = this.$route.params.id;			
			var idlist = id.split("");
			if (idlist[idlist.length - 1] == "a") {
				this.dataname="预投"
				this.touzimingcheng="预投金额"
				this.touziname="预投"
				this.id = id.substr(0,id.length - 1);
				this.pre = "1";
			this.$http.get(this.$url.URL+this.$url.PROJECT_MAIN+"/"+this.id+"/",{
				headers: { Authorization: this.token }
			})
				.then((response)=>{
					this.dataitem=response.data.issue_count
					if (response.data.issue_type == "MONTH") {
						response.data.issue_count = response.data.issue_count + "个月";
					} else {
						response.data.issue_count = response.data.issue_count + "天";
					}
					this.texts=response.data
					console.log(this.texts)
					for(let i=0;i<this.dataall.length;i++){
						if(this.texts.project_type==this.dataall[i].code){
							this.texts.project_type=this.dataall[i]
						}
					}	
					this.color=response.data.project_type.color		
				})
			console.log(this.my_data)
			}else{
				this.dataname="我要投资"
				this.touzimingcheng="投资金额"
				this.touziname="投资"
				this.id=this.$route.params.id;
				this.pre = "0";
				this.$http.get(this.$url.URL+this.$url.PROJECT_MAIN+"/"+this.id+"/",{
				headers: { Authorization: this.token }
			})
				.then((response)=>{
					this.dataitem=response.data.issue_count
					if (response.data.issue_type == "MONTH") {
						response.data.issue_count = response.data.issue_count + "个月";
					} else {
						response.data.issue_count = response.data.issue_count + "天";
					}
					this.texts=response.data
					console.log(this.texts)
					for(let i=0;i<this.dataall.length;i++){
						if(this.texts.project_type==this.dataall[i].code){
							this.texts.project_type=this.dataall[i]
						}
					}	
					this.color=response.data.project_type.color		
				})
			console.log(this.my_data)
			}
				
		},
		components:{
			topct
		},
		watch :{
			amount(){
				if(this.texts.issue_type == "MONTH"){
					this.investment=this.amount / 100 * this.texts.rate/ 12 * this.dataitem
				}else{
					this.investment=this.amount /36000 * this.texts.rate/ 12 * this.dataitem
				}

			}
		},
		methods:{
			clickbtn(){
				this.LoanJsonList=[];
				if(this.amount!==""){
					if(Number(this.my_data.available_remain)>=Number(this.amount)){
						if(Number(this.amount)>=Number(this.texts.min_amount)){
							if(Number(this.amount)<=Number(this.texts.fill_amount)){
								console.log(this.texts.amount)
								this.$http
                              .post(
                                this.$url.URL + this.$url.PAYINVEST,
                                {
                                  //投资的转账列表
                                  project_id: this.id,
                                  amount: this.amount,
                                  is_pre: this.pre
                                },
                                {
                                  headers: {
                                    Authorization: this.token
                                  }
                                }
							  ).then((response) => {
								let list = response.data.LoanJsonList;
                                if (response.data.LoanJsonList !== undefined) {
                                  for (let i = 0; i < list.length; i++) {
                                     if(list[i].SecondaryJsonList.length>0){
										list[i].SecondaryJsonList = JSON.stringify(
											list[i].SecondaryJsonList                             
										);
										}else{
										delete list[i].SecondaryJsonList
										}
                                    this.LoanJsonList.push(list[i]);
                                  }
                                  this.LoanJsonList = JSON.stringify(
                                    this.LoanJsonList
                                  );
                                  this.$http
                                    .post(this.$url.URL + this.$url.ENCODEURL,{
                                      //后台ENCODEURL
                                      data: this.LoanJsonList
                                    })
                                    .then((response) => {
                                      this.encold = response.data.data;
                                    });

                                  let str =
                                    this.LoanJsonList +
                                    this.p +
                                    "112" +
                                    this.payreturn +
                                    this.resul;

                                  this.$http
                                    .post(this.$url.URL + this.$url.SIGNATURE, {
                                      //获取秘钥接口
                                      str: str
                                    })
                                    .then((response) => {
                                      this.Notifysurl = response.data.result;
									
										MessageBox.confirm('是否前往乾多多投资页面?').then(action => {
											myform.submit();
										});

                                    //   this.$confirm("是否前往乾多多投资页面?", "提示", {
                                    //     confirmButtonText: "确定",
                                    //     cancelButtonText: "取消",
                                    //     type: "warning"
                                    //   })
                                    //     .then(() => {
									// 	//   form1.submit();
									// 	console.log("aaaa")
                                    //     })
                                    //     .catch(() => {});
                                    });
                                } else {
                                  MessageBox("提示",response.data.msg);
                                }
                              })
                              .catch((rel) => {
								   MessageBox("提示","投资金额超出项目可投资范围");
							  });
							}else{
								MessageBox.alert("投资金额必须小于项目可投资金额", "提示")
							}
							 
						}else{
							let setconten="最低投资金额为"+this.texts.min_amount+"元"
							MessageBox.alert(setconten, "提示")
						}
						
							  
					}else{
						MessageBox.alert("账户余额不足，请前往充值", "提示")
					}
				}else{
					MessageBox.alert("请先输入投资金额", "提示")
				}
			}
		}
	}
</script>

<style scoped="scoped">
	.prelaunchconten{
		width:100%;
		position:absolute;
		top:1.08rem;
	}
	#contentop{
		width:100%;

	
		background-color:#FFFFFF;
		overflow: hidden;
		position:relative;
	}
	#contentop>div:nth-of-type(1)>div{
		float:left;
		font-size:0.3rem;
		line-height: 0.8rem;
	}
	#contentop>div:nth-of-type(1)>div:nth-of-type(1){
		font-size:12px;
		width:30px;
		height:20px;
		background-color:red;
		text-align: center;
		line-height: 20px;
		margin-top:0.2rem;
		margin-left:0.24rem;
		margin-right:0.24rem;
		border-radius: 4px;
		color:#FFFFFF;
	}
	#contentop>div:nth-of-type(1)>div:nth-of-type(3){
		margin-top:0.2rem;
		width:0.2rem;
		height:0.3rem;
		position:relative;
		margin-left:0.2rem;
	}
	#contentop>div:nth-of-type(1)>div:nth-of-type(3)>img{
		width:0.2rem;
		height:0.3rem;
		position:absolute;
		top:0;
		left:0;
	}
	#contentopbox{
		width:100%;
		height:1.68rem;
		margin-top:0.8rem;
		
	}
	#contentopbox>div{
		float:left;
		width:25%;
		text-align: center;
		font-size:0.28rem;
		margin-top:0.4rem;
	}
	#contentopbox>div>div>span{
		font-size:0.18rem;
	}
	#contentopbox>div>div:nth-of-type(2){
		font-size:0.24rem;
		margin-top:0.2rem;
	}
	#contentopbox>div:nth-of-type(3){
		float:left;
		width:25%;
		text-align: center;
		font-size:0.24rem;
	}
	#contentopbox>div:nth-of-type(4){
		color:#D83515;
	}
	#contentuls{
		width:100%;
		list-style: none;
		margin-top:0.2rem;
		background-color:#FFFFFF;
	}
	#contentuls>li{
		width:100%;
		height:0.88rem;
		line-height: 0.88rem;
		font-size:0.26rem;
		text-indent: 0.24rem;
		border-top:1px solid #DcDcDc;
	}
	#contentuls>li:nth-of-type(1){
		border:none;
	}
	#contentuls>li>input{
		margin-left:0.2rem;
		width:70%;
		border:none;
		Outline:none;
	}
	#contentuls>li>span:nth-of-type(2){
		color:#FD8F00;
		margin-left:0.2rem;
	}
	#contenbottom{
		font-size:0.2rem;
		margin-top:0.2rem;
		margin-left:0.24rem;
		color:#828282;
	}
	#contenbtn{
		
		width:90%;
		height:0.8rem;
		margin:1.1rem auto;
		text-align: center;
		line-height: 0.8rem;
		background-color:#Fc8E0D;
		color:#FFFFFF;
		font-size:0.34rem;
		border-radius: 6px;
		border:none;
		margin-left:5%;
	}
</style>