<template>
	<div class="Msetinstall">
		<topct :dataname="dataname"></topct>
		<div class="Mstinesconten">
			<ul class="Mstinesul1">
				<router-link class="msetineimg" tag="li" to="/Malterpassword">
				
					<div>修改密码</div>
					<img src="../imgs/homeqietu/shiliangzhinengkaob.png"/>
				</router-link>
				<router-link class="msetineimg" tag="li" to="/Mfeedback">
					<div>意见反馈</div>
					<img src="../imgs/homeqietu/shiliangzhinengkaob.png"/>
				</router-link>
				<li class="msetinefont">
					<div>当前版本</div>
					<div>1.0.0</div>
				</li>				
			</ul>
			<div @click="goashore" id="outmsetbtn">
				退出当前账户
			</div>
		</div>
	</div>
</template>

<script>
	import topct from './topct'
	export default{
		data(){
			return{
				dataname:"设置"
			}
		},
		methods:{
			goashore(){
				this.$router.push("/goashore");
				sessionStorage.clear();
				localStorage.clear();
			}
		},
		components:{
			topct
		}
	}
</script>

<style>
	.Mstinesconten{
		width:100%;
		position:absolute;
		top:1.08rem;
	}
	.Mstinesul1{
		list-style: none;
		width:100%;
	}
	.msetineimg{
		position: relative;
		width:100%;
		height:0.88rem;
		line-height: 0.88rem;
		font-size:0.33rem;
		background-color:#FFFFFF;
		border-top:1px solid #DcDcDc;

	}
	.msetineimg>div{
		margin-left:0.24rem;
	}
	.Mstinesul1>li:nth-of-type(1){
		border:none;
	}
	.msetineimg>img{
		width:0.17rem;
		height:0.3rem;
		position: absolute;
		right:0.24rem;
		top:0.29rem;
	}
	.msetinefont{
		position:relative;
		width:100%;
		height:0.88rem;
		line-height: 0.88rem;
		font-size:0.33rem;
		background-color:#FFFFFF;
		border-top:1px solid #DcDcDc;
	}
	.msetinefont>div:nth-of-type(1){
		float:left;
		margin-left:0.24rem;
	}
	.msetinefont>div:nth-of-type(2){
		float:right;
		margin-right:0.24rem;
	}
	#fonts_warp{
		width:100%;
		
	}
	#fonts_warp>div{
		width:7.02rem;
		margin:auto;
		padding:0.2rem 0;
		background-color:#F5F5F5;
		font-size:0.24rem;
		color:#999999;
		
	}
	#outmsetbtn{
		width:6.85rem;
		height:0.8rem;
		background-color:#Fc8E0D;
		margin:auto;
		margin-top:4.1rem;
		border-radius: 6px;
		text-align: center;
		line-height: 0.8rem;
		font-size:0.34rem;
		color:#FFFFFF;
		
	}
</style>