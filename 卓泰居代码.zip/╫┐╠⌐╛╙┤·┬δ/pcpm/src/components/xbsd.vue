<template>
	<div class="xbsd_text">
		<div class="headname" style="background-color:#Fc8E0D">
			<router-link tag="div" to="/">
				<div class="headnamelist"><img @click="baberBolr2" src="../imgs/homeqietu/fanhui.png"/></div>
			</router-link>
			<div id="headname_left">新标速递</div>
		</div>
		<div id="xbsd_center">
			<div id="xbsd_center_box" v-for="item in list" @click="gobtn(item)">
				<div id="xbsd_center_box_top">
					<div :style="{backgroundcolor:item.project_type.color}" class="xbsd_box_div">{{item.project_type_display}}</div>
					<div>{{item.name}}</div>
					<div><img src="../imgs/homeqietu/biaodisuo.png" v-show="item.is_lock"/></div>
				</div>
				<div id="xbsd_center_box_bottom">
					<div class="xbsd_center_box_bottom_div">
						<div>年利率</div>
						<div>{{item.rate}}%</div>
					</div>
					<div class="xbsd_center_box_bottom_div">
						<div>总额</div>
						<div>{{item.amount}}</div>
					</div>
					<div class="xbsd_center_box_bottom_div">
						<div>期限</div>
						<div>{{item.issue_count}}</div>
					</div>
				</div>
				<input type="button" class="xbsdbutton"  @click.stop="gohomeinbtn(item)" :class="{xbsdbtn:item.progress>='100'}" value="我要投标" :disabled="item.progress>='100'">
					<canvas class="mycanvas"></canvas> 
			</div>
			
		</div>


	</div>
</template>

<script>
	import {drawRing} from "@/../static/plug/drawRing.js";
	import { MessageBox } from 'mint-ui';
	export default{
		data(){
			return{
				set:[],
				list:""
			}
		},
		computed:{
			
		},
		methods:{
			baberBolr2(){
				this.$store.dispatch("baberBolr2")
			},
			baberBolr2(){
				this.$store.dispatch("baberBolr2")
			},
			gohomeinbtn(item){
				if(window.sessionStorage.token==undefined){
					MessageBox.confirm('还未登录，其否前往登录?').then(action => {
						this.$router.push({path:'goashore'})
					});
				}else{
					this.$router.push({name:'investnvrstrepe', params: {id:item.id}})
				}
			},
			gobtn(item){
				this.$router.push({path:'/signdetails/'+item.id})
				sessionStorage.removeItem('particulars')
			}
		},
		created(){
			var overall = JSON.parse(window.sessionStorage.overall).project_type_list;
			console.log(overall)
	    	this.$http.get(this.$url.URL+this.$url.NEWPROJECT)
				.then((res)=>{
					for(let i=0;i<res.data.results.length;i++){
					 if (res.data.results[i].issue_type == "MONTH") {
						res.data.results[i].issue_count =
						res.data.results[i].issue_count + "个月";
					} else {
						res.data.results[i].issue_count =
						res.data.results[i].issue_count + "天";
					}
				}
				this.list=res.data.results
				console.log(this.list)
				for(let i=0;i<this.list.length;i++){
					this.set.push(this.list[i].progress)
					for(let l=0;l<overall.length;l++){
						if(this.list[i].project_type==overall[l].code){
							this.list[i].project_type=overall[l]
						}
					}
				}
				this.$nextTick(function(){
					var wth = document.documentElement.clientWidth; 
					var that=this
					drawRing(that);
				})
            	})

	    },
		mounted(){

		}
		
		
	}
</script>

<style scoped="scoped">
	.mycanvas{
 		position:absolute;
 		top:10%;
 		right:5.4%;
 	}
		#xbsd_center_box{
		width:100%;
		height:2.46rem;
		margin-top:0.1rem;
		background-color:#ffffff;
		position:relative;
		color:#494949;
	}

	.xbsd_center>div:nth-of-type(n+3)>div:nth-of-type(4){
		right:6px;
	}

	.xbsd_text{
		height:100%;
		background-color:#f5f5f5;
	}
	#xbsd_center{
		width:100%;
		position:absolute;
		top:0.88rem;
	}

	#xbsd_center>div:nth-of-type(1){
		margin-top:0.2rem;
	}
	#xbsd_center_box_top{
		height:0.7rem;
		line-height: 0.7rem;
		border-top:1px solid white;
		box-sizing: border-box;
	}
	#xbsd_center_box_top>div{
		float:left;
	}
	.xbsd_box_div1{
		background-color:red;
	}
	.xbsd_box_div2{
		background-color:yellow;
	}
	.xbsd_box_div3{
		background-color:beige;
	}
	.xbsd_box_div4{
		background-color:black;
	}
	.xbsd_box_div5{
		background-color:blue;
		
	}
	.xbsd_box_div{
		width:0.44rem;
		height:0.28rem;
		font-size:0.16rem;
		text-align: center;
		line-height: 0.28rem;
		margin-top:0.17rem;
		border-radius: 4px;
		margin-left:0.24rem;
		margin-right:0.2rem;
		color:#FFFFFF;
		overflow:hidden;
	}

	@media  (min-width:300px) and (max-width: 400px) { 
	   #xbsd_center_box_top>div:nth-of-type(1){
			width:26px;
			height:14px;
			font-size:12px;
			line-height:14px;
			margin-top:0.15rem;
		}
	}
	#xbsd_center_box_top>div:nth-of-type(2){
		font-size:0.32rem;
		vertical-align: middle;
	}
	#xbsd_center_box_top>div:nth-of-type(3)>img{
		width:0.2rem;
		height:0.26rem;
		vertical-align: middle;
		margin-top:-0.2rem;
		margin-left:0.3rem;
	}
	#xbsd_center_box_bottom{
		position: relative;
		margin-top:0.5rem;
	}
	.xbsd_center_box_bottom_div{
		float:left;
		text-align: center;
		margin-left:0.9rem;
		width:0.9rem;
	}

	.xbsd_center_box_bottom_div>div:nth-of-type(1){
		font-size:0.3rem;
		
	}
	.xbsd_center_box_bottom_div>div:nth-of-type(2){
		font-size:0.26rem;
		margin-top:0.2rem;
	}
	.xbsdbutton{
		width:1.6rem;
		height:0.5rem;
		background-color:#FD8F00;
		text-align: center;
		line-height: 0.5rem;
		font-size:0.26rem;
		color:#FFFFFF;
		position:absolute;
		bottom:0.2rem;
		right:0.34rem;
		border-radius: 6px;
		border:none;
	}
	.xbsdbtn{
		background: #dcdcdc;
	}
</style>