<template>

  <div id="app">

 			<router-view ></router-view>

    <ul id="taber" v-show="activeindex<5">
    	<li class="changeBg1" :class="{changeBg_1:activeindex==1}" @click="changeBg1()"><div v-show="activeindex!=='1'">首页</div></li>
		<li class="changeBg2" :class="{changeBg_2:activeindex==2}" @click="changeBg2()"><div v-show="activeindex!=='2'">投资</div></li>
		<li class="changeBg3" :class="{changeBg_3:activeindex==3}" @click="changeBg3()"><div v-show="activeindex!=='3'">账户</div></li>
		<li class="changeBg4" :class="{changeBg_4:activeindex==4}" @click="changeBg4()"><div v-show="activeindex!=='4'">我的</div></li>
    </ul>
  </div>
</template>

<script>
import router from './router'
export default {
  name: 'app',
  data(){
  	return{
		  activeindex:1
  	}
  },
  created(){
	  if(window.sessionStorage.btnindex==undefined){
		  window.sessionStorage.btnindex="1"
		  this.activeindex="1"
	  }else{
		  this.activeindex=window.sessionStorage.btnindex;
	  }
  },
  mounted(){
			router.beforeEach((to,from,next)=>{
				var path=to.path
				if(path=='/'){
					this.activeindex="1"
					 window.sessionStorage.btnindex="1"
					 
					 console.log("aaaa")
				}else if(path=='/invest'){
					this.activeindex="2"
					 window.sessionStorage.btnindex="2"
					 console.log("bbb")
				}else if(path=='/accountone'){
					this.activeindex="3"
					 window.sessionStorage.btnindex="3"
					 console.log("bbb")
				}else if(path=='/accountthiree'){
					this.activeindex="3"
					 window.sessionStorage.btnindex="3"
					 console.log("bbb")
				}else if(path=='/accounttwo'){
					this.activeindex="3"
					 window.sessionStorage.btnindex="3"
					 console.log("bbb")
				}else if(path=='/accountfour'){
					this.activeindex="3"
					 window.sessionStorage.btnindex="3"
					 console.log("bbb")
				}else if(path=='/investone'){
					this.activeindex="2"
					 window.sessionStorage.btnindex="2"
				}else if(path=='/investtwo'){
					this.activeindex="2"
					 window.sessionStorage.btnindex="2"
				}else if(path=='/investthiree'){
					this.activeindex="2"
					 window.sessionStorage.btnindex="2"
				}else if(path=='/investfour'){
					this.activeindex="2"
					 window.sessionStorage.btnindex="2"
				}else if(path=='/investfive'){
					this.activeindex="2"
					 window.sessionStorage.btnindex="2"
				}else if(path=='/mine'){
					this.activeindex="4"
					 window.sessionStorage.btnindex="4"
					 console.log("ccccd")
				}else if(path=='/Mine'){
					this.activeindex="4"
					 window.sessionStorage.btnindex="4"
					 console.log("ccccd")
				}else{
					this.activeindex="5"
					 window.sessionStorage.btnindex="5"
				}
				next()
		})
  },
  computed: {
    baberblor(){
    	return this.$store.state.baberblor
    }
  },
  methods:{
  	changeBg1(){
  		sessionStorage.removeItem("urls")
  		this.$router.push({path:'/'})
	  },
	changeBg2(){
  		sessionStorage.removeItem("urls")
		  this.$router.push({path:'/invest'})
		  this.$store.dispatch("invesone")
  	},
  	changeBg3(){
  		sessionStorage.removeItem("urls")
  		if(window.sessionStorage.token==undefined){
  			this.$router.push({path:'goashore'})
  		}else{
  			this.$router.push({path:'account'})
  			this.$store.dispatch("baberbtn1")
  		}
  	},
  	changeBg4(){
//		this.$store.dispatch('changeBg4')
  		sessionStorage.removeItem("urls")
  		if(window.sessionStorage.token==undefined){
  			this.$router.push({path:'goashore'})
  		}else{
  			this.$router.push({path:'mine'})
  		}
  	}
  }
}
</script>

<style>
*{
	margin:0;
	padding:0;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
	height:100%;
}
input[type="button"], input[type="submit"], input[type="reset"] {
-webkit-appearance: none;
}
textarea {  -webkit-appearance: none;}   
#taber{
  width: 100%;
  list-style: none;
  position:fixed;
  left:0;
  bottom:0;
  background-color:#ffffff;
  height:0.98rem;
  font-size:0.24rem;
  z-index: 999;
  
}
#taber>li{
	float:left;
	width:25%;
  text-align: center ;
  height:0.98rem;
  background-position: center 0.1rem;
	background-size:0.46rem 0.46rem;
	border-top:1px solid white;
}
#taber>li>div{
	margin:auto;
	margin-top:0.63rem;
}
	.headname{
		background-color:#Fc8E0D;
		width:100%;
		height:0.88rem;
		position: fixed;
		z-index:888;
		background-color:#Fc8E0D;
	}
	#headname_left{
		font-size:0.36rem;
		text-align:center;
		line-height: 0.88rem;
		color:white;
	}
	.headnamelist>img{
		width:0.22rem;
		height:0.39rem;
		position:absolute;
		top:0.24rem;
		left:0.24rem;
	}
	#headname_right{
		position:fixed;
		top:5px;
		right:0.01rem;
		font-size:30px;
	}
	.changeBg1{
		background:url(imgs/homeqietu/shouyeone.png) no-repeat center;
		background-size:0.46rem 0.46rem;
		
	}
	.changeBg2{
		background:url(imgs/homeqietu/touzitwo.png) no-repeat ;
		background-size:0.42rem 0.46rem;
	}
	.changeBg3{
		background:url(imgs/homeqietu/yonghuicon.png) no-repeat ;
		background-size:0.44rem 0.44rem;
	}
	.changeBg4{
		background:url(imgs/homeqietu/wodegerenzhongx.png) no-repeat;
		background-size:0.37rem 0.42rem;
	}
	.changeBg_1{
		background:url(imgs/homeqietu/shouyexuanzhong.png) no-repeat center;
		background-size:0.7rem 0.7rem !important;
		background-position: 0px 0px;
	}
	.changeBg_2{
		background:url(imgs/homeqietu/touzixuanzhong.png) no-repeat ;
		background-size:0.7rem 0.7rem !important;
		background-position: 0px 0px;

	}
	.changeBg_3{
		background:url(imgs/homeqietu/zhanghuxianzhongone.png) no-repeat ;
		background-size:0.7rem 0.7rem !important;
		background-position: 0px 0px;

	}
	.changeBg_4{
		background:url(imgs/homeqietu/wodexuanzhong.png) no-repeat;
		background-size:0.7rem 0.7rem !important;
		background-position: 0px 0px;

	}
</style>
