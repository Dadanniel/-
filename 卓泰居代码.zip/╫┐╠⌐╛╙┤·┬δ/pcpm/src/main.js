// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import VueAwesomeSwiper from 'vue-awesome-swiper'
import axios from 'axios'
import store from './store'
import Navigation from 'vue-navigation'
import url from '@/common/js/url.js'

// import OSS from 'ali-oss'
// import co from 'co'

import {MessageBox,InfiniteScroll,Swipe, SwipeItem,Radio}  from 'mint-ui'
import 'mint-ui/lib/style.css'
Vue.component(MessageBox.name, MessageBox)
Vue.component(Swipe.name, Swipe)
Vue.component(SwipeItem.name, SwipeItem)
Vue.component(Radio.name, Radio)
Vue.use(InfiniteScroll)//到底部加载
// axios.interceptors.response.use(
//   response => {
//       return response;
//   },
//   error => {
//       if (error.response) {
//           switch (error.response.status) {
//               case 401:
//                   sessionStorage.clear();
//                   router.push("/goashore");
//                   window.location.reload();

//           }
//       }
//       return Promise.reject(error.response.data)   // 返回接口返回的错误信息
//   })


Vue.use(Navigation, {router,store})
Vue.config.productionTip = false
Vue.use(VueAwesomeSwiper)

Vue.prototype.$url=url
Vue.prototype.$http = axios;
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
})
