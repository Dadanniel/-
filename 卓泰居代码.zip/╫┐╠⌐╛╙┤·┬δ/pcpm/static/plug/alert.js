function alert(text){

}
export {
	alert
}