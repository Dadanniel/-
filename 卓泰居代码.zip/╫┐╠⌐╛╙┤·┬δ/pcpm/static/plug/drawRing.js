function drawRing(that){  
					 	var thit = that
					 	var wth = document.documentElement.clientWidth; 

			                var c=document.querySelectorAll('.myCanvas');  
			                for(var i=0;i<c.length;i++){
			                var ctx = c[i].getContext('2d')
			                ctx.canvas.width=wth*0.2;  
			                ctx.canvas.height=wth*0.2;  
			                ctx.beginPath();  
			                ctx.lineWidth=2; 
			                ctx.strokeStyle='#dcdcdc';  			           
			                ctx.arc(wth*0.2*0.5,wth*0.2*0.5,wth*0.06,0,2*Math.PI);              
			                ctx.stroke(); 
			                ctx.beginPath();  
			                ctx.lineWidth=2;
			               
			                if(thit.set[i]>=0&&thit.set[i]<=100){
			                	ctx.strokeStyle="#D83515"
			                }
			                
			                ctx.arc(wth*0.2*0.5,wth*0.2*0.5,wth*0.06,-90*Math.PI/180,(thit.set[i]*3.6-90)*Math.PI/180);  
			                ctx.stroke(); 
			                ctx.font='12px Arial';  
			                ctx.fillStyle='#D83515';  
			                ctx.textBaseline='middle';  
			                ctx.textAlign='center';  
			                ctx.fillText(thit.set[i]+'%',wth*0.2*0.5,wth*0.2*0.5);  
					}  
}
export {
	drawRing
}