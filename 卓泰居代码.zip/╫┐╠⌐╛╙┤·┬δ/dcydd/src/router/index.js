import Vue from 'vue'
import Router from 'vue-router'
const home = r => {require.ensure([], () => r(require('@/components/home/home')), 'home')}//首页
const message = r => {require.ensure([], () => r(require('@/components/message/message')), 'message')}//消息
const lookhouse = r => {require.ensure([], () => r(require('@/components/lookhouse/lookhouse')), 'lookhouse')}//约看
const mine = r => {require.ensure([], () => r(require('@/components/mine/mine')), 'mine')}//我的
const indexlist = r => {require.ensure([], () => r(require('@/components/home/indexlist')), 'home')}//首页定位列表
const searchbox = r => {require.ensure([], () => r(require('@/components/home/searchbox')), 'home')}//首页搜索
const searchlist = r => {require.ensure([], () => r(require('@/components/home/searchlist')), 'home')}//首页所搜过滤列表
const hotdistrict = r => {require.ensure([], () => r(require('@/components/home/hotdistrict')), 'home')}//首页所搜过滤列表
const renting = r => {require.ensure([], () => r(require('@/components/home/renting')), 'home')}//首页我要买房我要卖房
const rentingitem = r => {require.ensure([], () => r(require('@/components/home/rentingitem')), 'home')}//首页我要买房我要卖房详情页
const subscribeitem = r => {require.ensure([], () => r(require('@/components/home/subscribeitem')), 'home')}//首页我要买房我要卖房预约看房
Vue.use(Router)

export default new Router({
  mode: 'history', 
  scrollBehavior (to, from, savedPosition) {
		return { x: 0, y: 0 }
	},
  routes: [
    {
      path: '/',
      name: 'home',
      component: home
    },
    {
      path: '/message',
      name: 'message',
      component: message
    },
    {
      path: '/lookhouse',
      name: 'lookhouse',
      component: lookhouse
    },
    {
      path: '/mine',
      name: 'mine',
      component: mine
    },
    {
      path: '/indexlist',
      name: 'indexlist',
      component: indexlist
    },
    {
      path: '/searchbox',
      name: 'searchbox',
      component: searchbox
    },
    {
      path:'/searchlist',
      name:"searchlist",
      component:searchlist
    },
    {
      path:"/hotdistrict",
      name:"hotdistrict",
      component:hotdistrict
    },
    {
      path:"/renting",
      name:"renting",
      component:renting
    },
    {
      path:"/rentingitem",
      name:"rentingitem",
      component:rentingitem
    },
    {
      path:"/subscribeitem",
      name:"subscribeitem",
      component:subscribeitem
    }
  ]
})
