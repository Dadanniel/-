<template>
  <div id="app">
    <router-view/> 
    <ul id="bottombtn" v-show="activeindex<5">
      <li class="btnlione" :class="{btnlionez:activeindex==1}" @click="homebtn">
        <div>首页</div>
      </li>
      <li class="btnlitwo" :class="{btnlitwoz:activeindex==2}" @click="messagebtn">
        <div>消息</div>
      </li>
      <li class="btnlithree" :class="{btnlithreez:activeindex==3}" @click="lookhousebtn">
        <div>约看</div>
      </li>
      <li class="btnlifour" :class="{btnlifourz:activeindex==4}" @click="minebtn">
        <div>我的</div>
      </li>
    </ul>
    
  </div>
</template>

<script>
import router from './router'
export default {
  name: 'App',
  data(){
    return{
      activeindex:1,
      transitionName: 'slide-left' 
    }
  },
  created(){
	  if(window.sessionStorage.btnindex==undefined){
		  window.sessionStorage.btnindex="1"
		  this.activeindex="1"
	  }else{
		  this.activeindex=window.sessionStorage.btnindex;
    }

  },
   mounted(){
			router.beforeEach((to,from,next)=>{
				var path=to.path
				if(path=='/'){
				   this.activeindex="1"
					 window.sessionStorage.btnindex="1"					 
				}else if(path=='/message'){
					this.activeindex="2"
					 window.sessionStorage.btnindex="2"
				}else if(path=='/lookhouse'){
					this.activeindex="3"
					 window.sessionStorage.btnindex="3"
				}else if(path=='/mine'){
					this.activeindex="4"
					 window.sessionStorage.btnindex="4"
				}else{
					this.activeindex="5"
					 window.sessionStorage.btnindex="5"
				}
				next()
		})
  },
  methods:{
    homebtn(){
      this.$router.push("/");
    },
    messagebtn(){
      this.$router.push("/message");
    },
    lookhousebtn(){
      this.$router.push("/lookhouse");
    },
    minebtn(){
      this.$router.push("/mine");
    }
  }
}
</script>

<style>
/* // @import 'common/css/master.less'; */
*{margin:0;padding:0;-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-text-size-adjust:none;-webkit-user-select:none;-ms-user-select:none;user-select:none;font-family:Arial, "微软雅黑";}
img{border:none;max-width:100%;vertical-align:middle;}
body,p,form,input,button,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6{margin:0;padding:0;list-style:none;overflow-x:hidden}
h1,h2,h3,h4,h5,h6{font-size:100%;}
input,textarea{-webkit-user-select:text;-ms-user-select:text;user-select:text;-webkit-appearance:none;font-size:1em;line-height:1.5em;}
table{border-collapse:collapse;}
input,select,textarea{outline:none;border:none;background:none;}
/* a{outline:0;cursor:pointer;*star:expression(this.onbanner=this.blur());} */
a:link,a:active{text-decoration:none;}
a:visited{text-decoration:none;}
a:hover{color:#f00;text-decoration:underline;}
a{text-decoration:none;-webkit-touch-callout:none;}
em,i{font-style:normal;}
li,ol{list-style:none;}
html{font-size:10px;}
.clear{clear:both;height:0;font-size:0;line-height:0;visibility:hidden; overflow:hidden;} 
.fl{float:left;}
.fr{float:right;}
html,body{ margin:0 auto;max-width:640px; min-width:320px;color:#555;background:#ffffff;height:100%;} 
#app{
  width:100%;
  height:100%;
}

#bottombtn{
   border-top:1px solid #666666;
   width:100%;
   height:0.5rem;
   position:fixed;
   bottom:0;
   left:0;
   display: flex;
  /* 父级设置子集的排列方向 */
   flex-direction: row;
  /* 子集横向排列 */
   align-items: center;
   /* 子集的内容纵向排列 */
   justify-content: center;
   text-align: center; 
   background:#fdfdfd;
   border-top:1px solid #cccccc;
   z-index:999;
 }
 #bottombtn li{
   /* 按照余下的空间子集进行比例分配 */
   flex: 1;
   font-size:0.14rem;
   
 }
  #bottombtn li>div{
   /* 按照余下的空间子集进行比例分配 */
  margin-top:0.27rem;
   
 }
.btnlione{
   background:url(imgs/home/homeimg.png) no-repeat;
   background-size:0.26rem;
   background-position:center 5%;
  
 }
.btnlionez{
   background:url(imgs/home/homexuanzhongimg.png) no-repeat;
   background-size:0.28rem;
   color:#FF4343;
   background-position:center 5%;
}
.btnlitwo{
   background:url(imgs/home/xiaoxiimg.png) no-repeat;
   background-size:0.26rem;
   background-position:center 5%;
  
 }
 .btnlitwoz{
   background:url(imgs/home/xiaoxixuanzhongimg.png) no-repeat;
   background-size:0.28rem;
   color:#FF4343;
   background-position:center 5%;
}
.btnlithree{
   background:url(imgs/home/yuekanimg.png) no-repeat;
   background-size:0.26rem;
   background-position:center 5%;
  
 }
.btnlithreez{
   background:url(imgs/home/yuekanxuanzhongming.png) no-repeat;
   background-size:0.28rem;
   color:#FF4343;
   background-position:center 5%;
}
.btnlifour{
   background:url(imgs/home/minimg.png) no-repeat;
   background-size:0.26rem;
   background-position:center 5%;
}
.btnlifourz{
   background:url(imgs/home/minexuanzhongimg.png) no-repeat;
   background-size:0.28rem 0.27rem;
   color:#FF4343;
   background-position:center 5%;
}

</style>
