<template>
    <div class="lookhouse">
        约看
    </div>
</template>
<script>
export default {
  
}
</script>
<style scoped lang="less">

</style>

