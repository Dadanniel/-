<template>
    <div class="mine">
        <headertwo :dataname="dataname"></headertwo>
    </div>
</template>
<script>
import headertwo from '../module/headertwo'
export default {
  data(){
      return{
          dataname:"我的"
      }
  },
  components:{
    headertwo
  }
}
</script>
<style scoped lang="less">

</style>

