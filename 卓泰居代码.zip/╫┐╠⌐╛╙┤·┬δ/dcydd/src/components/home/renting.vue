<template>
    <div class="renting">
       <div class="topseatch" :class="{searchboxwarpone:homemove==1,searchboxwarponea:homemove==2,searchboxwarponeb:homemove==3,searchboxwarponec:homemove==4,searchboxwarponed:homemove==5}">
            <img src="../../imgs/home/fanhui.png" alt="" @click="gohomebtn">
            <div id="topserchbox" :class="{searchboxone:homemove==1}">
                <img src="../../imgs/home/homesousuo.png" alt="" srcset="">
                <input type="text" placeholder="请输入您要搜索的内容">
            </div>
        </div>
        <mt-swipe :auto="4000" class="swiperitem">
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
        </mt-swipe>
        <div id="recommend">为你推荐</div>
          <swiper :options="swiperOptions" ref="mySwiper" class="swiperershoufangtwo">
            <!-- slides -->
            <swiper-slide class="swiperfangitemtwo">
                <div class="swipername">光明小区学区房</div>
                <div class="swipernametwo">
                    <span>保安</span>
                    <span>光明小区</span>
                    <span>基金白拿</span>
                </div>
                <div class="swipernametwo">
                    <span>2房2厅</span>
                    <span>89㎡</span>
                </div>
                <div class="swipernamethree" v-if="id=='1'">
                    235万
                    <span>13245元/平方</span>
                </div>
                <div class="swipernamefour" v-else>
                    123
                    <span>元/月</span>
                </div>
            </swiper-slide>
            <swiper-slide class="swiperfangitemtwo">
                <div class="swipername">光明小区学区房</div>
                <div class="swipernametwo">
                    <span>保安</span>
                    <span>光明小区</span>
                    <span>基金白拿</span>
                </div>
                <div class="swipernametwo">
                    <span>2房2厅</span>
                    <span>89㎡</span>
                </div>
                <div class="swipernamethree" v-if="id=='1'">
                    235万
                    <span>13245元/平方</span>
                </div>
                <div class="swipernamefour" v-else>
                    123
                    <span>元/月</span>
                </div>
            </swiper-slide>
            <swiper-slide class="swiperfangitemtwo">
                <div class="swipername">光明小区学区房</div>
                <div class="swipernametwo">
                    <span>保安</span>
                    <span>光明小区</span>
                    <span>基金白拿</span>
                </div>
                <div class="swipernametwo">
                    <span>2房2厅</span>
                    <span>89㎡</span>
                </div>
                <div class="swipernamethree" v-if="id=='1'">
                    235万
                    <span>13245元/平方</span>
                </div>
                <div class="swipernamefour" v-else>
                    123
                    <span>元/月</span>
                </div>
            </swiper-slide>
            <swiper-slide class="swiperfangitemtwo">
                <div class="swipername">光明小区学区房</div>
                <div class="swipernametwo">
                    <span>保安</span>
                    <span>光明小区</span>
                    <span>基金白拿</span>
                </div>
                <div class="swipernametwo">
                    <span>2房2厅</span>
                    <span>89㎡</span>
                </div>
                <div class="swipernamethree" v-if="id=='1'">
                    235万
                    <span>13245元/平方</span>
                </div>
                <div class="swipernamefour" v-else>
                    123
                    <span>元/月</span>
                </div>
            </swiper-slide>
        </swiper>

         <div class="tabercontent">
        <div class="shuaixuan" :class="{shuaixuanonesd:remover}">
    <ul class="taberlist">
        <li v-for="(item,index) in taberlist" @click="active=index" :class="{taberclass:id=='2'}">
            {{item}}
            <img src="../../imgs/home/xiangxia.png" alt="" srcset="">
        </li>
         
    </ul>
    <div class="shuaixuanone" v-if="active=='0'">
        <ul>
            <li v-for="(item,index) in erealistone">{{item}}</li>
            
        </ul>
        <ul>
            <li v-for="(item,index) in erealisttwo">{{item}}</li>
            
        </ul>
    </div>
    <div class="shuaixuantwo" v-else-if="active=='1'">
        <div v-for= "(item,index) in houselist">{{item}}</div>
        <p class="gobtnclass">确定</p>
    </div>
     <div class="shuaixuantwo shuaixuantwo_1 shuaixuantwo_input" v-else-if="active=='2'">
       <div v-for="(item,index) in moneylist">{{item}}</div>
       <input type="text">
       <p class="borderbottom"></p>
       <input type="text">
       <span class="moneyspan">自定义价格</span>
        <p class="gobtnclass">确定</p>
       
    </div>
    <div class="shuaixuantwo shuaixuantwo_1" v-else-if="active=='3'">
        <div v-for="(item,index) in acreagelist">{{item}}</div>
        <p class="gobtnclass">确定</p>
        
    </div>
     <div class="shuaixuantwo shuaixuantwo_2" v-else-if="active=='4'">
        <div v-for="(item,index) in typelist">{{item}}</div>
        <p class="gobtnclass">确定</p>
        
    </div>
    </div>
    <div class="cnxhlist" @click="removesreach">
            <div class="cnxhlistitem" @click="rentingitembtn">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>                          
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
        </div>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      id:1,//1=我要房子，2=我要租房
      homemove: 10,
      swiperOptions: {
        autoplay: true,
        slidesPerView: 1.851
      },
      remover:false,//控制滑动效果
      active: "5", //过滤控制
      moneylist:["50万以下","50-80万","80-110万","110万以上"],
      taberlist: ["区域", "户型", "价格", "面积", "类型"],
      erealistone: ["宝安区", "龙岗区", "龙华区", "南山区", "福田区"], //帅选区域列表
      erealisttwo: [
        "A片区",
        "B片区",
        "C片区",
        "D片区",
        "E片区",
        "F片区",
        "G片区",
        "W片区",
        "H片区"
      ], //帅选区域列表
      houselist: ["单间", "一房", "两房", "三房", "三房以上"], //户型帅选
      acreagelist: [
        "50㎡以下",
        "50-70㎡",
        "70-90㎡",
        "90-110㎡",
        "110-140㎡",
        "140-170㎡",
        "170-200㎡",
        "200㎡以上"
      ], //面积帅选
      typelist: ["普通住宅", "别墅", "商业类"] //住宅类型筛选
    };
  },
  mounted() {
    window.addEventListener("scroll", this.handleScroll);
  },
  created(){
       this.id= this.$route.query.id
       if(this.id=="2"){
           this.taberlist=["区域", "户型", "价格", "面积"]
       }
  },
  methods: {
    handleScroll() {
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;
      if (scrollTop >= "0" && scrollTop <= "40") {
        this.homemove = 10;
      } else if (scrollTop >= "40" && scrollTop <= "80") {
        this.homemove = 2;
      } else if (scrollTop >= "80" && scrollTop <= "120") {
        this.homemove = 3;
      } else if (scrollTop >= "120" && scrollTop <= "160") {
        this.homemove = 4;
      } else if (scrollTop >= "160" && scrollTop <= "200") {
        this.homemove = 5;
      } else {
        this.homemove = 1;
      }
      if(scrollTop < "365"){
          this.remover=false
      }else{
           this.remover=true
      }
    },
    gohomebtn() {
      this.$router.go(-1);
    },
    removesreach() {
      this.active = null;
    },
    rentingitembtn(){
      this.$router.push("/rentingitem")
    }
  }
};
</script>
<style scoped lang="less">
@import "../../common/css/master.less";
@import "../../common/css/search.css";
@import "../../common/css/fulist.css";
.renting {
  width: 100%;
  height: 100%;
}
.topseatch {
  border: none;
  background: rgba(255, 255, 255, 0);
}
.searchboxwarpone {
  width: 100%;
  height: 0.44rem;
  position: fixed;
  background: rgba(255, 255, 255, 1);
  top: 0;
  left: 0;
  z-index: 9999;
}
.searchboxwarponea {
  width: 100%;
  height: 0.44rem;
  position: fixed;
  background: rgba(255, 255, 255, 0.2);
  top: 0;
  left: 0;
  z-index: 9999;
}
.searchboxwarponeb {
  width: 100%;
  height: 0.44rem;
  position: fixed;
  background: rgba(255, 255, 255, 0.4);
  top: 0;
  left: 0;
  z-index: 9999;
}
.searchboxwarponec {
  width: 100%;
  height: 0.44rem;
  position: fixed;
  background: rgba(255, 255, 255, 0.6);
  top: 0;
  left: 0;
  z-index: 9999;
}
.searchboxwarponed {
  width: 100%;
  height: 0.44rem;
  position: fixed;
  background: rgba(255, 255, 255, 0.8);
  top: 0;
  left: 0;
  z-index: 9999;
}
.searchboxone {
  width: 3.3rem;
  height: 0.35rem;
  position: fixed;
  top: 0.0045rem;
  background-color: #f2f2f2;
  border-radius: 0.04rem;
}
.swiperitem {
  height: 2rem;
}
#recommend {
  width: 100%;
  text-indent: 0.12rem;
  font-size: 0.2rem;
  font-weight: bold;
  margin-top: 0.25rem;
}
.swiperershoufangtwo {
  width: 100%;
  overflow: hidden;
  margin-top: 0.15rem;
}
.swiperfangitemtwo {
  width: 1.9rem !important;
  height: 1.2rem;
  border-radius: 0.06rem;
  margin: 0;
  margin-left: 0.12rem;
  overflow: hidden;
  background: url(../../imgs/home/banner.png) no-repeat;
  background-size: 100% 100%;
}
.tabercontent {
  margin-top: 0.25rem;
}
.taberlist {
  border: none;
  background: #f9f9f9;
}
.cnxhlist {
  margin-bottom: 0;
}
.shuaixuanonesd{
    position: fixed;
    top:0.44rem;
    z-index:99999;
}
.taberclass{
    width:25% !important;
}
.swipername{
    width:100%;
    font-size: 0.18rem;
    color:#ffffff;
    margin-top:0.2rem;
    text-indent: 0.2rem;
}
.swipernametwo{
    font-size:0.13rem;
    margin-left:0.2rem;
    color:#ffffff;
}
.swipernametwo>span:nth-of-type(2){
    margin:0 0.05rem;
}
.swipernamethree{
    font-size:0.17rem;
    color:#ffc001;
    margin-left:0.2rem;
    margin-top:0.1rem;
}
.swipernamethree>span{
    margin-left:0.05rem;
    font-size:0.11rem;
    color:#ffffff;
}
.swipernamefour{
    font-size:0.2rem;
    color:#ffc001;
    margin-left:0.2rem;
    margin-top:0.1rem;
}
.swipernamefour>span{
    margin-left:0.05rem;
    font-size:0.11rem;
}
.gobtnclass{
    background:@colorone;
}
</style>

