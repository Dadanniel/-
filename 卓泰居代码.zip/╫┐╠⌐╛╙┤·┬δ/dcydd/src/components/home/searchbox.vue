<template>
  <div class="searchbox">
    <div class="searchboxitem">
         <div class="searchdiv_1">
            <div class="selectbox" @click.stop="select=!select">
                 {{selectitem}}
                <img src="../../imgs/home/xiangxia.png" alt="">
                <ul v-show="select">
                    <li v-for="item in selectlist" @click="selectbtn(item)">{{item}}</li>
                </ul>
            </div>
            <div id="searchbox_1">
                <img src="../../imgs/home/homesousuo.png" alt="" @click="messagebtn">
                <input type="text" placeholder="请输入您要搜索的内容" v-model="message" @focus="removecontentbtn">
            </div>
         </div>
         <div class="searchdiv_2" @click="gohomebtn">取消</div>
    </div>

    <div>
        <div class="contenttite">
            历史记录
        </div>
        <div class="content">
            <div v-for="item in messagelist" @click="messageitembtn(item)">{{item}}</div>
            
        </div>
    </div>
        
  </div>
</template>

<script scoped>
import {MessageBox} from 'mint-ui'
export default {
  data () {
    return {
        message:"",
        select:false,
        selectlist:["二手房","租房","小区"],
        selectitem:"二手房",
        messagelist:[],
        active:"3",
        rangeValue:2
    }
  },
  created(){
   if(window.sessionStorage.messagelist!==undefined){
       this.messagelist=JSON.parse(window.sessionStorage.messagelist)
   }
  },
  methods:{
    messagebtn(){
        if(this.message){
            this.$router.push("/searchlist")
            if(this.messagelist.indexOf(this.message)=="-1"){
               this.messagelist.splice(0, 0,this.message);  
               if(this.messagelist.length>6){
                  this.messagelist.splice(5,1)
               }
               window.sessionStorage.messagelist=JSON.stringify(this.messagelist) 
            }
            
        }else{
            MessageBox("提示","请输入您要搜索的内容")
        }
    },
    removecontentbtn(){
        this.remove=true
    },
    messageitembtn(item){
        this.message=item
    },
    selectbtn(item){
    this.selectitem=item
    },
    gohomebtn(){
        this.$router.go(-1)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped lang="less">
@import '../../common/css/master.less';
@import '../../common/css/fulist.css';
.searchbox{
    width:100%;
    overflow: hidden;
}
.searchboxitem{
    width:100%;
    height:0.44rem;
    position: fixed;
    top:0;
    left:0;
    border-bottom:1px solid #cccccc;
    z-index:9999;
    background:#ffffff;
}
.searchdiv_1{
    width:2.9rem;
    height:0.35rem;
    margin-top:0.045rem;
    margin-left:0.2rem;
    background:#f2f2f2;
    border-radius: 0.03rem;
    float:left;
}
.searchdiv_2{
    height:100%;
    float:left;
    font-size:0.16rem;
    line-height: 0.44rem;
    margin-left:0.15rem;
}
.selectbox{
    float:left;
    height: 0.35rem;
    line-height: 0.35rem;
    float:left;
    margin-left:0.1rem;
    font-size:0.15rem;
    text-align: center;
    position: relative;
}
.selectbox>ul{
    width:0.95rem;
    left:-0.15rem;
    position: absolute;
    top:0.38rem;
    background:url(../../imgs/home/sousuotankuang.png) no-repeat;
    height:1.3rem;
    background-size:100% 100%;

}
.selectbox>ul>li{
    height:0.4rem;
    width:95%;
    // float:left;
    margin:auto;
    border-bottom:1px solid #cccccc;
    text-align: center;
    box-sizing: border-box;
}
.selectbox>ul>li:nth-of-type(1){
    margin-top:0.1rem;
    
}
.selectbox>ul>li:nth-last-of-type(1){
    border:none;
}
.selectbox>ul>li:active{
    color:@colorone;
}
#searchbox_1{
    width:2rem;
    height:0.35rem;
    float:left;
    font-size:0.16rem;
    line-height: 0.35rem;
    margin-left:0.1rem;

}
#searchbox_1>img{
    width:0.16rem;
}
#searchbox_1>input{
    width:1.7rem;
    height:100%;
    
    font-size:0.13rem;
    color: #999999;
}
.contenttite{
    width:100%;
    font-size:0.18rem;
    font-weight:bold;
    padding-top:0.9rem;
    margin-left:0.12rem;
}
.content{
    padding-left:0.12rem;
    padding-right:0.3rem;
    margin-top:0.2rem;
    overflow: hidden;
}
.content>div{
    font-size:0.15rem;
    padding:0.1rem;
    color:#666666;
    background: #f9f9f9;
    float:left;
    margin-bottom:0.1rem;
    margin-left:0.05rem;
    border-radius: 0.04rem;
}
.taberlist{
    position:fixed;
    top:0.45rem;
    left:0;
}
.taberlist>li{
    width:20%;
}
.cnxhlist {
    margin-bottom:0;
    margin-top:0.35rem;
  }
</style>
