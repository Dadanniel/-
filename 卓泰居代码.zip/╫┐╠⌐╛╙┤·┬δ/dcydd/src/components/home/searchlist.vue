<template>
  <div class="searchlist">
    <div class="topseatch">
        <img src="../../imgs/home/fanhui.png" alt="" @click="gohomebtn">
        <div id="topserchbox">
            <img src="../../imgs/home/homesousuo.png" alt="" srcset="">
            <input type="text" placeholder="请输入您要查询的信息">
        </div>
    </div>
    
    <div class="tabercontent">
    <div class="shuaixuan">
    <ul class="taberlist">
        <li v-for="(item,index) in taberlist" @click="active=index">
            {{item}}
            <img src="../../imgs/home/xiangxia.png" alt="" srcset="">
        </li>
         
    </ul>
    <div class="shuaixuanone" v-if="active=='0'">
        <ul>
            <li v-for="(item,index) in erealistone">{{item}}</li>
            
        </ul>
        <ul>
            <li v-for="(item,index) in erealisttwo">{{item}}</li>
            
        </ul>
    </div>
    <div class="shuaixuantwo" v-else-if="active=='1'">
        <div v-for= "(item,index) in houselist">{{item}}</div>
        <p class="gobtnclass">确定</p>
        
    </div>
    <div class="shuaixuantwo shuaixuantwo_1 shuaixuantwo_input" v-else-if="active=='2'">
       <div v-for="(item,index) in moneylist">{{item}}</div>
       <input type="text">
       <p class="borderbottom"></p>
       <input type="text">
       <span class="moneyspan">自定义价格</span>
        <p class="gobtnclass">确定</p>
       
    </div>
    <div class="shuaixuantwo shuaixuantwo_1" v-else-if="active=='3'">
        <div v-for="(item,index) in acreagelist">{{item}}</div>
        <p class="gobtnclass">确定</p>
        
    </div>
     <div class="shuaixuantwo shuaixuantwo_2" v-else-if="active=='4'">
        <div v-for="(item,index) in typelist">{{item}}</div>
        <p class="gobtnclass">确定</p>
    </div>
    </div>
    <div class="cnxhlist" @click="removesreach">
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>                          
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
        </div>
        </div>
  </div>
</template>

<script>

export default {
  name: 'HelloWorld',
  data () {
    return {
      active:"5",//过滤控制
      moneylist:["50万以下","50-80万","80-110万","110万以上"],
      taberlist:['区域','户型','价格','面积','类型'],
      erealistone:["宝安区","龙岗区","龙华区","南山区","福田区"],//帅选区域列表
      erealisttwo:['A片区','B片区','C片区','D片区','E片区','F片区','G片区','W片区','H片区'],//帅选区域列表
      houselist:['单间','一房','两房','三房','三房以上'],//户型帅选
      acreagelist:["50㎡以下","50-70㎡","70-90㎡","90-110㎡","110-140㎡","140-170㎡","170-200㎡","200㎡以上"],//面积帅选
      typelist:["普通住宅","别墅","商业类"],//住宅类型筛选
    }
  },
  created(){
    
  },
  methods:{
    gohomebtn(){
        this.$router.go(-1)
    },
    removesreach(){
        this.active=null
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped lang="less">
@import '../../common/css/master.less';
@import '../../common/css/search.css';
@import '../../common/css/fulist.css';
.tabercontent{
    margin-top:0.44rem;
}
#shuaixuancolor{
    color:@colorone;
}
.shuaixuanname{
    color:@colorone;
}
// .taberlist{
//     position: fixed;
//     top:0.45rem;
// }
.cnxhlist{
    margin-top:0.35rem;
    margin-bottom:0;
}
.shuaixuan{
    position: fixed;
    top:0.44rem;
}
.gobtnclass{
    background:@colorone;
}
</style>
