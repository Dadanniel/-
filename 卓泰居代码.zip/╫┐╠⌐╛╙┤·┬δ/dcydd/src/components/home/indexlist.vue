<template>
  <div class="indexlist">
    <div class="topseatch">
        <img src="../../imgs/home/fanhui.png" alt="" @click="gohomebtn">
        <div id="topserchbox">
            <img src="../../imgs/home/homesousuo.png" alt="" srcset="">
            <input type="text" placeholder="输入城市名">
        </div>
    </div>

    <mt-index-list class="indexlistbox">
        <mt-index-section index="当前">
            <mt-cell title="深圳"></mt-cell>
        </mt-index-section>
        <mt-index-section index="热门">
            <mt-cell title="北京"></mt-cell>
            <mt-cell title="上海"></mt-cell>
        </mt-index-section>
        <mt-index-section index="Z">
            <mt-cell title="Zack"></mt-cell>
            <mt-cell title="Zane"></mt-cell>
        </mt-index-section>
         <mt-index-section index="C">
            <mt-cell title="Aaron"></mt-cell>
            <mt-cell title="Alden"></mt-cell>
            <mt-cell title="Austin"></mt-cell>
        </mt-index-section>
        <mt-index-section index="D">
            <mt-cell title="Baldwin"></mt-cell>
            <mt-cell title="Braden"></mt-cell>
        </mt-index-section>
        <mt-index-section index="E">
            <mt-cell title="Zack"></mt-cell>
            <mt-cell title="Zane"></mt-cell>
        </mt-index-section>
          <mt-index-section index="G">
            <mt-cell title="Zack"></mt-cell>
            <mt-cell title="Zane"></mt-cell>
        </mt-index-section>
         <mt-index-section index="N">
            <mt-cell title="Aaron"></mt-cell>
            <mt-cell title="Alden"></mt-cell>
            <mt-cell title="Austin"></mt-cell>
        </mt-index-section>
        <mt-index-section index="K">
            <mt-cell title="Baldwin"></mt-cell>
            <mt-cell title="Braden"></mt-cell>
        </mt-index-section>
        <mt-index-section index="L">
            <mt-cell title="Zack"></mt-cell>
            <mt-cell title="Zane"></mt-cell>
        </mt-index-section>
    </mt-index-list>
  </div>
</template>

<script>

import {IndexList, IndexSection,Cell} from 'mint-ui'
export default {
  name: 'HelloWorld',
  data () {
    return {
    }
  },
  methods:{
    gohomebtn(){
        this.$router.go(-1)
    }
  },

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped lang="less">
@import '../../common/css/search.css';

</style>
