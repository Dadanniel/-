<template>
    <div class="home">
        
        <div class="swiper">
            <mt-swipe :auto="4000" class="swiperitem">
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
            </mt-swipe>
            <div class="searchboxwarp" :class="{searchboxwarpone:homemove==1,searchboxwarponea:homemove==2,searchboxwarponeb:homemove==3,searchboxwarponec:homemove==4,searchboxwarponed:homemove==5}">
               <div class="searchbox" :class="{searchboxone:homemove==1}">
                    <div id="serchitem">
                        <div id="serchleft" @click="indexlistbtn">
                            <span>深圳</span>
                            <img src="../../imgs/home/xiangxia.png" alt="" srcset="">
                        </div>
                        <div id="serchright" @click="sarchbtn">
                            <img src="../../imgs/home/homesousuo.png" alt="">
                            <!-- <input type="text" placeholder="搜索心意住所"> -->
                            <div> 搜索心意住所 </div>
                        </div>   
                    </div> 
                </div>
            </div>
        </div>
        <ul class="btnbox">
            <li @click="rentingbtn">
                <img src="../../imgs/home/woyaomaifang.png" alt="">
                <div>我要房子</div>
            </li>
            <li @click="rentingbtntwo">
                <img src="../../imgs/home/woyaozufang.png" alt="">
                <div>我要租房</div>
            </li>
            <li>
                <img src="../../imgs/home/woyaoshouzu.png" alt="">
                <div>我要售/租</div>
            </li>
            <li>
                <img src="../../imgs/home/dituzhaopang.png" alt="">
                <div>地图找房</div>
            </li>
            <li>
                <img src="../../imgs/home/xiaoquzhaopang.png" alt="">
                <div>小区找房</div>
            </li>
             <li>
                <img src="../../imgs/home/zhaojinjiren.png" alt="">
                <div>找经纪人</div>
            </li>
            <li>
                <img src="../../imgs/home/zhaomengdian.png" alt="">
                <div>找门店</div>
            </li>
            <li>
                <img src="../../imgs/home/changyonggongju.png" alt="">
                <div>常用工具</div>
            </li>
        </ul>
        <img class="yinyingfengimg" src="../../imgs/home/yinyingfengge.png" alt="" srcset="">
        <div class="erlist">
            <div>二手房购买指南</div>
            <div>查看更多</div>
        </div>
         <swiper :options="swiperOption" ref="mySwiper" class="swiperershoufang">
            <!-- slides -->
            <swiper-slide class="swiperfangitem">
                <div class="sweperimg">
                    <img src="../../imgs/home/banner.png" alt="" srcset="">
                </div>
                <div class="sweperboxcent">
                    <div>如何购买心意房屋地方发动机</div>
                    <div>如何购买心意房屋地方发动机</div>
                </div>
            </swiper-slide>
            <swiper-slide class="swiperfangitem">
                <div class="sweperimg">
                    <img src="../../imgs/home/banner.png" alt="" srcset="">
                </div>
                <div class="sweperboxcent">
                    <div>如何购买心意房屋地方发动机</div>
                    <div>如何购买心意房屋地方发动机</div>
                </div>
            </swiper-slide>
            <swiper-slide class="swiperfangitem">
                <div class="sweperimg">
                    <img src="../../imgs/home/banner.png" alt="" srcset="">
                </div>
                <div class="sweperboxcent">
                    <div>如何购买心意房屋地方发动机</div>
                    <div>如何购买心意房屋地方发动机</div>
                </div>
            </swiper-slide>
            <swiper-slide class="swiperfangitem">
                <div class="sweperimg">
                    <img src="../../imgs/home/banner.png" alt="" srcset="">
                </div>
                <div class="sweperboxcent">
                    <div>如何购买心意房屋地方发动机</div>
                    <div>如何购买心意房屋地方发动机</div>
                </div>
            </swiper-slide>
        </swiper>

         <div class="pingrongji">平台二手房成交量统计</div>
         <div class="ershoufangimg">
             <div id="fangwuleft">
                 <div>全市1月均价</div>
                 <div>一月世华成交量</div>
             </div>
             <div id="fangwuright">
                 <div>23456<span>元/平米</span></div>
                 <div>56<span>套</span></div>
             </div>
         </div>
         <div class="erlisttwo">
            <div>热门小区</div>
            <div @click="hotdistrictbtn">查看更多</div>
        </div>

         <swiper :options="swiperOptions" ref="mySwiper" class="swiperershoufangtwo">
            <!-- slides -->
            <swiper-slide class="swiperfangitemtwo">
                <img src="../../imgs/home/banner.png" alt="" srcset="">
                <div class="xiaoquname">光明小区</div>
                <div class="xiaoqunum">在售10套/在租1套</div>
                <div class="xiaoqumoney">2345<span>元/平米</span></div>
            </swiper-slide>
            <swiper-slide class="swiperfangitemtwo">
                <img src="../../imgs/home/banner.png" alt="" srcset="">
                <div class="xiaoquname">光明小区</div>
                <div class="xiaoqunum">在售10套/在租1套</div>
                <div class="xiaoqumoney">2345<span>元/平米</span></div>
            </swiper-slide>
            <swiper-slide class="swiperfangitemtwo">
                <img src="../../imgs/home/banner.png" alt="" srcset="">
                <div class="xiaoquname">光明小区</div>
                <div class="xiaoqunum">在售10套/在租1套</div>
                <div class="xiaoqumoney">2345<span>元/平米</span></div>
            </swiper-slide>
            <swiper-slide class="swiperfangitemtwo">
                <img src="../../imgs/home/banner.png" alt="" srcset="">
                <div class="xiaoquname">光明小区</div>
                <div class="xiaoqunum">在售10套/在租1套</div>
                <div class="xiaoqumoney">2345<span>元/平米</span></div>
            </swiper-slide>
        </swiper>
        <div class="erlisttwo">
            <div>猜你喜欢</div>
            <div>
                <span style="color:@colorone;margin-right:0.1rem">二手房</span>
                <span style="color:#666666">租房</span>
            </div>
        </div>
        <div class="cnxhlist">
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
        </div>
    </div>
</template>
<script>
import { MessageBox } from 'mint-ui';
export default {
  data() {
    return {
      homemove:10,
      swiperOption: {
        autoplay: true,
        slidesPerView: 1.43,
        spaceBetween: 10
      },
      swiperOptions: {
        autoplay: true,
        slidesPerView: 2.17
      }
    };
  },
  created(){
    if (navigator.geolocation) { 
         navigator.geolocation.getCurrentPosition( // 该函数有如下三个参数
        function(pos){ // 如果成果则执行该回调函数
            var latitude = pos.coords.latitude//经度
            var longitude = pos.coords.longitude//纬度
            alert(latitude)
            var url = "http://api.map.baidu.com/geocoder/v2/?callback=renderReverse&location=latitude,longitude&output=json&pois=1&ak=78b5875728ae0f81f08379e3b8790f1e"
            this.$http.get(url)
            .then((response)=>{
                console.log(response)
                alert(response)
            })
        }
        )
     } else {   
        MessageBox('提示', '您的浏览器不支持获取地理位置服务'); 
     } 
  },
  mounted () {  
   window.addEventListener('scroll', this.handleScroll)
  },
  methods:{
    handleScroll () {
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
       if(scrollTop>="0"&&scrollTop<="40"){
           this.homemove=10
       }else if(scrollTop>="40"&&scrollTop<="80"){
           this.homemove=2
       }else if(scrollTop>="80"&&scrollTop<="120"){
           this.homemove=3
       }else if(scrollTop>="120"&&scrollTop<="160"){
           this.homemove=4
       }else if(scrollTop>="160"&&scrollTop<="200"){
           this.homemove=5
       }else{
           this.homemove=1
       }
    },
    indexlistbtn(){
        this.$router.push("/indexlist")
    },
    sarchbtn(){
        this.$router.push("/searchbox")
    },
    hotdistrictbtn(){
        this.$router.push("/hotdistrict")
    },
    rentingbtn(){
        this.$router.push({path:'/renting/', query: {id:'1'}})
    },
    rentingbtntwo(){
        this.$router.push({path:'/renting/', query: {id:'2'}})
    }
  }
};
</script>

<style scoped lang="less">
@import '../../common/css/fulist.css';
@import '../../common/css/master.less';
.home {
  width: 100%;
  height: 8rem;
}
.swiper {
  width: 100%;
  height: 2rem;
}
.swiper > img {
  width: 100%;
  height: 100%;
}
.searchboxwarp{
    width:100%;
    height:0.6rem;
    position: fixed;
    background:rgba(255,255 , 255,0);
    top:0;
    left:0;
    z-index: 9999;
}
.searchboxwarpone{
    width:100%;
    height:0.6rem;
    position: fixed;
    background:rgba(255,255 , 255,1);
    top:0;
    left:0;
    z-index: 9999;
}
.searchboxwarponea{
    width:100%;
    height:0.6rem;
    position: fixed;
    background:rgba(255,255 , 255,0.2);
    top:0;
    left:0;
    z-index: 9999;
}
.searchboxwarponeb{
    width:100%;
    height:0.6rem;
    position: fixed;
    background:rgba(255,255 , 255,0.4);
    top:0;
    left:0;
    z-index: 9999;
}
.searchboxwarponec{
    width:100%;
    height:0.6rem;
    position: fixed;
    background:rgba(255,255 , 255,0.6);
    top:0;
    left:0;
    z-index: 9999;
}
.searchboxwarponed{
    width:100%;
    height:0.6rem;
    position: fixed;
    background:rgba(255,255 , 255,0.8);
    top:0;
    left:0;
    z-index: 9999;
}
.searchbox {
  width: 3.3rem;
  height: 0.4rem;
  position: fixed;
  top: 0.1rem;
  left: 0.225rem;
  background-color: #ffffff;
  border-radius: 0.04rem;
}
.searchboxone{
  width: 3.3rem;
  height: 0.4rem;
  position: fixed;
  top: 0.1rem;
  left: 0.225rem;
  background-color: #f2f2f2;
  border-radius: 0.04rem;
}
#serchitem {
  width: 100%;
  height: 0.2rem;
  margin-top: 0.1rem;
}
#serchleft {
  width: 25%;
  height: 100%;
  border-right: 1px solid #999999;
  text-align: center;
  font-size: 0.15rem;
  color: #333333;
  float: left;
  box-sizing: border-box;
}
#serchright {
  width: 75%;
  height: 100%;
  float: left;
}
#serchright > img {
  float: left;
  width: 0.15rem;
  height: 0.15rem;
  margin-left: 0.15rem;
  margin-top: 0.025rem;
}
#serchright > div {
  height: 100%;
  margin-left: 0.05rem;
  width: 70%;
  float: left;
  font-size: 0.15rem;
  color: #999999;
}
.btnbox {
  width: 100%;
  overflow: hidden;
  list-style: none;
}
.btnbox > li > img {
  width: 0.5rem;
  height: 0.5rem;
}
.btnbox > li {
  width: 25%;
  float: left;
  font-size: 0.14rem;
  text-align: center;
  margin-top: 0.2rem;
}
.yinyingfengimg {
  margin-top: 0.2rem;
  float: left;
  width: 100%;
}
.erlist {
  width: 100%;
  overflow: hidden;
  margin-top: 0.52rem;
}
.erlist > div:nth-of-type(1) {
  float: left;
  margin-left: 0.12rem;
  height: 0.2rem;
  border-left: 4px solid red;
  text-indent: 0.1rem;
  font-size: 0.16rem;
  line-height: 0.2rem;
  box-sizing: border-box;
}
.erlisttwo {
  width: 100%;
  overflow: hidden;
  margin-top: 0.3rem;
}
.erlisttwo > div:nth-of-type(1) {
  float: left;
  margin-left: 0.12rem;
  height: 0.2rem;
  border-left: 4px solid @colorone;
  text-indent: 0.1rem;
  font-size: 0.16rem;
  line-height: 0.2rem;
  box-sizing: border-box;
}
.erlisttwo > div:nth-of-type(2) {
  float: right;
  margin-right: 0.12rem;
  height: 0.2rem;
  text-indent: 0.1rem;
  font-size: 0.14rem;
  line-height: 0.2rem;
  color: #2581ff;
}
.pingrongji {
  float: left;
  margin-left: 0.12rem;
  height: 0.2rem;
  border-left: 4px solid red;
  text-indent: 0.1rem;
  font-size: 0.16rem;
  line-height: 0.2rem;
  box-sizing: border-box;
  margin-top: 0.3rem;
}
.erlist > div:nth-of-type(2) {
  float: right;
  margin-right: 0.12rem;
  height: 0.2rem;
  text-indent: 0.1rem;
  font-size: 0.14rem;
  line-height: 0.2rem;
  color: #2581ff;
}
.swiperershoufang {
  width: 100%;
  height: 1rem;
  margin-top: 0.2rem;
}
.swiperfangitem {
  width: 2.5rem !important;
  height: 100%;
  margin-left: 0.1rem;
  background: #f9f9f9;
}
.swiperershoufangtwo {
  width: 100%;
  overflow: hidden;
  margin-top: 0.2rem;
}
.swiperfangitemtwo {
  width: 1.6rem !important;
  margin: 0;
  margin-left: 0.12rem;
  overflow: hidden;
}
.swiperfangitemtwo > img {
  width: 100%;
  height: 1.2rem;
  float: left;
}
.tongjiboximgP {
  width: 100%;
}
.sweperimg {
  width: 1rem;
  height: 0.9rem;
  margin-top: 0.05rem;
  margin-left: 0.05rem;
  float: left;
}
.sweperimg > img {
  float: left;
  width: 100%;
  height: 100%;
}
.sweperboxcent {
  width: 1.1rem;
  float: left;
  margin-left: 0.2rem;
}
.sweperboxcent > div:nth-of-type(1) {
  width: 100%;
  font-size: 0.15rem;
  color: #333333;
  margin-top: 0.1rem;
}
.sweperboxcent > div:nth-of-type(2) {
  width: 100%;
  font-size: 0.12rem;
  color: #666666;
  margin-top: 0.05rem;
}
.ershoufangimg {
  width: 3.5rem;
  height: 1.2rem;
  display: block;
  margin: auto;
  margin-top: 0.7rem;
  background: url(../../imgs/home/tongjibeijing.png) no-repeat;
  background-size: 100% 100%;
}
#fangwuleft {
  width: 100%;
  overflow: hidden;
}
#fangwuleft > div {
  width: 50%;
  float: left;
  text-indent: 0.2rem;
  color: #fff6d9;
  font-size: 0.15rem;
  margin-top: 0.3rem;
}
#fangwuright {
  width: 100%;
  overflow: hidden;
}
#fangwuright > div {
  width: 50%;
  float: left;
  text-indent: 0.2rem;
  color: #ffc001;
  font-size: 0.24rem;
  margin-top: 0.2rem;
}
#fangwuright > div > span {
  font-size: 0.12rem;
}
.xiaoquname {
  width: 100%;
  float: left;
  font-size: 0.18rem;
  color: #333333;
  margin-top: 0.1rem;
}
.xiaoqunum {
  width: 100%;
  float: left;
  font-size: 0.13rem;
  color: #666666;
  margin-top: 0.1rem;
}
.xiaoqumoney {
  width: 100%;
  float: left;
  font-size: 0.19rem;
  color: #ff4343;
  margin-top: 0.1rem;
}
.xiaoqumoney > span {
  font-size: 0.11rem;
}

</style>

