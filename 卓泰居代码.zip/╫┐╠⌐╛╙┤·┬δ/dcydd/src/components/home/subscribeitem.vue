<template>
    <div class="subscribeitem">
        <headerone :dataname="dataname"></headerone>
         <div class="cnxhlist" >
           <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
        </div>
        <ul class="nameclass">
            <li>
                <span>姓名</span>
                <input type="text" placeholder="请输入您的姓名">
            </li>
            <li>
                <span>电话</span>
                <input type="text" placeholder="请输入您的电话">
            </li>
        </ul>
        <div class="yuyuekanfagn"> 
            <span>预约看房时间</span>
            <img src="../../imgs/home/gengduojiantou.png" alt="">
        </div>
        <buttonone class="buttonone" :buttonname="buttonname"></buttonone>
    </div>
</template>
<script>
import headerone from '../module/headertwo'
import buttonone from '../module/buttonone'
export default {
   data(){
      return{
          dataname:"预约看房",
          buttonname:"提交"
      }
  },
  components:{
    headerone,
    buttonone
  }
}
</script>
<style scoped lang="less">
@import '../../common/css/fulist.css';
    .subscribeitem{
        width:100%;
        min-height:100%;
        background-color:#f8f8f8;
    }
    .cnxhlist{
        margin-top:0.54rem;
        margin-bottom:0;
        background-color:#ffffff;
    }
    .nameclass{
        width:100%;
        overflow: hidden;
        background-color:#ffffff;
        margin-top:0.15rem;
        float:left;
    }
    .nameclass>li{
        margin-left:0.12rem;
        margin-right:0.12rem;
        height:0.5rem;
        line-height: 0.5rem;
    }
    .nameclass>li:nth-of-type(1){
        border-bottom:1px solid #cacaca;
    }
    .nameclass>li>span{
        font-size:0.17rem;
        color:#282828;
        float:left;
    }
    .nameclass>li>input{
        float:left;
        height:0.25rem;
        font-size:0.15rem;
        color:#999999;
        float:left;
        margin-left:0.3rem;
        padding-top:0.125rem;
    }
    .yuyuekanfagn{
        width:100%;
        height:0.5rem;
        margin-top:0.1rem;
        float:left;
        background-color:#ffffff;
        line-height: 0.5rem;
    }
    .yuyuekanfagn>span{
        margin-left:0.12rem;
        font-size:0.17rem;
        color:#282828;
        float:left;
    }
    .yuyuekanfagn>img{
        float:right;
        width:0.1rem;
        height:0.18rem;
        margin-right:0.12rem;
        padding-top:0.16rem;
    }
    .buttonone{
        float:left;
        margin-left:10%;
        margin-top:0.8rem;
    }
</style>