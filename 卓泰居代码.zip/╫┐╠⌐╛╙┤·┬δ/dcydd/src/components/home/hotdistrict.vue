<template>
    <div class="hotdistrict">
        <headerone :dataname="dataname"></headerone>
         <div class="cnxhlist" >
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            在售10套/在租1套
                        </div>
                        
                         <div class="cnxhconterfive">
                            <div>3456<span>元/平米</span></div>           
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            在售10套/在租1套
                        </div>
                        
                         <div class="cnxhconterfive">
                            <div>3456<span>元/平米</span></div>           
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            在售10套/在租1套
                        </div>
                        
                         <div class="cnxhconterfive">
                            <div>3456<span>元/平米</span></div>           
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            在售10套/在租1套
                        </div>
                        
                         <div class="cnxhconterfive">
                            <div>3456<span>元/平米</span></div>           
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            在售10套/在租1套
                        </div>
                        
                         <div class="cnxhconterfive">
                            <div>3456<span>元/平米</span></div>           
                        </div>
                    </div>
                </div>              
            </div>
            
        </div>
       
    </div>
</template>
<script>
import headerone from '../module/headertwo'
export default {
  data(){
      return{
          dataname:"热门小区"
      }
  },
  components:{
    headerone
  }
}
</script>
<style scoped lang="less">
    .hotdistrict{
        width:100%;
        height:100%;
    }
</style>
<style scoped lang="less">
@import '../../common/css/fulist.css';
.cnxhlist{
    margin-top:0.44rem;
    margin-bottom:0;
}
.cnxhconterone{
    font-size:0.18rem;
}
.cnxhcontertwo{
    font-size:0.13rem;
    margin-top:0.15rem;
    margin-bottom:0.2rem;
}
.cnxhconterfive{
    font-size:0.19rem;

}
.cnxhconterfive span{
    font-size:0.11rem;
}
</style>
