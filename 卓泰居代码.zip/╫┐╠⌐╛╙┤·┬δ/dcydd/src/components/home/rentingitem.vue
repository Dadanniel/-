<template>
    <div class="rentingitem">
         <img class="gorentingimg" src="../../imgs/home/fanhui.png" alt="" @click="gohomebtn">
         <img class="titleimgone" v-if="movehx" src="../../imgs/home/shoucangxz.png" alt="">
         <img class="titleimgone" v-else src="../../imgs/home/shouchangwxz.png" alt="">
         <img class="fengxiangimg" src="../../imgs/home/fengxiang.png" alt="">
         <mt-swipe :auto="4000" class="swiperitem">
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
            <mt-swipe-item>
                <img src="../../imgs/home/banner.png" alt="" srcset="">
            </mt-swipe-item>
        </mt-swipe>
        <div class="locathionclass">
            <div>光明小区学区房</div>
            <div>
                <div>234<span>万</span></div>
                <div>12345万/平米</div>
            </div>
        </div>
        <div class="locathionname">
            房源信息
        </div>
        <ul class="ullistname">
            <li>朝向：<span>朝南</span></li>
            <li>大小：<span>68㎡</span></li>
            <li>户型：<span>一室一厅</span></li>
            <li>类型：<span>公寓</span></li>
            <li>装修：<span>精装</span></li>
            <li>房龄：<span>5年</span></li>
            <li>其他：<span>姜黄色分散爱的方式看大声道</span></li>
        </ul>
        <div class="fangywz">房源位置</div>
        <div id="container" tabindex="0"></div>
        <div class="fangywz">房源简介</div>
        <div class="moreApratInfo">
            发的撒娇破发怕山东矿机PDF刷卡机票按实际盘点就怕是附近啪讲评奖品就怕积分多怕死聚魄丹静安寺东风大街上欧尼酱都是击破房间票数家时代峻峰o
            否阿什顿符号是调试哦大叔覅啥都福胡打死哈佛我按时佛我阿US黄大发is回复我慧法师号   打司机佛啊会会发生哦少数哈哈搜我哈佛ID哈市覅哈会哦我好我活动合法U盾反杀福安市丰厚的搜狐发哦哈佛爱好地方好房  
            发的腮红<span>【更多】</span>
        </div>
        <div class="fangywz">关联小区</div>
        <div class="cnxhlists" >
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterones">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwos">
                            在售10套/在租1套
                        </div>
                        
                         <div class="cnxhconterfives">
                            <div>3456<span>元/平米</span></div>           
                        </div>
                    </div>
                </div>              
            </div>
             <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterones">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwos">
                            在售10套/在租1套
                        </div>
                        
                         <div class="cnxhconterfives">
                            <div>3456<span>元/平米</span></div>           
                        </div>
                    </div>
                </div>              
            </div>
        </div>
        <div class="shoubianfang">周边房源</div>
        <div class="cnxhlist">
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
            <div class="cnxhlistitem">
                <div class="cnxhcontnet">
                    <div class="cnxhcontnetleft">
                        <img src="../../imgs/home/banner.png" alt="">
                    </div>
                    <div class="cnxhcontnetright">
                        <div class="cnxhconterone">
                            光明小区学区房
                        </div>
                        <div class="cnxhcontertwo">
                            保安 光明小区 给付对价
                        </div>
                        <div class="cnxhconterthree">
                            2房2厅 86m² 
                        </div>
                        <div class="cnxhconterfour">
                            <div>学区房</div>
                            <div>地铁旁</div>
                            <div>超市旁</div>
                        </div>
                         <div class="cnxhconterfive">
                            <div>345万</div>
                            <div>1234元/平方</div>
                            
                        </div>
                    </div>
                </div>              
            </div>
        </div>
        <ul class="btnbottomul">
            <li @click="subscribeitem">预约看房</li>
            <li @click="warpdivbl=true">联系经纪人</li>
        </ul>
        <div class="warpdiv" v-show="warpdivbl">
            <div>
                <div class="messagebox">
                     <img src="../../imgs/home/banner.png" alt="">
                     <div>
                         <div>刘大姐</div>
                         <div>电话：123 4564 1321</div>
                         <div>一句话介绍经纪人</div>
                     </div>
                </div>
                <ul class="phonebtn">
                    <li>
                        <img src="../../imgs/home/dianhua.png" alt="">
                        电话
                    </li>
                    <li>
                        <img src="../../imgs/home/duanxin.png" alt="">
                        短信
                    </li>
                </ul>
            </div>
            <img src="../../imgs/home/fuanbibtn.png" alt="" @click="warpdivbl=false">
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      movehx: false,
      warpdivbl:false
    };
  },
  created(){
  },
  methods: {
    gohomebtn() {
      this.$router.go(-1);
    },
    subscribeitem(){
        this.$router.push("/subscribeitem")
    }
  },
  mounted() {
    var map = new AMap.Map('container', {
        resizeEnable: true,
        zoom:11,
        center: [116.397428, 39.90923]
     });
  }
};
</script>
<style scoped lang="less">
@import "../../common/css/master.less";
@import '../../common/css/fulist.css';
.cnxhlists{
    margin-bottom:0;
}
.cnxhlists>div:nth-last-of-type(1){
    border-bottom:1px solid #cccccc;
}
.cnxhconterones{
    font-size:0.18rem;
}
.cnxhcontertwos{
    font-size:0.13rem;
    margin-top:0.15rem;
    margin-bottom:0.2rem;
}
.cnxhconterfives{
    font-size:0.19rem;

}
.cnxhconterfives span{
    font-size:0.11rem;
}
.rentingitem {
  width: 100%;
  height: 100%;
}
.swiperitem {
  width: 100%;
  height: 2rem;
}
.gorentingimg {
  width: 0.12rem;
  height: 0.2rem;
  position: absolute;
  top: 0.12rem;
  left: 0.12rem;
  display: inline-block;
  z-index: 999;
}
.titleimgone {
  width: 0.22rem;
  position: absolute;
  top: 0.12rem;
  right: 0.5rem;
  display: inline-block;
  z-index: 999;
}
.fengxiangimg {
  width: 0.23rem;
  position: absolute;
  top: 0.12rem;
  right: 0.12rem;
  display: inline-block;
  z-index: 999;
}
.locathionclass {
  width: 100%;
  height: 0.7rem;
  margin-top: 0.15rem;
}
.locathionclass > div:nth-of-type(1) {
  float: left;
  font-size: 0.24rem;
  margin-left: 0.12rem;
  height: 0.7rem;
  line-height: 0.7rem;
}
.locathionclass > div:nth-of-type(2) {
  float: right;
  font-size: 0.24rem;
  height: 0.7rem;
  text-align: right;
  margin-right: 0.12rem;
}
.locathionclass > div:nth-of-type(2) > div:nth-of-type(1) {
  color: @colorone;
  line-height: 0.4rem;
}
.locathionclass > div:nth-of-type(2) > div:nth-of-type(1) > span {
  font-size: 0.13rem;
}
.locathionclass > div:nth-of-type(2) > div:nth-of-type(2) {
  font-size: 0.11rem;
  color: #666666;
}
.locathionname {
  font-size: 0.2rem;
  margin-top: 0.1rem;
  margin-left: 0.12rem;
}
.ullistname {
  width: 100%;
  overflow: hidden;
  margin-top: 0.25rem;
}
.ullistname > li {
  width: 50%;
  float: left;
  margin-top: 0.15rem;
  font-size: 0.15rem;
  color: #333333;
  text-indent: 0.12rem;
}
.ullistname > li:nth-of-type(1),
.ullistname > li:nth-of-type(2) {
  margin: 0;
}
.ullistname > li:nth-last-of-type(1) {
  width: 100%;
}
.ullistname > li > span {
  color: #666666;
}
.fangywz {
  font-size: 0.2rem;
  margin-top: 0.35rem;
  margin-left: 0.12rem;
}
#container{
    width:100%;
    height:2rem;
    margin-top:0.15rem;
}
.moreApratInfo{
    font-size:0.16rem;
    // margin-top:0.15rem;
    margin:0.15rem 0.12rem;
    overflow:hidden; 
    text-overflow:nowrap;
    display:-webkit-box; 
    -webkit-box-orient:vertical;
    -webkit-line-clamp:6; 
}
.moreApratInfo>span{
    color:#2581ff;
}
.shoubianfang{
    float:left;
    margin-top:0.35rem;
    font-size:0.2rem;
    margin-left:0.12rem;
}
.btnbottomul{
    width:100%;
    height:0.5rem;
    position: fixed;
    bottom:0;

}
.btnbottomul>li{
    width:50%;
    float:left;
    height:0.5rem;
    text-align: center;
    line-height: 0.5rem;
    font-size:0.17rem;
    color:#ffffff;
    z-index: 999999;
    background:@colorone;
}
.btnbottomul>li:nth-of-type(2){
    background:#5db1ff;
}
.warpdiv{
    width:100%;
    height:100%;
    position: fixed;
    background:rgba(1, 1, 1, 0.6);
    z-index:999999;
    top:0;
    left:0;
}
.warpdiv>div{
    width:3rem;
    height:1.82rem;
    background:#ffffff;
    position:fixed;
    top:50%;
    left:50%;
    margin-top:-1.3rem;
    margin-left:-1.5rem;
    border-radius: 0.06rem;
}
.warpdiv>img{
    width:0.23rem;
    height:0.23rem;
    position:fixed;
    top:65%;
    left:50%;
    margin-left:-0.115rem;
}
.messagebox{
    margin-left:0.15rem;
    margin-right:0.15rem;
    margin-top:0.3rem;
    height:0.8rem;
}
.messagebox>img{
    width:0.8rem;
    height:0.8rem;
    float:left;
}
.messagebox>div{
    height:100%;
    margin-left:0.15rem;
    float:left;
    font-size:0.2rem;
}
.messagebox>div>div:nth-of-type(2){
    font-size:0.15rem;
    margin-top:0.1rem;
    margin-bottom:0.1rem;
}
.messagebox>div>div:nth-of-type(3){
    font-size:0.13rem;
    margin-top:-0.05rem;
}
.phonebtn{
    widthP:100%;
    height:0.7rem;
}
.phonebtn>li{
    float:left;
    width:50%;
    height:100%;
    line-height: 0.7rem;
    text-align: center;
    font-size:0.18rem;
}
.phonebtn>li>img{
    width:0.23rem;
}
</style>

