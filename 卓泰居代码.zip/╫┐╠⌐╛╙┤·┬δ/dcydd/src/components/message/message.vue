<template>
    <div class="message">
        <headerone :dataname="dataname"></headerone>
    </div>
</template>
<script>
import headerone from '../module/headerone'
export default {
  data(){
      return{
          dataname:"消息"
      }
  },
  components:{
    headerone
  }
}
</script>
<style scoped lang="less">

</style>

