<template>
</template>


<script>
import Vue from 'Vue';
export default new Vue({
	name:"bus",
	data () {
		return {
			//code
		}
	}
})
</script>

<style>
</style>