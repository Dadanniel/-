<template>
	<div class="indexdiscounts">
		我的优惠劵
	</div>
</template>

<script>
</script>

<style>
</style>