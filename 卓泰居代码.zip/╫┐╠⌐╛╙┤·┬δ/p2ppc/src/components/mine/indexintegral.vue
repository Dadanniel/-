<template>
	<div class="indexintegral">
		我的积分
	</div>
</template>

<script>
</script>

<style>
</style>