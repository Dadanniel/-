export const availableMoney = state => state.availableMoney   //可用总余额 
export const userName = state => state.userName               //用户名 
export const cardId = state => state.cardId                   //身份证实名认证
export const email = state => state.email                     //邮箱认证