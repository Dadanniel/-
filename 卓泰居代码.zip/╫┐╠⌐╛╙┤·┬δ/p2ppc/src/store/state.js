const state = {
	shade:false,
	shadeone:false,
	availableMoney: '', //账户总余额
	userName: '',       //用户名
	cardId: false,         //身份证实名认证
	email: false,           //邮箱认证
	opinion:false,   //意见反馈窗口
}
export default state;