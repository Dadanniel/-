export const SET_AVAILABLEMONEY = 'SET_AVAILABLEMONEY'  //设置可用余额
export const SET_USERNAME = 'SET_USERNAME'              //设置用户名
